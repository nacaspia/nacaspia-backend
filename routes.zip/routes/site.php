<?php

use Illuminate\Support\Facades\Route;
/*
Route::get('/scraping/{data}', function ($data) {
    if ($data == 'news') {
        $dataScraper = new \App\Scraping\News();
        $result = $dataScraper->scrape(); // Metodu çağırırıq
    }elseif ($data == 'enlightenment') {
        $dataScraper = new \App\Scraping\Enlightenment();
        $result = $dataScraper->scrape(); // Metodu çağırırıq
    }elseif ($data == 'laboratorys') {
        $dataScraper = new \App\Scraping\Laboratory();
        $result = $dataScraper->scrape(); // Metodu çağırırıq
    }elseif ($data == 'useful') {
        $dataScraper = new \App\Scraping\Useful();
        $result = $dataScraper->scrape(); // Metodu çağırırıq
    }
    return response()->json($result); // JSON cavabı olaraq qaytarırıq
});*/
try {
    Route::group([
    'prefix' => implode('/', [LaravelLocalization::setLocale(), '']),
    'middleware' => ['localeSessionRedirect', 'localizationRedirect', 'localeViewPath' ]],
    function() {
        Route::get('/search', 'HomeController@search')->name('search');
        Route::get('/career', 'HomeController@career')->name('career');
        Route::get('/404', 'HomeController@notPage')->name('404');
        Route::get('/volunteer', 'HomeController@volunteer')->name('volunteer');
        Route::get('/career-apply/{slug}', 'HomeController@careerApply')->name('careerApply');
        Route::post('/send-career-apply', 'AjaxController@sendCareerApply')->name('sendCareerApply');
        Route::post('/send-volunteer-apply', 'AjaxController@sendVolunteerApply')->name('sendVolunteerApply');
        Route::get('/', 'HomeController@index')->name('index');
        Route::get('/enlightenment', 'HomeController@enlightenment')->name('enlightenment');
        Route::get('/enlightenment-details/{slug}', 'HomeController@enlightenmentDetails')->name('enlightenmentDetails');
        Route::get('/institute/{slug}', 'HomeController@institute')->name('institute');
        Route::get('/laboratory/{slug}', 'HomeController@laboratory')->name('laboratory');
        Route::get('/city-laboratory/{slug}', 'HomeController@cityLaboratory')->name('cityLaboratory');
        Route::get('/laboratory-details/{catSlug}/{slug}', 'HomeController@laboratoryDetails')->name('laboratoryDetails');
        Route::get('/service/{slug}', 'HomeController@service')->name('service');
        Route::post('/send-service-contact', 'AjaxController@sendServiceContact')->name('sendServiceContact');
        Route::get('/useful/{slug}', 'HomeController@useful')->name('useful');
        Route::get('/useful/{catSlug}/{slug}', 'HomeController@usefulDetail')->name('usefulDetail');
        Route::get('/contact', 'HomeController@contact')->name('contact');
        Route::post('/send-contact', 'AjaxController@sendContact')->name('sendContact');
        Route::get('/complaints', 'HomeController@complaints')->name('complaints');
        Route::get('/reception-days', 'HomeController@receptionDays')->name('receptionDays');
        Route::get('/tariff-details/{slug}', 'HomeController@tariffDetails')->name('tariffDetails');
        Route::get('/education/{slug}', 'HomeController@news')->name('news');
        Route::get('/education/{catSlug}/{slug}', 'HomeController@newsDetails')->name('newsDetails');
        Route::get('/page/{slug}/{parentSlug}', 'HomeController@page')->name('page');
        Route::get('/page-details/{slug}/{parentSlug}', 'HomeController@pageDetails')->name('pageDetails');
    });
    Route::fallback(function () {
        abort(404);
    });
}catch (\Exception $exception){
    return response($exception->getMessage(), 500);
}
