<?php
namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Models\About;
use App\Models\Accreditation;
use App\Models\Career;
use App\Models\Category;
use App\Models\Charter;
use App\Models\City;
use App\Models\Complaint;
use App\Models\Enlightenment;
use App\Models\HealthyEating;
use App\Models\InstituteCategory;
use App\Models\Laboratory;
use App\Models\LaboratoryCategory;
use App\Models\LeaderShip;
use App\Models\News;
use App\Models\Page;
use App\Models\PageContent;
use App\Models\Position;
use App\Models\Service;
use App\Models\Setting;
use App\Models\Structure;
use App\Models\TariffCategory;
use App\Models\Training;
use App\Models\Useful;
use App\Models\UsefulCategory;
use App\Models\UsefulLink;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    protected $currentLang;

    public function __construct()
    {
        $this->currentLang = LaravelLocalization::getCurrentLocale();
        if (!in_array($this->currentLang,['az','en','ru'])){
            return self::notFound();
        }
    }

    public function career()
    {
        $currentLang = $this->currentLang;
        $career = Career::where('status', 1)->orderBy('id','DESC')->get();
        return view('site.career',compact('currentLang','career'));
    }

    public function volunteer()
    {
        $currentLang = $this->currentLang;
        $languages = config('languages.languages');
        return view('site.volunteer',compact('currentLang','languages'));
    }

    public function careerApply($slug = null)
    {
        $currentLang = $this->currentLang;
        $languages = config('languages.languages');
        $career = null;
        if ($slug != 'apply'){
            $career = Career::where(['status' => 1,'slug->'.$this->currentLang => $slug])->first();
        }
        return view('site.career-apply',compact('currentLang','languages','career'));
    }

    public function index()
    {
        $currentLang = $this->currentLang;
        $newsCategory = Category::with('news')->where(['status' => 1])->first();
        $news = News::where(['is_main' => 1,'status' =>1,'category_id' => $newsCategory['id']])->orderBy('datetime','DESC')->offset(0)->limit(4)->get();
        $services = Service::where(['status'=> 1,'parent_id' => null,'sub_parent_id' => null])->get();
        $enlightenments = Enlightenment::where(['is_main' => 1,'status' =>1])->orderBy('datetime','DESC')->offset(0)->limit(4)->get();
        $healthyEating = HealthyEating::where('status', 1)->get();
        $usefulLink = UsefulLink::where('status', 1)->get();
        $cities = City::with('mainLaboratory','laboratory')->where(['status'=>1])->get();
        $tariffCategory = TariffCategory::where(['status' => 1])->get();
        $setting = Setting::first();
        return view('site.home',compact('currentLang','newsCategory','news','services','enlightenments','healthyEating','usefulLink','cities','tariffCategory','setting'));
    }

    public function tariffDetails($slug)
    {
        $currentLang = $this->currentLang;
        $tariffCategory = TariffCategory::with('tariffs')->where(['status' => 1,'slug->'.$this->currentLang => $slug])->first();
        if (empty($tariffCategory['tariffs'][0])){
            return self::notFound();
        }
        return view('site.tariff-detail',compact('currentLang','tariffCategory'));
    }

    public function news($slug)
    {
        $currentLang = $this->currentLang;

        $newsCategory = Category::with('news')->where('status', 1)->where("slug->{$this->currentLang}", $slug)->first();

        if ($newsCategory) {
            $newsCategory->news = $newsCategory->news()->paginate(8); // Paginate news items
        }
        if (empty($newsCategory['id']) || empty($newsCategory['news'][0])){
            return self::notFound();
        }
        return view('site.news',compact('currentLang','newsCategory'));
    }

    public function newsDetails($catSlug,$slug)
    {
        $currentLang = $this->currentLang;
        $newsCategory = Category::with('news')->where(['status' => 1,'slug->'.$this->currentLang => $catSlug])->orderBy('id','DESC')->first();
        if (empty($newsCategory['id']) || empty($newsCategory['news'][0])){
            return self::notFound();
        }
        $news = News::where(['status' => 1,'slug->'.$this->currentLang => $slug,'category_id' => $newsCategory['id']])->orderBy('id','DESC')->first();
        if (empty($news['id'])){
            return self::notFound();
        }
        return view('site.news-details',compact('currentLang','newsCategory','news'));
    }

    public function laboratory($slug)
    {
        $currentLang = $this->currentLang;
        $laboratoryCategory = LaboratoryCategory::with('laboratory')->where(['status' => 1,'slug->'.$this->currentLang => $slug])->first();
        if (empty($laboratoryCategory['id']) || empty($laboratoryCategory['laboratory'][0])){
            return self::notFound();
        }
        return view('site.laboratory',compact('currentLang','laboratoryCategory'));
    }

    public function cityLaboratory($slug)
    {
        $currentLang = $this->currentLang;
        $cities = City::with('laboratory')->where(['status' => 1,'slug->'.$this->currentLang => $slug])->orderBy('id','DESC')->first();
        if (empty($cities['laboratory'][0])){
            return self::notFound();
        }

        return view('site.city-laboratory',compact('currentLang','cities'));
    }

    public function laboratoryDetails($catSlug,$slug)
    {
        $currentLang = $this->currentLang;
        $laboratoryCategory = LaboratoryCategory::with('laboratory')->where(['status' => 1,'slug->'.$this->currentLang => $catSlug])->first();
        if (empty($laboratoryCategory['id']) || empty($laboratoryCategory['laboratory'][0])){
            return self::notFound();
        }
        $laboratory = Laboratory::where(['status' => 1,'slug->'.$this->currentLang => $slug,'category_id' => $laboratoryCategory['id']])->first();
        if (empty($laboratory['id'])){
            return self::notFound();
        }
        return view('site.laboratory-details',compact('currentLang','laboratoryCategory','laboratory'));
    }

    public function enlightenment()
    {
        $currentLang = $this->currentLang;
        $enlightenments = Enlightenment::where(['status' => 1])->orderBy('datetime','DESC')->paginate(8);
        if (empty($enlightenments[0])){
            return self::notFound();
        }
        return view('site.enlightenment',compact('currentLang','enlightenments'));
    }

    public function enlightenmentDetails($slug)
    {
        $currentLang = $this->currentLang;
        $enlightenment = Enlightenment::where(['status' => 1,'slug->'.$this->currentLang => $slug])->first();
        if (empty($enlightenment['id'])){
            return self::notFound();
        }
        return view('site.enlightenment-details',compact('currentLang','enlightenment'));
    }

    public function institute($slug)
    {

        $currentLang = $this->currentLang;
        $instituteCategory = InstituteCategory::where(['status' => 1, 'slug->'.$this->currentLang => $slug])->first();
        if (!empty($instituteCategory['page_type']) && $instituteCategory['page_type'] == 'slide_content'){
            $institutePage = About::where(['category_id' => $instituteCategory['id']])->first();
            if (empty($institutePage['id'])){
                return self::notFound();
            }
            return view('site.about',compact('currentLang','instituteCategory','institutePage'));
        }elseif (!empty($instituteCategory['page_type']) && $instituteCategory['page_type'] == 'file_content'){
            $institutePage = Charter::where(['category_id' => $instituteCategory['id']])->first();
            if (empty($institutePage['id'])){
                return self::notFound();
            }
            return view('site.charter',compact('currentLang','instituteCategory','institutePage'));
        }elseif (!empty($instituteCategory['page_type']) &&$instituteCategory['page_type'] == 'image_content'){
            $institutePage = Position::where(['status' => 1])->whereNull('parent_id')->with('parent','leaderShip')->
            whereHas('leaderShip', function ($query) use ($instituteCategory) {
                $query->where('category_id', $instituteCategory['id']);
                $query->where('is_show',1);
            })->get();
            if (empty($institutePage[0]['id'])){
                return self::notFound();
            }
            return view('site.leader-ship',compact('currentLang','instituteCategory','institutePage'));
        }elseif (!empty($instituteCategory['page_type']) &&$instituteCategory['page_type'] == 'content'){
            $institutePage = Structure::where(['status' => 1,'is_show' => 1,'category_id' => $instituteCategory['id']])->with('parent')->ordered()->orderBy('position_id','ASC','parent_position_id','ASC')->get();
            if (empty($institutePage[0]['id'])){
                return self::notFound();
            }
            return view('site.structure',compact('currentLang','instituteCategory','institutePage'));
        }elseif (!empty($instituteCategory['page_type']) &&$instituteCategory['page_type'] == 'photo'){
            $institutePage = Accreditation::where(['status' => 1,'category_id' => $instituteCategory['id']])->orderBy('id','DESC')->paginate(8);
            if (empty($institutePage[0]['id'])){
                return self::notFound();
            }
            return view('site.accreditation',compact('currentLang','instituteCategory','institutePage'));
        }else{
            return self::notFound();
        }
    }

    public function service($slug){
        $currentLang = $this->currentLang;
        $service = Service::with('parentCategories')->where(['status' => 1, 'slug->'.$this->currentLang => $slug])->first();
        if (empty($service['id'])){
            return self::notFound();
        }
        $trainings = Training::orderBy('id','DESC')->get();

        return view('site.service',compact('currentLang','service','trainings'));
    }

    public function useful($slug){
        $currentLang = $this->currentLang;
        $usefulCategory = UsefulCategory::where(['status' => 1, 'slug->'.$this->currentLang => $slug])->first();
//        dd($usefulCategory);
        if (!empty($usefulCategory['parent_id']) && empty($usefulCategory['sub_parent_id'])){
            $useful = Useful::where(['status' => 1,'category_id' => $usefulCategory['parent_id'],'parent_category_id' => $usefulCategory['id']])->with(['category','parentCategory','subParentCategory'])->orderBy('id','DESC')->get();
        }elseif (!empty($usefulCategory['sub_parent_id'])){
            $useful = Useful::where(['status' => 1,'category_id' => $usefulCategory['parent_id'],'parent_category_id' => $usefulCategory['sub_parent_id'],'sub_parent_category_id' => $usefulCategory['id']])->with(['category','parentCategory','subParentCategory'])->orderBy('id','DESC')->get();
        }else {
            $useful = Useful::where(['status' => 1,'category_id' => $usefulCategory['id']])->with(['category','parentCategory','subParentCategory'])->orderBy('id','DESC')->get();
        }
        if (empty($useful[0])){
            return self::notFound();
        }
        return view('site.useful',compact('currentLang','usefulCategory','useful'));
    }

    public function usefulDetail($catSlug, $slug){
        $currentLang = $this->currentLang;
        $usefulCategory = UsefulCategory::where(['status' => 1, 'slug->'.$this->currentLang => $catSlug])->first();
        if (empty($usefulCategory['id'])){
            return self::notFound();
        }
        if (!empty($usefulCategory['parent_id'])){
            $useful = Useful::where(['status' => 1,'category_id' => $usefulCategory['parent_id'],'parent_category_id' => $usefulCategory['id'], 'slug->'.$this->currentLang => $slug])->with(['category','parentCategory','subParentCategory'])->orderBy('id','DESC')->first();
        }elseif (!empty($usefulCategory['sub_category_parent_id'])){
            $useful = Useful::where(['status' => 1,'category_id' => $usefulCategory['parent_id'],'parent_category_id' => $usefulCategory['sub_category_parent_id'],'sub_category_parent_id' => $usefulCategory['id'], 'slug->'.$this->currentLang => $slug])->with(['category','parentCategory','subParentCategory'])->orderBy('id','DESC')->first();
        }else {
            $useful = Useful::where(['status' => 1,'category_id' => $usefulCategory['id'], 'slug->'.$this->currentLang => $slug])->with(['category','parentCategory','subParentCategory'])->orderBy('id','DESC')->first();
        }
        return view('site.useful-detail',compact('currentLang','usefulCategory','useful'));
    }

    public function contact(){
        $currentLang = $this->currentLang;
        $setting = Setting::first();
        return view('site.contact',compact('currentLang','setting'));
    }


    public function receptionDays(){
        $currentLang = $this->currentLang;
        $leaderShips = LeaderShip::with('parent')->whereNotNull('reception_days->'.$this->currentLang)->where(['status' => 1])->whereNotNull('parent_position_id')->orderBy('position_id','ASC','parent_position_id','ASC')->ordered()->get();

        $structures = Structure::with('parent')->whereNotNull('reception_days->'.$this->currentLang)->where(['status' => 1])->whereNotNull('parent_position_id')->ordered()->orderBy('position_id','ASC','parent_position_id','ASC')->get();
        if (empty($leaderShips[0]) && empty($structures[0])){
            return self::notFound();
        }
        $setting = Setting::first();
        return view('site.reception-days',compact('currentLang','leaderShips','structures','setting'));
    }

    public function complaints(){
        $currentLang = $this->currentLang;
        $complaint = Complaint::first();
        if (empty($complaint) && empty($complaint)){
            return self::notFound();
        }
        return view('site.complaints',compact('currentLang','complaint'));
    }
    public function search(Request $request)
    {
        $currentLang = $this->currentLang;
        $search = $request->get('q');
        if (!empty($search)) {
            $search = str_replace(['İ', 'I'], ['i', 'ı'],$search);
            $search = mb_strtolower($search, 'UTF-8');

            //institute
            $instituteCategory = InstituteCategory::where(['status' => 1])
                ->whereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(title, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->get()
                ->map(function ($item) {
                    if (!empty($item['slug'][$this->currentLang])){
                        $item->link = route('site.institute', [
                            'slug' => $item['slug'][$this->currentLang]
                        ]);
                    }else{
                        $item->link = null;
                    }
                    return $item;
                });


            $about = About::with('category')
                ->whereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(title, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(text, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(`fulltext`, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->get()
                ->map(function ($item) {
                    if (!empty($item['category']['slug'][$this->currentLang])){
                        $item->link = route('site.institute', [
                            'slug' => $item['category']['slug'][$this->currentLang]
                        ]);
                    }else{
                        $item->link = null;
                    }
                    return $item;
                });

            $charter = Charter::with('category')
                ->whereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(title, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(text, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(`fulltext`, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->get()
                ->map(function ($item) {
                    if (!empty($item['category']['slug'][$this->currentLang])){
                        $item->link = route('site.institute', [
                            'slug' => $item['category']['slug'][$this->currentLang]
                        ]);
                    }else{
                        $item->link = null;
                    }
                    return $item;
                });



            // News sonuçları
            $newsResults = News::with('category')
                ->whereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(title, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(text, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(`fulltext`, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->get()
                ->map(function ($item) {
                    $item->link = route('site.newsDetails', [
                        'catSlug' => $item['category']['slug'][$this->currentLang],
                        'slug' => $item['slug'][$this->currentLang]
                    ]); // News
                    $item->category = $item['category']['title'][$this->currentLang];
                    return $item;
                });


            // Enlightenment sonuçları
            $enlightenmentResults = Enlightenment::
            whereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(title, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(text, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(`fulltext`, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->get() ->map(function ($item) {
                    if (!empty($item['slug'][$this->currentLang])){
                        $item->link = route('site.enlightenmentDetails', [
                            'slug' => $item['slug'][$this->currentLang]
                        ]);
                    }else{
                        $item->link = null;
                    }

                    return $item;
                });

            // Laboratory sonuçları
            $laboratoryResults = Laboratory::
            whereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(title, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(text, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(`fulltext`, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->get()->map(function ($item) {
                    $item->link = route('site.laboratoryDetails', [
                        'catSlug' => $item['laboratoryCategory']['slug'][$this->currentLang],
                        'slug' => $item['slug'][$this->currentLang]
                    ]);
                    $item->category = $item['laboratoryCategory']['title'][$this->currentLang];
                    return $item;
                });

            // Useful sonuçları
            $usefulResults = Useful::
            whereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(title, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(text, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(`fulltext`, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->get()->map(function ($item) {
                    $item->link = !empty($item['file'])? asset('uploads/useful/file/'.$item->file) :route('site.usefulDetail', [
                        'catSlug' => $item['category']['slug'][$this->currentLang],
                        'slug' => $item['slug'][$this->currentLang]
                    ]);
                    $item->category = $item['category']['title'][$this->currentLang];
                    return $item;
                });

            // Service sonuçları
            $serviceResults = Service::
            whereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(title, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->orWhereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(text, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->get()->map(function ($item) {
                    $item->link =  route('site.service', [
                        'slug' => $item['slug'][$this->currentLang]
                    ]);
                    return $item;
                });

            //Pages
            $pageResults = Page::
            whereRaw('LOWER(REPLACE(REPLACE(JSON_UNQUOTE(JSON_EXTRACT(title, "$.'.$this->currentLang.'")), "&nbsp;", " "), "&#160;", " ")) LIKE ?', ['%'.strtolower($search).'%'])
                ->get()->map(function ($item) {
                    $item->link =  route('site.page',
                        ['slug' => $item['slug'][$this->currentLang]?? null,
                            'parentSlug' => $item['slug'][$this->currentLang] ?? null,
                            'pageParentCategories' =>  $item['slug'][$this->currentLang],
                            'subParentCategories' => $item['slug'][$this->currentLang]
                        ]);
                    return $item;
                });

            // Sonuçları birleştir
            $instituteCategory = collect($instituteCategory);
            $about = collect($about);
            $charter = collect($charter);
            $newsResults = collect($newsResults);
            $enlightenmentResults = collect($enlightenmentResults);
            $laboratoryResults = collect($laboratoryResults);
            $usefulResults = collect($usefulResults);
            $serviceResults = collect($serviceResults);
            $pageResults = collect($pageResults);

            $results = $instituteCategory->merge($about)
                ->merge($charter)
                ->merge($newsResults)
                ->merge($enlightenmentResults)
                ->merge($laboratoryResults)
                ->merge($usefulResults)
                ->merge($serviceResults)
                ->merge($pageResults);
//            dd($results);
        }else{
            return self::notFound();
        }
        return view('site.search', compact('currentLang', 'results'));
    }

    public function page($slug,$parentSlug,Request $request)
    {
        $currentLang = $this->currentLang;
//        'pageParentCategories' =>  $pageParentCategories['slug'][$currentLang], 'subParentCategories' => null
        $pageParentCategories =  $request['pageParentCategories'] ?? null;
        $subParentCategories =  $request['subParentCategories'] ?? null;
        if (empty($pageParentCategories) && empty($subParentCategories)){
            $page = Page::where(['status' => 1, 'slug->'.$this->currentLang => $parentSlug])->first();
        }else if (!empty($pageParentCategories) && !empty($subParentCategories)){
            $page = Page::where(['status' => 1, 'slug->'.$this->currentLang => $subParentCategories])->first();
        }else if (!empty($pageParentCategories) && empty($subParentCategories)){
            $page = Page::where(['status' => 1, 'slug->'.$this->currentLang => $pageParentCategories])->first();
        }
        if (empty($page) || $page['page_type'] == 'main'){
            return self::notFound();
        }

        if (empty($page['page_parent_id']) && empty($page['page_sub_parent_id']))
        {
            if (!empty($page['parent_id']) && $page['page_type'] == 'slider'){
                $pageContent = PageContent::where(['status' => 1,'page_id' => $page['parent_id'],'parent_page_id' => $page['id']])->orderBy('id','DESC')->first();
            }elseif (!empty($page['parent_id']) && $page['page_type'] == 'file_content'){
                $pageContent = PageContent::where(['status' => 1,'page_id' => $page['parent_id'],'parent_page_id' => $page['id']])->orderBy('id','DESC')->get();
            }else {
                $pageContent = PageContent::where(['status' => 1,'page_id' => $page['parent_id'],'parent_page_id' => $page['id']])->orderBy('id','DESC')->get();
            }
        }elseif (!empty($page['page_parent_id']) && !empty($page['page_sub_parent_id'])){
            if (!empty($page['parent_id']) && $page['page_type'] == 'slider'){
                $pageContent = PageContent::where(['status' => 1,'page_id' => $page['parent_id'],'parent_page_id' => $page['page_parent_id'],'page_parent_id' => $page['page_sub_parent_id'],'page_sub_parent_id' => $page['id']])->orderBy('id','DESC')->first();
                if (empty($pageContent)){
                    return self::notFound();
                }
            }elseif (!empty($page['parent_id']) && $page['page_type'] == 'file_content'){
                $pageContent = PageContent::where(['status' => 1,'page_id' => $page['parent_id'],'parent_page_id' => $page['page_parent_id'],'page_parent_id' => $page['page_sub_parent_id'],'page_sub_parent_id' => $page['id']])->orderBy('id','DESC')->get();
                if (empty($pageContent[0])){
                    return self::notFound();
                }
            }else {
                $pageContent = PageContent::where(['status' => 1,'page_id' => $page['parent_id'],'parent_page_id' => $page['page_parent_id'],'page_parent_id' => $page['page_sub_parent_id'],'page_sub_parent_id' => $page['id']])->orderBy('id','DESC')->get();
                if (empty($pageContent[0])){
                    return self::notFound();
                }
            }
        }elseif (!empty($page['page_parent_id']) && empty($page['page_sub_parent_id'])){
            if (!empty($page['parent_id']) && $page['page_type'] == 'slider'){
                $pageContent = PageContent::where(['status' => 1,'page_id' => $page['parent_id'],'parent_page_id' => $page['page_parent_id'],'page_parent_id' => $page['id']])->orderBy('id','DESC')->first();
                if (empty($pageContent)){
                    return self::notFound();
                }
            }elseif (!empty($page['parent_id']) && $page['page_type'] == 'file_content'){
                $pageContent = PageContent::where(['status' => 1,'page_id' => $page['parent_id'],'parent_page_id' => $page['page_parent_id'],'page_parent_id' =>$page['id']])->orderBy('id','DESC')->get();
                if (empty($pageContent[0])){
                    return self::notFound();
                }
            }else {
                $pageContent = PageContent::where(['status' => 1,'page_id' => $page['parent_id'],'parent_page_id' => $page['page_parent_id'],'page_parent_id' =>$page['id']])->orderBy('id','DESC')->get();
                if (empty($pageContent[0])){
                    return self::notFound();
                }
            }
        }

        return view('site.page',compact('currentLang','page','pageContent'));
    }

    public function pageDetails($slug,$parentSlug)
    {
        $currentLang = $this->currentLang;
        $page = Page::where(['status' => 1, 'slug->'.$this->currentLang => $slug])->with('parentOnePage')->first();

        if (empty($page['id'])){
            return self::notFound();
        }
        if (empty($page['page_parent_id']) && empty($page['page_sub_parent_id']))
        {
            $pageContent = PageContent::where(['status' => 1,'page_id' => $page['parent_id'],'parent_page_id' => $page['id'], 'slug->'.$this->currentLang => $parentSlug])->first();
        }elseif(!empty($page['page_parent_id']) && empty($page['page_sub_parent_id']))
        {
            $pageContent = PageContent::where(['status' => 1,'page_id' => $page['parent_id'],'parent_page_id' => $page['page_parent_id'],'page_parent_id' => $page['id'], 'slug->'.$this->currentLang => $parentSlug])->first();
        }elseif(!empty($page['page_parent_id']) && !empty($page['page_sub_parent_id']))
        {

            $pageContent = PageContent::where(['status' => 1,'page_id' => $page['parent_id'],'parent_page_id' => $page['page_parent_id'],'page_parent_id' => $page['page_sub_parent_id'],'page_sub_parent_id' => $page['id'], 'slug->'.$this->currentLang => $parentSlug])->first();
        }
        if (empty($pageContent['id'])){
            return self::notFound();
        }
        return view('site.page-details',compact('currentLang','page','pageContent'));
    }
    public function notPage()
    {
        $currentLang = $this->currentLang;
        return view('errors.404',compact('currentLang'));
    }

    public function notFound()
    {
        $currentLang = $this->currentLang;
        return view('site.not_found',compact('currentLang'));
    }
}
