<?php

namespace App\Http\Controllers\Admin;

use App\Helpers\AboutHelper;
use App\Helpers\AccreditationHelper;
use App\Helpers\CharterHelper;
use App\Helpers\LeaderShipHelper;
use App\Helpers\StructureHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\InstituteRequest;
use App\Models\About;
use App\Models\Accreditation;
use App\Models\Charter;
use App\Models\InstituteCategory;
use App\Models\LeaderShip;
use App\Models\Position;
use App\Models\Structure;
use App\Models\Translation;
use App\Repositories\AboutRepositoryImpl;
use App\Repositories\AccreditationRepositoryImpl;
use App\Repositories\CharterRepositoryImpl;
use App\Repositories\LeaderShipRepositoryImpl;
use App\Repositories\StructureRepositoryImpl;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Lang;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;

class InstituteController extends Controller
{
    protected $aboutRepository;
    protected $charterRepository;
    protected $leaderShipRepository;
    protected $structureRepository;
    protected $accreditationRepository;
    protected $currentLang;

    public function __construct(AboutRepositoryImpl $aboutRepository, CharterRepositoryImpl $charterRepository, LeaderShipRepositoryImpl $leaderShipRepository, StructureRepositoryImpl $structureRepository, AccreditationRepositoryImpl $accreditationRepository)
    {
        $this->aboutRepository = $aboutRepository;
        $this->charterRepository = $charterRepository;
        $this->leaderShipRepository = $leaderShipRepository;
        $this->structureRepository = $structureRepository;
        $this->accreditationRepository = $accreditationRepository;
        $this->currentLang = LaravelLocalization::getCurrentLocale();
        if (!in_array($this->currentLang,['az','en','ru'])){
            return self::notFound();
        }
    }
    public function notFound()
    {
        $currentLang = $this->currentLang;
        return view('site.not_found',compact('currentLang'));
    }

    public function index($slug){
        $instituteCategory = InstituteCategory::where(['slug->'.$this->currentLang => $slug,'status' => 1])->first();

        if (empty($instituteCategory)){
            return redirect(route('admin.index'));
        }
        $currentLang = $this->currentLang;
        $locales = Translation::where('status',1)->get();
        $institutePage = null;
        if ($instituteCategory['page_type'] == 'slide_content'){
            $institutePage = About::where(['category_id' => $instituteCategory['id']])->first();
        }elseif ($instituteCategory['page_type'] == 'file_content'){
            $institutePage = Charter::where(['category_id' => $instituteCategory['id']])->first();
        }elseif ($instituteCategory['page_type'] == 'image_content'){
            $institutePage = Position::where(['status' => 1])
                ->whereNull('parent_id')
                ->with(['leaderShip' => function ($query) use ($instituteCategory) {
                    $query->where('category_id', $instituteCategory->id);
                }])
                ->whereHas('leaderShip', function ($query) use ($instituteCategory) {
                    $query->where('category_id', $instituteCategory->id);// Burada sıralamaq istədiyiniz sütunu yazın
                })
                ->get();
        }elseif ($instituteCategory['page_type'] == 'content'){
            $institutePage = $this->structureRepository->getAll($instituteCategory);
        }elseif ($instituteCategory['page_type'] == 'photo'){
            $institutePage = $this->accreditationRepository->getAll($instituteCategory);
        }

        return view('admin.institute.index',compact('instituteCategory','currentLang','locales','institutePage'));
    }

    public function create($slug){
        $instituteCategory = InstituteCategory::where(['slug->'.$this->currentLang => $slug,'status' => 1])->first();
        if (empty($instituteCategory)){
            return redirect(route('admin.index'));
        }
        $locales = Translation::where('status',1)->get();
        $currentLang = $this->currentLang;
        $positions = null;
        if ($instituteCategory['page_type'] == 'image_content'){
            $positions = Position::where(['status' => 1])->whereNull('parent_id')->get();
        }elseif ($instituteCategory['page_type'] == 'content'){
            $positions = Position::where(['status' => 1])->whereNull('parent_id')->get();
        }
        return view('admin.institute.create',compact('instituteCategory','positions','locales','currentLang'));
    }


    public function store(InstituteRequest $instituteRequest)
    {
        try {
            $instituteCategory = InstituteCategory::where(['slug->'.$this->currentLang => $instituteRequest['category_slug'],'status' => 1])->first();
            $institutePage = null;
            $table = null;
            $dataSave = false;
            if ($instituteCategory['page_type'] == 'slide_content') {
                $validator = Validator::make($instituteRequest->all(), [
                    'slider_image.*' => 'required|image|mimes:jpeg,png,jpg,gif,svg|dimensions:width=1600,height=1066|max:237'
                ],[
                    'slider_image.*.required' => 'Hər bir slayd şəkili yüklənməlidir.',
                    'slider_image.*.image' => 'Yalnız şəkil faylları yüklənə bilər.',
                    'slider_image.*.mimes' => 'Şəkil yalnız jpeg, png, jpg, gif və ya svg formatında olmalıdır.',
                    'slider_image.*.dimensions' => 'Hər bir şəkilin ölçüsü 1600x1066 piksel olmalıdır.',
                    'slider_image.*.max' => 'Hər bir şəkil faylının maksimum ölçüsü 237 KB olmalıdır.'
                ]);
                if ($validator->fails()) {
                    return redirect()->back()->with('errors','errors '. $validator->errors());
                }
                $data = AboutHelper::data($instituteRequest,$institutePage,$instituteCategory['id']);
                $dataSave = $this->aboutRepository->create($data);
                $table = 'abouts';
            }elseif ($instituteCategory['page_type'] == 'file_content') {
                $data = CharterHelper::data($instituteRequest,$institutePage,$instituteCategory['id']);
                $dataSave = $this->charterRepository->create($data);
                $table = 'charters';
            }elseif ($instituteCategory['page_type'] == 'image_content') {
                $validator = Validator::make($instituteRequest->all(), [
                    'full_name.az' => 'required|string|max:255',
                    'position_id' => 'required',
                    'parent_position_id' => 'required',
                    'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|dimensions:width=1435,height=1600|max:228'
                ],[
                    'full_name.az.required' => 'Ad soyad vacibdi',
                    'position_id.required' => 'Vəzifə vacibdi',
                    'parent_position_id.required' => 'Alt vəzifə vacibdi',
                    'image.required' => 'Şəkil yükləmək məcburidir.',
                    'image.image' => 'Yalnız şəkil faylları yüklənə bilər.',
                    'image.mimes' => 'Şəkil yalnız jpeg, png, jpg, gif və ya svg formatında olmalıdır.',
                    'image.dimensions' => 'Şəkilin ölçüsü 1435x1600 piksel olmalıdır.',
                    'image.max' => 'Şəkil faylının maksimum ölçüsü 228 KB olmalıdır.'
                ]);
                if ($validator->fails()) {
                    return redirect()->back()->with('errors','errors '. $validator->errors());
                }
                $data = LeaderShipHelper::data($instituteRequest,$institutePage,$instituteCategory['id']);
                $dataSave = $this->leaderShipRepository->create($data);
                $table = 'leaderships';
            }elseif ($instituteCategory['page_type'] == 'content') {
                $data = StructureHelper::data($instituteRequest,$institutePage,$instituteCategory['id']);
                $dataSave = $this->structureRepository->create($data);
                $table = 'structures';
            }elseif ($instituteCategory['page_type'] == 'photo') {
                $validator = Validator::make($instituteRequest->all(), [
                    'title.az' => 'required|string|max:255',
                    'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|dimensions:width=2550,height=3300|max:1900'
                ],[
                    'image.required' => 'Şəkil yükləmək məcburidir.',
                    'image.image' => 'Yalnız şəkil faylları yüklənə bilər.',
                    'image.mimes' => 'Şəkil yalnız jpeg, png, jpg, gif və ya svg formatında olmalıdır.',
                    'image.dimensions' => 'Şəkilin ölçüsü 2550x3300 piksel olmalıdır.',
                    'image.max' => 'Şəkil faylının maksimum ölçüsü 1.9 MB olmalıdır.'
                ]);
                if ($validator->fails()) {
                    return redirect()->back()->with('errors','errors '. $validator->errors());
                }

                $data = AccreditationHelper::data($instituteRequest,$institutePage,$instituteCategory['id']);
                $dataSave = $this->accreditationRepository->create($data);
                $table = 'accreditations';
            }
            $messages = !empty($dataSave)? Lang::get('admin.add_success'): Lang::get('admin.add_error');

            $logData = [
                'subj_id' => $dataSave->id,
                'subj_table' => $table,
                'description' => $messages,
            ];
            saveLog($logData);
            DB::commit();
            return redirect()->back()->with('success', $messages);
        } catch (\Exception $exception) {
            DB::rollBack();
            $messages = $exception->getMessage();
            $logData = [
                'subj_id' => empty($institutePage['id'])? null: $institutePage['id'],
                'subj_table' => $table,
                'description' => $messages,
            ];
            saveLog($logData);
            return redirect()->back()->with('errors','errors '. $exception->getMessage());
        }
    }

    public function edit($id,$slug){
        $instituteCategory = InstituteCategory::where(['slug->'.$this->currentLang => $slug,'status' => 1])->first();
        if (empty($instituteCategory)){
            return redirect(route('admin.index'));
        }
        $locales = Translation::where('status',1)->get();
        $currentLang = $this->currentLang;
        $positions = null;
        if ($instituteCategory['page_type'] == 'image_content'){
            $institutePage = $this->leaderShipRepository->edit($id);
            $positions = Position::where(['status'=>1])->whereNull('parent_id')->get();
        }elseif ($instituteCategory['page_type'] == 'content'){
            $institutePage = $this->structureRepository->edit($id);
            $positions = Position::where('status',1)->whereNull('parent_id')->get();
        }elseif ($instituteCategory['page_type'] == 'photo'){
            $institutePage = $this->accreditationRepository->edit($id);
        }
        return view('admin.institute.edit',compact('instituteCategory','institutePage','positions','locales','currentLang'));
    }

    public function update(InstituteRequest $instituteRequest, $id)
    {
        try {
            $instituteCategory = InstituteCategory::where(['slug->'.$this->currentLang => $instituteRequest['category_slug'],'status' => 1])->first();
            $institutePage = null;
            $table = null;
            $dataUp = false;
            if ($instituteCategory['page_type'] == 'slide_content') {
                $validator = Validator::make($instituteRequest->all(), [
                    'slider_image.*' => 'image|mimes:jpeg,png,jpg,gif,svg|dimensions:width=1600,height=1066|max:237'
                ],[
                    'slider_image.*.image' => 'Yalnız şəkil faylları yüklənə bilər.',
                    'slider_image.*.mimes' => 'Şəkil yalnız jpeg, png, jpg, gif və ya svg formatında olmalıdır.',
                    'slider_image.*.dimensions' => 'Hər bir şəkilin ölçüsü 1600x1066 piksel olmalıdır.',
                    'slider_image.*.max' => 'Hər bir şəkil faylının maksimum ölçüsü 237 KB olmalıdır.'
                ]);
                if ($validator->fails()) {
                    return redirect()->back()->with('errors','errors '. $validator->errors());
                }
                $institutePage = $this->aboutRepository->edit($id);
                $data = AboutHelper::data($instituteRequest,$institutePage,$instituteCategory['id']);
                $dataUp = $this->aboutRepository->update($id,$data);
                $table = 'abouts';
            }elseif ($instituteCategory['page_type'] == 'file_content') {
                $institutePage = $this->charterRepository->edit($id);
                $data = CharterHelper::data($instituteRequest,$institutePage,$instituteCategory['id']);
                $dataUp = $this->charterRepository->update($id,$data);
                $table = 'charters';
            }elseif ($instituteCategory['page_type'] == 'image_content') {
                $validator = Validator::make($instituteRequest->all(), [
                    'image' => 'image|mimes:jpeg,png,jpg,gif,svg|dimensions:width=1435,height=1600|max:228'
                ],[
                    'image.image' => 'Yalnız şəkil faylları yüklənə bilər.',
                    'image.mimes' => 'Şəkil yalnız jpeg, png, jpg, gif və ya svg formatında olmalıdır.',
                    'image.dimensions' => 'Şəkilin ölçüsü 1435x1600 piksel olmalıdır.',
                    'image.max' => 'Şəkil faylının maksimum ölçüsü 228 KB olmalıdır.'
                ]);
                if ($validator->fails()) {
                    return redirect()->back()->with('errors','errors '. $validator->errors());
                }
                $institutePage = $this->leaderShipRepository->edit($id);
                $data = LeaderShipHelper::data($instituteRequest,$institutePage,$instituteCategory['id']);
                $dataUp = $this->leaderShipRepository->update($id,$data);
                $table = 'leaderships';
            }elseif ($instituteCategory['page_type'] == 'content') {
                $institutePage = $this->structureRepository->edit($id);
                $data = StructureHelper::data($instituteRequest,$institutePage,$instituteCategory['id']);
                $dataUp = $this->structureRepository->update($id,$data);
                $table = 'structures';
            }elseif ($instituteCategory['page_type'] == 'photo') {
                $institutePage = $this->accreditationRepository->edit($id);
                $validator = Validator::make($instituteRequest->all(), [
                    'title.az' => 'required|string|max:255',
                    'image' => 'image|mimes:jpeg,png,jpg,gif,svg|dimensions:width=2550,height=3300|max:1900'
                ],[
                    'image.image' => 'Yalnız şəkil faylları yüklənə bilər.',
                    'image.mimes' => 'Şəkil yalnız jpeg, png, jpg, gif və ya svg formatında olmalıdır.',
                    'image.dimensions' => 'Şəkilin ölçüsü 2550x3300 piksel olmalıdır.',
                    'image.max' => 'Şəkil faylının maksimum ölçüsü 1.9 MB olmalıdır.'
                ]);
                if ($validator->fails()) {
                    return redirect()->back()->with('errors','errors '. $validator->errors());
                }
                $data = AccreditationHelper::data($instituteRequest,$institutePage,$instituteCategory['id']);
                $dataUp = $this->accreditationRepository->update($id,$data);
                $table = 'accreditations';
            }
            $messages = !empty($dataUp)? Lang::get('admin.up_success'): Lang::get('admin.up_error');
            $logData = [
                'subj_id' => $id,
                'subj_table' => $table,
                'description' => $messages,
            ];
            saveLog($logData);
            DB::commit();
            return redirect()->back()->with('success', $messages);
        } catch (\Exception $exception) {
            DB::rollBack();
            $messages = $exception->getMessage();
            $logData = [
                'subj_id' => $id,
                'subj_table' => $table,
                'description' => $messages,
            ];
            saveLog($logData);
            return redirect()->back()->with('errors','errors '. $exception->getMessage());
        }
    }



    public function destroy(Request $request,$id)
    {
        try {
            $instituteCategory = InstituteCategory::where(['slug->'.$this->currentLang => $request->category_slug,'status' => 1])->first();

            if (empty($instituteCategory)){
                return redirect(route('admin.index'));
            }
            $institutePage = null;
            if ($instituteCategory['page_type'] == 'image_content'){
                $institutePage = $this->leaderShipRepository->delete($id);
                $table = 'leaderships';
            }elseif ($instituteCategory['page_type'] == 'content'){
                $institutePage = $this->structureRepository->delete($id);
                $table = 'structures';
            }elseif ($instituteCategory['page_type'] == 'photo'){
                $institutePage = $this->accreditationRepository->delete($id);
                $table = 'accreditations';
            }
            $messages = Lang::get('admin.delete_success');
            $logData = [
                'subj_id' => $id,
                'subj_table' => $table,
                'description' => $messages,
            ];
            saveLog($logData);
            return redirect()->back()->with('success', $messages);
        } catch (\Exception $exception) {
            $messages = $exception->getMessage();
            $logData = [
                'subj_id' => $id,
                'subj_table' => 'institute',
                'description' => $messages,
            ];
            saveLog($logData);
            return redirect()->back()->with('errors', 'errors ' . $messages);
        }
    }

    public function deleteSliderImage(Request $request)
    {
        $imageName = $request->input('image'); // Silinməsi istənilən şəkil adı

        // Məlumatları əldə edin
        $about = About::whereJsonContains('slider_image', $imageName)->first();

        if (!$about) {
            return response()->json(['success' => false, 'message' => 'Məlumat tapılmadı.']);
        }

        // Şəkil massivini əldə edin
        $sliderImages = $about->slider_image; // Artıq massivdir, json_decode etməyə ehtiyac yoxdur

        // Şəkili massivdən sil
        if (($key = array_search($imageName, $sliderImages)) !== false) {
            unset($sliderImages[$key]); // Şəkili massivdən çıxar
        }

        // Yenilənmiş massiv
        $about->slider_image = array_values($sliderImages); // İndeksləri yenilə
        $about->save(); // Məlumatları saxla

        // Fiziki faylı sil
        $imagePath = public_path('uploads/institute/abouts/' . $imageName);
        if (file_exists($imagePath)) {
            unlink($imagePath); // Şəkili sil
        }

        return response()->json(['success' => true, 'message' => 'Şəkil uğurla silindi.']);
    }

    public static function orderBy( Request $request)
    {
        $sortedIDs = $request->sortedIDs;
        $type = $request->type;
        if ($type == 'structure') {
            foreach ($sortedIDs as $order => $id) {
                Structure::where('id', $id)->update(['order_by' => $order + 1]);
            }
            $leadId = $request->leadId;
            $leadId = Structure::where('id', $leadId)->first();
            if (!empty($leadId['reception_days']['az'])) {
                $messages = 'Struktur və qəbul günlərində sıralama uğurla yeniləndi!';
            }else{
                $messages = 'Struktur sıralama uğurla yeniləndi!';
            }
        }else{
            foreach ($sortedIDs as $order => $id) {
                LeaderShip::where('id', $id)->update(['order_by' => $order + 1]);
            }
            $leadId = $request->leadId;
            $leadId = LeaderShip::where('id', $leadId)->first();
            if (!empty($leadId['reception_days']['az'])) {
                $messages = 'Rəhbərlik və qəbul günlərində sıralama uğurla yeniləndi!';
            }else{
                $messages = 'Rəhbərlikdə sıralama uğurla yeniləndi!';
            }
        }

        return response()->json(['status' => 'success', 'message' => $messages]);
    }

}
