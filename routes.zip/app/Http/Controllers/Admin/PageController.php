<?php

namespace App\Http\Controllers\Admin;

use App\Helpers\PageHelper;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\PageRequest;
use App\Models\LaboratoryCategory;
use App\Models\Page;
use App\Models\PageContent;
use App\Models\Translation;
use App\Repositories\PageRepositoryImpl;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Lang;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;

class PageController extends Controller
{
    protected $pageRepository;
    protected $currentLang;

    public function __construct(PageRepositoryImpl $pageRepository)
    {
        $this->pageRepository = $pageRepository;
        $this->currentLang = LaravelLocalization::getCurrentLocale();
        if (!in_array($this->currentLang,['az','en','ru'])){
            return self::notFound();
        }
    }
    public function notFound()
    {
        $currentLang = $this->currentLang;
        return view('site.not_found',compact('currentLang'));
    }

    public function index()
    {
        $pages = $this->pageRepository->getAll();
        $mainPage = Page::whereNull('parent_id')->where('status',1)->get();
        $locales = Translation::where('status',1)->get();
        $currentLang = $this->currentLang;
        return view('admin.pages.index', compact('pages','mainPage','locales','currentLang'));
    }

    public function create()
    {
        //
    }

    public function store(PageRequest $pageRequest)
    {
        try {
            $data = PageHelper::data($pageRequest);
            $page = $this->pageRepository->create($data);
            if ($page) {
                $messages = Lang::get('admin.add_success');
            }else{
                $messages = Lang::get('admin.add_error');
            }
            $logData = [
                'subj_id' => $page->id,
                'subj_table' => 'pages',
                'description' => $messages,
            ];
            saveLog($logData);
            DB::commit();
            return redirect()->back()->with('success', $messages);
        } catch (\Exception $exception) {
            DB::rollBack();
            $messages = $exception->getMessage();
            $logData = [
                'subj_id' => null,
                'subj_table' => 'pages',
                'description' => $messages,
            ];
            saveLog($logData);
            return redirect()->back()->with('errors','errors '. $exception->getMessage());
        }
    }

    public function show(Page $page)
    {
        //
    }

    public function edit(Page $page)
    {
        //
    }

    public function update(PageRequest $pageRequest, $id)
    {
        try {
            $data = PageHelper::data($pageRequest);
            $page = $this->pageRepository->update($id,$data);
            if ($page) {
                $messages = Lang::get('admin.up_success');
            }else{
                $messages = Lang::get('admin.up_error');
            }
            $logData = [
                'subj_id' => $id,
                'subj_table' => 'pages',
                'description' => $messages,
            ];
            saveLog($logData);
            DB::commit();
            return redirect()->back()->with('success', $messages);
        } catch (\Exception $exception) {
            DB::rollBack();
            $messages = $exception->getMessage();
            $logData = [
                'subj_id' => $id,
                'subj_table' => 'pages',
                'description' => $messages,
            ];
            saveLog($logData);
            return redirect()->back()->with('errors','errors '. $exception->getMessage());
        }
    }

    public function destroy($id)
    {
        try {
            $page = $this->pageRepository->edit($id);

            if (!empty($page['parent_id'])) {
                $pageContent = PageContent::where(['page_id' => $page['parent_id'], 'parent_page_id' => $page['id']])->delete();
            }else{
                $pageContent = PageContent::where('page_id',$id)->delete();
            }
            $parent = Page::where(['parent_id' => $page['parent_id']])->get();

            $parentPage = Page::where(['page_parent_id' => $page['id']])->get();
            $parentSubPage = Page::where(['page_sub_parent_id' => $page['id']])->get();

            if (empty($page['parent_id']) && !empty($parent[0]) && empty($parentPage[0]) && empty($parentSubPage[0])) {
                Page::where(['parent_id' => $page['parent_id']])->delete();
            }elseif (!empty($page['parent_id']) && !empty($parent[0]) && !empty($parentPage[0]) && empty($parentSubPage[0])) {
                Page::where(['page_parent_id' => $page['id']])->delete();
            }elseif (!empty($page['parent_id']) && !empty($parent[0]) && !empty($parentPage[0]) && !empty($parentSubPage[0])) {
                Page::where(['page_sub_parent_id' => $page['id']])->delete();
            }
            if ($this->pageRepository->delete($page['id'])) {
                $messages = Lang::get('admin.delete_success');
                $logData = [
                    'subj_id' => $id,
                    'subj_table' => 'pages',
                    'description' => $messages,
                ];
                saveLog($logData);
                return redirect()->back()->with('success', $messages);
            }
        } catch (\Exception $exception) {
            $messages = $exception->getMessage();
            $logData = [
                'subj_id' => $id,
                'subj_table' => 'pages',
                'description' => $messages,
            ];
            saveLog($logData);
            return redirect()->back()->with('errors', 'errors ' . $messages);
        }

    }

    public function getParentPage(Request $request)
    {
        $parentId = $request->input('parent_id');
        if (!$parentId) {
            return response()->json(['success' => false, 'message' => 'Invalid parent ID']);
        }

        // Alt kateqoriyaları gətir
        $parentPage = Page::where('parent_id', $parentId)->whereNotNull('parent_id')->whereNull(['page_parent_id','page_sub_parent_id'])->get()->map(function ($page) {
            return [
                'id' => $page->id,
                'title' => $page['title'][$this->currentLang] ?? null,
                'page_type' => $page['page_type'] ?? null,
            ];
        });

        return response()->json(['success' => true, 'parentPage' => $parentPage]);
    }

    public function getParentCategories(Request $request)
    {
        $parentId = $request->input('page_parent_id');
        if (!$parentId) {
            return response()->json(['success' => false, 'message' => 'Invalid parent ID']);
        }

        // Alt kateqoriyaları gətir
        $subCategories = Page::where('page_parent_id', $parentId)->whereNotNull('page_parent_id')->whereNull('page_sub_parent_id')->get()->map(function ($category) {
            return [
                'id' => $category->id,
                'title' => $category['title'][$this->currentLang] ?? null,
            ];
        });

        return response()->json(['success' => true, 'parentCategories' => $subCategories]);
    }

    public function getSubCategories(Request $request)
    {
        $sub_parent_id = $request->input('page_sub_parent_id');
        if (!$sub_parent_id) {
            return response()->json(['success' => false, 'message' => 'Invalid parent ID']);
        }

        // Alt kateqoriyaları gətir
        $subCategories = Page::where('page_sub_parent_id', $sub_parent_id)->whereNotNull('page_parent_id')->whereNotNull('page_sub_parent_id')->get()->map(function ($category) {
            return [
                'id' => $category->id,
                'title' => $category['title'][$this->currentLang] ?? null,
            ];
        });

        return response()->json(['success' => true, 'subParentCategories' => $subCategories]);
    }
}
