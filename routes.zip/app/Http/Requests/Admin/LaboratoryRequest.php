<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Lang;

class LaboratoryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules()
    {
        $isCreate = $this->isMethod('post');
        return [
           'image' => $isCreate ?  'required|image|mimes:jpeg,png,jpg,gif,svg|dimensions:width=5326,height=4339|max:10500': 'image|mimes:jpeg,png,jpg,gif,svg|dimensions:width=5326,height=4339|max:10500',
            'category_id' => 'required',
            'title.az' => 'required|string|max:255',
            'text.az' => 'nullable|string',
            'fulltext.*' => 'nullable|string'
        ];
    }

    public function messages()
    {
        return [
            '*.required' => Lang::get('validation.required', ['attribute' => ':attribute']),
            '*.string' => Lang::get('validation.string', ['attribute' => ':attribute']),
            'datetime.date' => Lang::get('validation.date', ['attribute' => ':attribute']),
            'image.required' => 'Şəkil yükləmək məcburidir.',
            'image.image' => 'Yalnız şəkil faylları yüklənə bilər.',
            'image.mimes' => 'Şəkil yalnız jpeg, png, jpg, gif və ya svg formatında olmalıdır.',
            'image.dimensions' => 'Şəkilin ölçüsü 5326x4339 piksel olmalıdır.',
            'image.max' => 'Şəkil faylının maksimum ölçüsü 10.5 MB olmalıdır.',
            ];
    }
}
