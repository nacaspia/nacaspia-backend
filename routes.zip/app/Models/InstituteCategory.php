<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InstituteCategory extends Model
{
    use HasFactory;

    protected $table = 'institute_categories';

    protected $fillable = [
        'id',
        'parent_id',
        'sub_parent_id',
        'title',
        'slug',
        'page_type',
        'order_by',
        'status'
    ];

    public function scopeOrdered($query)
    {
        return $query->orderBy('order_by');
    }

    protected $casts = [
        'title' => 'array',
        'slug' => 'array',
    ];

    public function parentCategories()
    {
        return $this->hasMany(InstituteCategory::class,'parent_id','id')->whereNull('sub_parent_id')->with('subParentCategories');
    }

    public function subParentCategories()
    {
        return $this->hasMany(InstituteCategory::class,'sub_parent_id','id');
    }
}
