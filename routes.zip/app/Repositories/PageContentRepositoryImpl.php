<?php
namespace App\Repositories;
use App\Contracts\PageContentRepository;
use App\Models\PageContent;

class PageContentRepositoryImpl implements PageContentRepository
{
    protected $model;

    public function __construct()
    {
        $this->model  = new PageContent();
    }

    public function getAll()
    {
        return $this->model->with(['page','parentPage','subParentPage','pageSubParentPage'])->orderBy('id','DESC')->get();
    }

    public function create(array $data)
    {
        return $this->model->create($data);
    }

    public function edit($id)
    {
        return $this->model->with(['page','parentPage','subParentPage','pageSubParentPage'])->whereId($id)->first();
    }

    public function update($id, array $data)
    {
        return $this->model->whereId($id)->update($data);
    }

    public function delete($id)
    {
        return $this->model->whereId($id)->delete();
    }
}
