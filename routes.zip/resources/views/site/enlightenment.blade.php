@extends('site.layouts.app')
@section('site.title')
    @lang('site.education')
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset("site/assets/css/education_page.css") }}" />
{{--    <link rel="stylesheet" href="{{ asset("site/assets/css/cooperation.css") }}" />--}}
@endsection
@section('site.content')
    <section class="education_page">
        <h1>@lang('site.education')</h1>
        <div class="education_row">
            @if(!empty($enlightenments[0]))
                @foreach($enlightenments as $enlightenment)
                    <?php $slug = !empty($enlightenment['slug'][$currentLang]) ? $enlightenment['slug'][$currentLang] : null;?>
                        <a href="@if(!empty($enlightenment['slug'][$currentLang])) {{ route('site.enlightenmentDetails',['slug' => $slug]) }} @endif" class="education_card">
                            <div class="education_img">
                                <img src="{{ asset('uploads/enlightenment/'.$enlightenment->image) }}" alt="{!! !empty($enlightenment['title'][$currentLang])? $enlightenment['title'][$currentLang]: null !!}" />
                            </div>
                            <div class="education_text">
                                <h5>
                                    {!! !empty($enlightenment['title'][$currentLang])? $enlightenment['title'][$currentLang]: NULL !!}
                                </h5>
                                <span>{!! date('d-m-Y\TH:i', strtotime($enlightenment->datetime)) !!}</span>
                                <p>{!! !empty($enlightenment['text'][$currentLang])? $enlightenment['text'][$currentLang]: NULL !!}</p>
                            </div>
                        </a>
                @endforeach
            @endif
        </div>
    </section>
    @if(!empty($enlightenments[0]) && isset($enlightenments[0]))
        {{ $enlightenments->appends(request()->except('page'))->links('components.site.pagination',['posts' => $enlightenments]) }}
    @endif
@endsection
@section('site.js')
    <script src="{{ asset('site/assets/js/education.js') }}"></script>
    <script src="{{ asset("site/assets/js/home.js") }}"></script>
@endsection
