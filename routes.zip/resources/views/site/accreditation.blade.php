@extends('site.layouts.app')
@section('site.title')
    {{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset('site/assets/css/home.css') }}" />
    <link rel="stylesheet" href="{{ asset('site/assets/css/bylaws.css') }}" />
    <link rel="stylesheet" href="{{ asset('site/assets/css/accreditation.css') }}" />
@endsection
@section('site.content')
    <section class="accreditation">
        <h1>{{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}</h1>
        @if(!empty($institutePage[0]) && isset($institutePage[0]))
        <div class="accreditaion_row">
            @foreach($institutePage as $data)
            <div class="accrediation_card"  data-id="{{ !empty($data['slug'][$currentLang]) ? $data['slug'][$currentLang]: null }}">
                <div class="certificate_img">
                    <img src="{{ asset('uploads/institute/accreditation/'.$data->image) }}" alt="{{ !empty($data['full_name'][$currentLang])? $data['full_name'][$currentLang]: null }}">
                </div>
                <p>{{ !empty($data['title'][$currentLang]) ? $data['title'][$currentLang]: null }}</p>
            </div>
            @endforeach
        </div>
        @endif
    </section>
    @if(!empty($institutePage[0]) && isset($institutePage[0]))
    {{ $institutePage->appends(request()->except('page'))->links('components.site.pagination',['posts' => $institutePage]) }}
    @endif
    @foreach($institutePage as $data)
    <div class="pop_up_certificate">
        <div class="certificate_full">
            <img src="{{ asset('uploads/institute/accreditation/'.$data->image) }}" alt="{{ !empty($data['full_name'][$currentLang])? $data['full_name'][$currentLang]: null }}">
        </div>
    </div>
    @endforeach
@endsection
@section('site.js')
    <script src="{{ asset('site/assets/js/accreditaion.js') }}"></script>
@endsection
