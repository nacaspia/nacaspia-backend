@extends('site.layouts.app')
@section('site.title')
    {{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset('site/assets/css/structure.css') }}" />
    <link rel="stylesheet" href="{{ asset('site/assets/css/accreditation.css') }}" />
@endsection
@section('site.content')
    <section class="container-fluid structure">
        <div class="row">
            <h1>{{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}</h1>
            <div class="structure_row">
                @if(!empty($institutePage[0]) && isset($institutePage[0]))
                    @foreach($institutePage as $institute)
                        <div class="structure_block">
                            <div class="structure_block_header">
                                <h5>{!! !empty($institute['title'][$currentLang])? $institute['title'][$currentLang]: null !!}</h5>
                            </div>
                            <div class="contact_person">
                                <div class="contact_person_name">
                                    @if(!empty($institute->image))
                                    <figure  data-id="{{ asset('uploads/institute/structureImage/'.$institute->image) }}">
                                        <img src="{{ asset('uploads/institute/structureImage/'.$institute->image) }}" alt="" />
                                    </figure>
                                    @endif
                                    <div class="contact_person_name_info">
                                    <p> {{ !empty($institute['full_name'][$currentLang])? $institute['full_name'][$currentLang]: null }}</p>
                                    @if(!empty($institute['parent']))
                                    <span class="position"> {{ !empty($institute['parent']['title'][$currentLang])? $institute['parent']['title'][$currentLang]: null }}</span>
                                    @endif
                                    </div>
                                </div>
                                @if(!empty($institute['email']))
                                <div class="contact_info">
                                    <img src="{{ asset('site/assets/images/svg/email_orange.svg') }}" alt="" />
                                    <a href="mailto:{{$institute['email']}}">{{$institute['email']}}</a>
                                </div>
                                @endif
                                @if(!empty($institute['phone']))
                                <div class="contact_info">
                                    <img src="{{ asset('site/assets/images/svg/phone_orange.svg') }}" alt="" />
                                    <a href="tel:{{$institute['phone']}}">{{$institute['phone']}}</a>
                                </div>
                                @endif
                            </div>
                            <div class="pdf_div">
                                <a target="_blank" href="{{ asset('uploads/institute/structure/'.$institute['file'] ) }}" class="pdf_file_structure">
                                    <img src="{{ asset('site/assets/images/svg/pdf.svg') }}" alt="pdf file" />
                                    <span>Əsasnamə</span>
                                </a>
                            </div>
                        </div>
                    @endforeach
                @endif
            </div>
        </div>
    </section>
    <div id="imageModal" class="modal">
        <div class="modal-overlay"></div>
        <img id="modalImage" class="modal-image" src="" alt="image" />
    </div>
@endsection
@section('site.js')
    <script src="{{ asset('site/assets/js/structure.js') }}"></script>
@endsection
