@extends('site.layouts.app')
@section('site.title')
    @lang('site.complaints')
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset('site/assets/css/complaints.css') }}" />
@endsection
@section('site.content')
    <section class="complaints">
        <h1>{{ !empty($complaint['title'][$currentLang])? $complaint['title'][$currentLang]: NULL }}</h1>
        <div class="header_text_div">
            <p class="header_text">{!! !empty($complaint['text'][$currentLang])? $complaint['text'][$currentLang]: NULL !!}</p>
        </div>
        <div class="call">
            <div>@lang('site.email'): <a href="mailto:{{ !empty($complaint['contact']['email'])? $complaint['contact']['email']: NULL }}">{{ !empty($complaint['contact']['email'])? $complaint['contact']['email']: NULL }}</a></div>
            <div>“{{ !empty($complaint['contact']['phone'])? $complaint['contact']['phone']: NULL }} Çağrı Mərkəzi”</div>
            <div>@lang('site.website'): <a href="https://afsi.gov.az">afsi.gov.az</a></div>
        </div>
    </section>
    <section class="steps">
        <div class="step_row">
            @foreach($complaint['block'] as $key => $blockItem)
                <div class="step">
                    <div class="step_number">
                        <img src="{{ asset('site/assets/images/svg/complaints_step'.$loop->iteration.'.svg') }}" alt="" />
                    </div>
                    <span>{{ $blockItem[$currentLang] ?? '' }}</span>
                </div>
            @endforeach
        </div>
    </section>
    @if(!empty($complaint['file']['file']))
    <section class="pdf_file">
        <a href="{{ asset('uploads/complaint/'.$complaint['file']['file']) }}" download class="download_button">
            <div class="text_icon">
                <img src="{{ asset('site/assets/images/svg/pdf.svg') }}" alt="pdf file" />
                {{ !empty($complaint['file']['file_title'][$currentLang])? $complaint['file']['file_title'][$currentLang]: NULL }}
            </div>
            <div>
                <img src="{{ asset('site/assets/images/svg/download.svg') }}" alt="PDF" />
                <span>@lang('site.download')</span>
            </div>
        </a>
    </section>
    @endif
@endsection
@section('site.js')
@endsection
