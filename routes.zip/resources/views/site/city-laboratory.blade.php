@extends('site.layouts.app')
@section('site.title')
    {{ !empty($cities['name'][$currentLang])? $cities['name'][$currentLang]: null }}
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset("site/assets/css/laboratories.css") }}" />
@endsection
@section('site.content')
    <section class="container-fluid career_header">
        <div class="career_header_text">
            <h1>{{ !empty($cities['name'][$currentLang])? $cities['name'][$currentLang]: null }}</h1>
            <p>@lang('site.laboratory_content')</p>
        </div>
        <div class="career_circle1">
            <img src="{{ asset('site/assets/images/svg/lab_icon.svg') }}" alt="{{ !empty($cities['name'][$currentLang])? $cities['name'][$currentLang]: null }}" />
        </div>
        <div class="career_circle2">
            <img src="{{ asset('site/assets/images/svg/lab_icon.svg') }}" alt="{{ !empty($cities['name'][$currentLang])? $cities['name'][$currentLang]: null }}" />
        </div>
        <div class="career_circle3">
            <img src="{{ asset('site/assets/images/svg/lab_icon.svg') }}" alt="{{ !empty($cities['name'][$currentLang])? $cities['name'][$currentLang]: null }}" />
        </div>
        <div class="career_circle4">
            <img src="{{ asset('site/assets/images/svg/lab_icon.svg') }}" alt="{{ !empty($cities['name'][$currentLang])? $cities['name'][$currentLang]: null }}" />
        </div>
        <div class="career_circle5">
            <img src="{{ asset('site/assets/images/svg/lab_icon.svg') }}" alt="{{ !empty($cities['name'][$currentLang])? $cities['name'][$currentLang]: null }}" />
        </div>
    </section>
    <section class="laboratories">
        <div class="lab_rows">
            @if(!empty($cities['laboratory'][0]))
                @foreach($cities['laboratory'] as $data)
                        <?php
                        $catSlug = !empty($data['laboratoryCategory']['slug'][$currentLang]) ? $data['laboratoryCategory']['slug'][$currentLang] : null;
                        $slug = !empty($data['slug'][$currentLang]) ? $data['slug'][$currentLang] : null;
                        ?>
                    <div class="lab">
                        <div class="lab_img">
                            <img src="{{ asset('uploads/laboratory/'.$data['image']) }}" alt="{{ !empty($data['title'][$currentLang])? $data['title'][$currentLang]: null }}" />
                        </div>
                        <h5>{{ !empty($data['title'][$currentLang])? $data['title'][$currentLang]: null }}</h5>
                        <div class="lab_name">
                            <p>{!! !empty($data['text'][$currentLang])? $data['text'][$currentLang]: null !!}</p>
                            <div class="line"></div>
                            <a href="@if(!empty($data['slug'][$currentLang])) {{ route('site.laboratoryDetails',['catSlug' => $catSlug, 'slug' => $slug]) }} @endif" class="btn">
                                <span>@lang('site.more')</span>
                                <img src="{{ asset('site/assets/images/svg/arrow_classic.svg') }}" alt="" />
                            </a>
                        </div>
                    </div>
                @endforeach
            @endif
        </div>
    </section>
@endsection
@section('site.js')
    <script src="{{ asset("site/assets/js/laboratories.js") }}"></script>
@endsection
