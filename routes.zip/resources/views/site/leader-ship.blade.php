@extends('site.layouts.app')
@section('site.title')
    {{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset('site/assets/css/team.css') }}" />
@endsection
@section('site.content')
    <section class="container-fluid team">
        <div class="row">
            <h1>{{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}</h1>
            @if(!empty($institutePage[0]) && isset($institutePage[0]))
                @foreach($institutePage as $institute)
                    <h3>{{ $institute['title'][$currentLang] }}</h3>
                    <div class="underline"></div>
                    <div class="team_row">
                        @foreach($institute['leadership'] as $data)
                            @if($data['category_id'] == $instituteCategory['id'])
                            <div class="team_member" data-id="{{ $data['id'] }}">
                            <div class="img_wrapper">
                                <img src="{{ asset('uploads/institute/leadership/'.$data->image) }}" alt="{{ !empty($data['full_name'][$currentLang])? $data['full_name'][$currentLang]: null }}">
                                <button type="button" onclick="openShowMore()">Ətraflı</button>
                            </div>
                            <h4>{{ !empty($data['full_name'][$currentLang])? $data['full_name'][$currentLang]: null }}</h4>
                            <span>{{ !empty($data['parent']['title'][$currentLang]) ? $data['parent']['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}</span>
                        </div>
                            @endif
                        @endforeach
                    </div>
                @endforeach
            @endif
        </div>
    </section>
    @if(!empty($institutePage[0]) && isset($institutePage[0]))
        @foreach($institutePage as $institute)
            @foreach($institute['leadership'] as $data)
                @if($data['category_id'] == $instituteCategory['id'])
            <div class="show_more_team_member" data-id="{{$data['id']}}">
                <div class="close" onclick="closeShowMore()">
                    <img src="{{ asset('site/assets/images/svg/close.svg') }}" alt="close" />
                </div>
                <div>
                    <div class="img_wrapper_more">
                        <img src="{{ asset('uploads/institute/leadership/'.$data->image) }}" alt="{{ !empty($data['full_name'][$currentLang])? $data['full_name'][$currentLang]: null }}">
                    </div>
                </div>
                <div class="team_member_text">
                    <h2>{{ !empty($data['full_name'][$currentLang])? $data['full_name'][$currentLang]: null }}</h2>
                    <span>{{ !empty($data['parent']['title'][$currentLang]) ? $data['parent']['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}</span>
                    <div class="underline" style="margin: 12px 0 0 0"></div>
                    <div class="team_member_info">
                        {!! !empty($data['fulltext'][$currentLang])? $data['fulltext'][$currentLang]: null !!}
                    </div>
                </div>
            </div>
                @endif
            @endforeach
        @endforeach
    @endif
@endsection
@section('site.js')
    <script src="{{ asset('site/assets/js/team.js') }}"></script>
@endsection
