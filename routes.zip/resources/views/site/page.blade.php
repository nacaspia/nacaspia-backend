@extends('site.layouts.app')
@section('site.title')
    {{ !empty($page['title'][$currentLang]) ? $page['title'][$currentLang]: null }}
@endsection
@section('site.css')
    @if (!empty($page['parent_id']) && $page['page_type'] == 'slider')
    <link rel="stylesheet" href="{{ asset("site/assets/css/about.css") }}" />
    @elseif(!empty($page['parent_id']) && $page['page_type'] === 'file_content')
        <link rel="stylesheet" href="{{ asset("site/assets/css/useful.css") }}" />
    @elseif (!empty($page['parent_id']) && $page['page_type'] == 'image_content')
        <link rel="stylesheet" href="{{ asset("site/assets/css/cooperation.css") }}" />
    @endif
@endsection
@section('site.content')
    @if (!empty($page['parent_id']) && $page['page_type'] == 'slider')
        <section class="container-fluid about_us">
            <div class="row">
                <div class="about_section">
                    <div class="col-md-5">
                        <h1>{!! !empty($pageContent['title'][$currentLang])? $pageContent['title'][$currentLang]: NULL !!}</h1>
                    </div>
                    <div class="col-md-6">
                        <p>{!! !empty($pageContent['text'][$currentLang])? $pageContent['text'][$currentLang]: NULL  !!}</p>
                    </div>
                </div>
            </div>
        </section>
        @if(!empty($pageContent['slider_image'][0]))
            <section>
                <div class="swiper">
                    <div class="swiper-wrapper">
                        @foreach($pageContent['slider_image'] as $slider_image)
                            <div class="swiper-slide">
                                <div href="" class="about_div">
                                    <img src="{{ asset('uploads/pages/slider_image/'.$slider_image) }}" alt="AQTI" />
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </section>
        @endif
        <section class="container-fluid about_text">
            {!! !empty($pageContent['fulltext'][$currentLang])? $pageContent['fulltext'][$currentLang]: NULL  !!}
        </section>
    @elseif (!empty($page['parent_id']) && $page['page_type'] == 'file_content')
        <section class="container-fluid">
            <div class="row useful_section">
                <h1>{{ !empty($page['title'][$currentLang]) ? $page['title'][$currentLang]: null }}</h1>
                <div class="useful_links">
                    @if(!empty($pageContent[0]))
                        @foreach($pageContent as $pageItem)
                            <div class="useful_link">
                                <a href="{{ asset('uploads/pages/file/'.$pageItem->file) }}" target="_blank">
                                    <div class="a_text">
                                        {!! !empty($pageItem['title'][$currentLang]) ? $pageItem['title'][$currentLang]: null !!}
                                    </div>
                                    <div>
                                        <img src="{{ asset("site/assets/images/svg/download.svg") }}" alt="{!! !empty($pageItem['title'][$currentLang]) ? $pageItem['title'][$currentLang]: null !!}" />
                                        <span>@lang('site.download')</span>
                                    </div>
                                </a>

                            </div>
                        @endforeach
                    @endif
                </div>
            </div>
        </section>
    @elseif (!empty($page['parent_id']) && $page['page_type'] == 'image_content')
        <section class="container-fluid cooperation">
            <h1>{{ !empty($page['title'][$currentLang]) ? $page['title'][$currentLang]: null }}</h1>
            <section class="container-fluid news_section">
                <div class="row">
                    <div class="cooperation_row">
                        @if(!empty($pageContent[0]))
                            @foreach($pageContent as $pageKey=>$pageItem)
                                @if(!empty($pageItem->image))
                                        <?php
                                        $pageSlug = !empty($page['slug'][$currentLang]) ? $page['slug'][$currentLang] : null;
                                        $parentSlug = !empty($pageItem['slug'][$currentLang]) ? $pageItem['slug'][$currentLang] : null;
                                        ?>
                                    <a href="@if(!empty($pageItem['slug'][$currentLang])) {{ route('site.pageDetails',['slug'=>$pageSlug,'parentSlug'=>$parentSlug]) }} @endif" class="news">
                                        <div class="news_arrow">
                                            <div class="news_arrow_inner">
                                                <img src="{{ asset('site/assets/images/svg/arrow_black.svg') }}" alt="" />
                                                <img src="{{ asset('site/assets/images/svg/arrow_hover.svg') }}" alt="" class="arrow_hover"/>
                                            </div>
                                        </div>
                                        <div class="news_info">
                                            <div class="news_img">
                                                <img src="{{ asset('uploads/pages/image/'.$pageItem->image) }}" alt="{!! !empty($pageItem['title'][$currentLang])? $pageItem['title'][$currentLang]: null !!}" />
                                            </div>
                                            <div class="news_text">
                                                <h5>{!! !empty($pageItem['title'][$currentLang])? $pageItem['title'][$currentLang]: null !!}</h5>
                                                <div class="moving_text">
                                                    <p>{{ date('d-m-Y H:i', strtotime($pageItem->datetime)) }}</p>
                                                    <p>{!! !empty($pageItem['title'][$currentLang])? substr($pageItem['title'][$currentLang], 0, 200).'...': null !!}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                @endif
                            @endforeach
                        @endif
                    </div>
                </div>
            </section>
        </section>
    @endif
@endsection
@section('site.js')
    @if (!empty($page['parent_id']) && $page['page_type'] == 'slider')
        <script src="{{ asset("site/assets/js/about_us.js") }}"></script>
    @elseif(!empty($page['parent_id']) && $page['page_type'] === 'file_content')
    @elseif (!empty($page['parent_id']) && $page['page_type'] == 'image_content')
        <script src="{{ asset("site/assets/js/home.js") }}"></script>
    @endif
@endsection
