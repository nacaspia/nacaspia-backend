@extends('site.layouts.app')
@section('site.title')
    @lang('site.reception_days')
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset('site/assets/css/reception_days.css') }}" />
@endsection
@section('site.content')
    <section class="container-fluid reception_days">
        <div class="row">
            <h1>@lang('site.reception_days')</h1>
            <div class="toggler">
                <button class="active tab1" onclick="toggleTab('tab1')">@lang('site.reception_leader_ships')</button>
                <button class="tab2" onclick="toggleTab('tab2')">@lang('site.reception_structure')</button>
            </div>
            <div class="content">
                <div id="tab1" class="tab-content active">
                    <div class="table">
                        <div class="table_row table_row_header">
                            <div id="queue">№</div>
                            <div class="data_row data_row_header">
                                <div class="data">@lang('site.full_name')</div>
                                <div class="data">@lang('site.position')</div>
                                <div class="data">@lang('site.reception_date')</div>
                            </div>
                        </div>
                        @if(!empty($leaderShips[0]))
                            @foreach($leaderShips as $leaderKey => $leader)
                                @if(!empty($leader['reception_days'][$currentLang]))
                                <div class="table_row">
                                <div id="queue">{{++$leaderKey}}</div>
                                <div class="data_row">
                                    <div class="data">{!! !empty($leader['full_name'][$currentLang])? $leader['full_name'][$currentLang]: null !!}</div>
                                    <div class="data">{!! !empty($leader['parent']['title'][$currentLang])? $leader['parent']['title'][$currentLang]: null !!}</div>
                                    <div class="data">{!! !empty($leader['reception_days'][$currentLang])? $leader['reception_days'][$currentLang]: null !!}</div>
                                </div>
                            </div>
                                @endif
                            @endforeach
                        @endif
                    </div>
                </div>

                <div id="tab2" class="tab-content">
                    <div class="table">
                        <div class="table_row table_row_header">
                            <div id="queue">№</div>
                            <div class="data_row data_row_header">
                                <div class="data">@lang('site.full_name')</div>
                                <div class="data">@lang('site.position')</div>
                                <div class="data">@lang('site.reception_date')</div>
                            </div>
                        </div>
                        @if(!empty($structures[0]))
                            @foreach($structures as $structureKey => $structure)
                                @if(!empty($structure['reception_days'][$currentLang]))
                                <div class="table_row">
                                    <div id="queue">{{++$structureKey}}</div>
                                    <div class="data_row">
                                        <div class="data">{!! !empty($structure['full_name'][$currentLang])? $structure['full_name'][$currentLang]: null !!}</div>
                                        <div class="data">{!! !empty($structure['parent']['title'][$currentLang])? $structure['parent']['title'][$currentLang]: null !!}</div>
                                        <div class="data">{!! !empty($structure['reception_days'][$currentLang])? $structure['reception_days'][$currentLang]: null !!}</div>
                                    </div>
                                </div>
                                @endif
                            @endforeach
                        @endif
                    </div>
                </div>
            </div>
            <div class="call">
                <div class="call_text">@lang('site.for_contact'):</div>
                <div class="call_number">
                    <div>@lang('site.call_center')- <a href="tel:{{ !empty($setting['phone'])? $setting['phone']: NULL }}">{{ !empty($setting['phone'])? $setting['phone']: NULL }}</a></div>
                    <div>@lang('site.email')- <a href="mailto:{{ !empty($setting['email'])? $setting['email']: NULL }}"> {{ !empty($setting['email'])? $setting['email']: NULL }}</a></div>
                </div>
            </div>
        </div>
    </section>
@endsection
@section('site.js')
    <script src="{{ asset('site/assets/js/reception_days.js') }}"></script>
@endsection
