@extends('site.layouts.app')
@section('site.title')
    @lang('site.home')
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset("site/assets/plugins/jsmap/css/jsmaps.css") }}" />
    <link rel="stylesheet" href="{{ asset("site/assets/css/home.css") }}" />
@endsection
@section('site.content')
    <section class="statistics container-fluid">
        <div class="row">
            <h2 class="wow fadeIn" data-wow-duration="1.5s">
                @lang('site.statistics')
            </h2>
            <div class="statistics-numbers">
                <div class="number wow slideInLeft" data-wow-duration="1.5s">
                    <div class="counter">
                        <span>{{ !empty($setting['accepted_samples'])? $setting['accepted_samples']: 0 }}</span>
                        <div class="stat_img">
                            <img src="{{ asset("site/assets/images/svg/lab.svg") }}" alt="" />
                        </div>
                    </div>
                    <span class="statistics-name">@lang('site.accepted_samples')</span>
                </div>
                <div class="number wow slideInLeft" data-wow-duration="1.5s">
                    <div class="counter">
                        <span>{{ !empty($setting['laboratory_examinations'])? $setting['laboratory_examinations']: 0 }}</span>
                        <div class="stat_img">
                            <img src="{{ asset("site/assets/images/svg/guidance_medical-laboratory.svg") }}" alt="" />
                        </div>
                    </div>
                    <span class="statistics-name">@lang('site.laboratory_examinations')</span>
                </div>

                <div class="number wow slideInRight" data-wow-duration="1.5s">
                    <div class="counter">
                        <span>{{ !empty($setting['trainees'])? $setting['trainees']: 0 }}</span>
                        <div class="stat_img">
                            <img src="{{ asset("site/assets/images/svg/people-group.svg") }}" alt="" />
                        </div>
                    </div>
                    <span class="statistics-name">@lang('site.trainees')</span>
                </div>
                <div class="number wow slideInRight" data-wow-duration="1.5s">
                    <div class="counter">
                        <span>{{ !empty($setting['animal_identification'])? $setting['animal_identification']: 0 }}</span>
                        <div class="stat_img">
                            <img src="{{ asset("site/assets/images/svg/cow-face.svg") }}" alt="" />
                        </div>
                    </div>
                    <span class="statistics-name">@lang('site.animal_identification')</span>
                </div>
            </div>
        </div>
    </section>

    <section class="container-fluid news_section">
        <div class="row">
            <div class="news_header">
                <div>
                    <h2 class="wow slideInLeft" data-wow-duration="1.5s">@lang('site.news')</h2>
                    <p class="sub_header wow slideInLeft" data-wow-duration="1.5s">@lang('site.news_content')</p>
                </div>
                <div class="all_news wow slideInRight" data-wow-duration="1.5s">
                    <?php $catSlug = !empty($newsCategory['slug'][$currentLang]) ? $newsCategory['slug'][$currentLang] : null; ?>
                    <a href="{{ route('site.news',['slug' => $catSlug ]) }}">@lang('site.all_news')</a>
                </div>
            </div>
            <div class="news_row">
                @if(!empty($news[0]))
                    @foreach($news as $newKey=>$newItem)
                            <?php
                            $catSlug = !empty($newsCategory['slug'][$currentLang]) ? $newsCategory['slug'][$currentLang] : null;
                            $slug = !empty($newItem['slug'][$currentLang]) ? $newItem['slug'][$currentLang] : null;
                            ?>
                        <a href="@if(!empty($newItem['slug'][$currentLang])) {{ route('site.newsDetails',['catSlug'=>$catSlug,'slug'=>$slug]) }} @endif" class="news wow slideInRight" data-wow-duration="1.5s" data-wow-delay="0.75s">
                            <div class="news_arrow">
                                <div class="news_arrow_inner">
                                    <img src="{{ asset('site/assets/images/svg/arrow_black.svg') }}" alt="" />
                                    <img src="{{ asset('site/assets/images/svg/arrow_hover.svg') }}" alt="" class="arrow_hover"/>
                                </div>
                            </div>
                            <div class="news_info">
                                <div class="news_img">
                                    <img src="{{ asset('uploads/news/'.$newItem->image) }}" alt="{!! !empty($newItem['title'][$currentLang])? $newItem['title'][$currentLang]: null !!}" />
                                </div>
                                <div class="news_text">
                                    <h5>{!! !empty($newItem['title'][$currentLang])? $newItem['title'][$currentLang]: null !!}</h5>
                                    <div class="moving_text">
                                        <p>{{ date('d-m-Y H:i', strtotime($newItem->datetime)) }}</p>
                                        <p>{!! !empty($newItem['text'][$currentLang])? substr($newItem['text'][$currentLang], 0, 200).'...': null !!}</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    @endforeach
                @endif
            </div>
        </div>
    </section>

    <section class="container-fluid services">
        <div class="row">
            <h2 class="wow slideInLeft">@lang('site.our_services')</h2>
            @if(!empty($services[0]))
                <div class="services_list">
                    <div class="img_services col-sm-12 col-md-6 wow slideInLeft">
                        <div class="img_div">
                            <img id="serviceImage" src="{{ asset('uploads/services/'.$services->first()->image) }}" alt="default_image"/>
{{--                            <div class="square"></div>--}}
                        </div>
                    </div>
                    <div class="services_types container wow slideInRight">
                        @foreach ($services as $service)
                            <a href="{{ route('site.service',$service['slug'][$currentLang]) }}" class="service_card small" data-image="{{ asset('uploads/services/'.$service->image) }}">
                                <span>{{$service['title'][$currentLang]}}</span>
                                <img src="{{ asset('site/assets/images/svg/arrow_white.svg') }}" alt="" />
                            </a>
                        @endforeach
                    </div>
                </div>
            @endif
        </div>
    </section>

    <section class="container-fluid map_section">
        <div class="map_div">
            <div class="map_text wow slideInLeft">
                <h2>@lang('site.laboratories')</h2>
                <p>@lang('site.laboratory_content')</p>
            </div>
            <div class="map_wrapper lab_name">
                <div class="jsmaps-wrapper wow slideInRight" id="az-map"></div>
                <div class="lab_info">
                    <div class="back">
                        <img src="{{ asset('site/assets/images/svg/back.svg') }}" alt="back" />
                    </div>
                    <div class="lab_text">
                        <h6></h6>
                        <p></p>
                        <div class="buttons_module">
                            <a href=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="map_info">
            @foreach($cities as $cityData)
                @if(!empty($cityData['mainLaboratory']))
                        <?php
                        $catSlug = !empty($cityData['mainLaboratory']['laboratoryCategory']['slug'][$currentLang]) ? $cityData['mainLaboratory']['laboratoryCategory']['slug'][$currentLang] : null;
                        $slug = !empty($cityData['mainLaboratory']['slug'][$currentLang]) ? $cityData['mainLaboratory']['slug'][$currentLang] : null;
                        $citySlug = !empty($cityData['slug'][$currentLang]) ? $cityData['slug'][$currentLang] : null;
                        ?>
                    <div class="map_info_content" data-abbreviation="{{$cityData['abbreviation']}}" data-link="@if(!empty($cityData['slug'][$currentLang])) {{ route('site.cityLaboratory',$citySlug) }} @endif">
                        <div class="map_info_title">{{$cityData['mainLaboratory']['title'][$currentLang]}}</div>
                        <div class="map_info_text">{{$cityData['mainLaboratory']['text'][$currentLang]}}</div>
                        <div class="map_info_link"><a href="@if(!empty($cityData['mainLaboratory']['slug'][$currentLang])) {{ route('site.laboratoryDetails',['catSlug' => $catSlug, 'slug' => $slug]) }} @endif">Ətraflı</a></div>
                        @if(count($cityData['laboratory']) > 1)
                            <div class="map_info_link_all">
                                <a href="@if(!empty($cityData['slug'][$currentLang])) {{ route('site.cityLaboratory',$citySlug) }} @endif">@lang('site.all')</a>
                            </div>
                        @endif
                    </div>
                @endif
            @endforeach
        </div>
    </section>

    <section class="container-fluid tariffs">
        <div class="row">
            <h2>@lang('site.tariffs')</h2>
            <div class="tariffs_row">
                @if(!empty($tariffCategory[0]))
                    @foreach($tariffCategory as $tariffCat)
                        <a href="{{ !empty($tariffCat['link'])? $tariffCat['link']: route('site.tariffDetails',['slug' => $tariffCat['slug'][$currentLang]]) }}" class="tariff @if($tariffCategory->first()) wow slideInRight @endif" target="_blank">
                            <img src="{{ asset('site/assets/images/svg/arrow_white.svg') }}" alt="" class="arrow_tariffs"/>
                            <img src="{{ asset('uploads/tariff-category/'.$tariffCat->image) }}" alt="" class="tariffs_img"/>
                            <span class="tariff_text">{{$tariffCat['title'][$currentLang]}}</span>
                        </a>
                    @endforeach
                @endif
            </div>
        </div>
    </section>

    <section class="container-fluid education_part">
        <div class="row">
            <div class="news_header">
                <div>
                    <h2 class="wow slideInLeft" data-wow-duration="1.5s">
                        @lang('site.education')
                    </h2>
                    <p class="sub_header wow slideInLeft" data-wow-duration="1.5s">
                        @lang('site.education_content')
                    </p>
                </div>
                <div class="all_news wow slideInRight" data-wow-duration="1.5s">
                    <a href="{{ route('site.enlightenment') }}">@lang('site.all')</a>
                </div>
            </div>
            <div class="news_row wow slideInRight" data-wow-duration="1.5s" data-wow-delay="0.5s">
                @if(!empty($enlightenments[0]))
                    @foreach($enlightenments as $enlightenment)
                            <?php $slug = !empty($enlightenment['slug'][$currentLang]) ? $enlightenment['slug'][$currentLang] : null;?>
                        <a href="@if(!empty($enlightenment['slug'][$currentLang])) {{ route('site.enlightenmentDetails',['slug' => $slug]) }}@endif" class="education_card">
                            <div class="education_img">
                                <img src="{{ asset('uploads/enlightenment/'.$enlightenment->image) }}" alt="{!! !empty($enlightenment['title'][$currentLang])? $enlightenment['title'][$currentLang]: null !!}" />
                            </div>
                            <div class="education_text">
                                <h5>
                                    {!! !empty($enlightenment['title'][$currentLang])? $enlightenment['title'][$currentLang]: NULL !!}
                                </h5>
                                <span>{!! date('d-m-Y\TH:i', strtotime($enlightenment->datetime)) !!}</span>
                                <p>{!! !empty($enlightenment['text'][$currentLang])? $enlightenment['text'][$currentLang]: NULL !!}</p>
                            </div>
                        </a>
                    @endforeach
                @endif
            </div>
        </div>
    </section>

    <section class="container-fluid diet_part">
        <div class="row">
            <h2 class="wow slideInLeft" data-wow-duration="1.5s">@lang('site.diet_part')</h2>
            <div class="diet">
                @if(!empty($healthyEating[0]))
                    <div class="diet_types wow slideInLeft" data-wow-duration="1.5s">
                        @foreach($healthyEating as $healthy)
                            <a href="{{$healthy['link']}}" class="diet_card" data-image="{{ asset('uploads/healthyEating/'.$healthy->image) }}">
                                <img src="{{ asset('site/assets/images/svg/arrow_white.svg') }}" alt="{{ !empty($healthy['title'][$currentLang])? $healthy['title'][$currentLang]: null }}" />
                                <span>{{ !empty($healthy['title'][$currentLang])? $healthy['title'][$currentLang]: null }}</span>
                            </a>
                        @endforeach
                    </div>
                    <div class="diet_img wow slideInRight" data-wow-duration="1.5s">
                        <img
                            id="dietImage"
                            src="{{ asset('uploads/healthyEating/'.$healthyEating->first()->image) }}"
                            alt="default_diet_image"
                        />
                    </div>
                @endif
            </div>
        </div>
    </section>

    <section class="container-fluid link_part">
        <div class="row">
            <h2 class="wow slideInLeft" data-wow-duration="1.5s">@lang('site.useful_links')</h2>
            <div>
                <div class="swiper wow slideInRight" data-wow-duration="1.5s">
                    <div class="swiper-wrapper">
                        @if(!empty($usefulLink[0]))
                            @foreach($usefulLink as $link)
                                <div class="swiper-slide">
                                    <a href="{{$link->link}}" class="link_div" target="_blank">
                                        <img src="{{ asset('uploads/usefulLink/'.$link->image) }}" alt="{{ !empty($link['title'][$currentLang])? $link['title'][$currentLang]: null }}" />
                                    </a>
                                </div>
                            @endforeach
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
@section('site.js')
    <script src="{{ asset("site/assets/plugins/jquery/jquery-3.6.0.min.js") }}"></script>
    <script src="{{ asset("site/assets/plugins/jsmap/js/jsmaps-libs.js") }}"></script>
    <script src="{{ asset("site/assets/plugins/jsmap/js/jsmaps-panzoom.js") }}"></script>
    <script src="{{ asset("site/assets/plugins/jsmap/js/jsmaps.min.js") }}"></script>
    <script>
        window.JSMaps.maps.azerbaijan = {
            config: {
                strokeColor: "#808080",
            },
            paths: [
                    <?php foreach ($cities as $cityKey => $cityValue){ ?>
                {
                    enable: <?php echo !empty($cityValue['mainLaboratory']) ? 1 : 0; ?>,
                    name: "<?php echo $cityValue['name']['az']; ?><br><span class='laboratory-text'><?php echo !empty($cityValue['mainLaboratory']) ? $cityValue['mainLaboratory']['title']['az'] : ''; ?></span>",
                    abbreviation: "<?php echo $cityValue['abbreviation']; ?>",
                    textX: 0,
                    textY: 0,
                    color: "#F6F6F6",
                    hoverColor: "#B9DDB4",
                    selectedColor: "#B9DDB4",
                    path: "<?php echo $cityValue['path']; ?>",
                },
                <?php } ?>
            ],
            pins: [
                    <?php foreach ($cities as $cityKey => $cityValue){
                    if (!empty($cityValue['mainLaboratory'])) { ?>
                {
                    name: "<?php echo $cityValue['name']['az']; ?><br><span class='laboratory-text'><?php echo $cityValue['mainLaboratory']['title']['az']; ?></span>",
                    abbreviation: "<?php echo $cityValue['abbreviation']; ?>",
                    xPos: <?php echo $cityValue['xPos']; ?>,
                    yPos: <?php echo $cityValue['yPos']; ?>,
                    src: "/site/assets/images/svg/pin_map.svg",
                    srcWidth: 41,
                    srcHeight: 58,
                },
                <?php }} ?>
            ]
        };
    </script>


    {{--    <script src="{{ asset("site/assets/plugins/jsmap/maps/azerbaijan.js") }}"></script>--}}
    <script src="{{ asset("site/assets/js/home.js") }}"></script>
@endsection
