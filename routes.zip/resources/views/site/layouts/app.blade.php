<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>AQTİ- @yield('site.title')</title>
    <link rel="stylesheet" href="{{ asset("site/assets/css/reset.css") }}" />
    <link rel="stylesheet" href="{{ asset("site/assets/plugins/bootstrap/css/bootstrap.min.css") }}"/>
    <link rel="stylesheet" href="{{ asset("site/assets/plugins/swiper/css/swiper-bundle.min.css") }}"/>
    <link rel="stylesheet" href="{{ asset("site/assets/plugins/wow/css/animate.css") }}" />
    <link rel="stylesheet" href="{{ asset("site/assets/css/main.css") }}" />
    @yield('site.css')
</head>
<body>
<x-site.header />
@yield('site.content')
<x-site.footer />
