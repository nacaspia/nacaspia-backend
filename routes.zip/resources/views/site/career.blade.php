@extends('site.layouts.app')
@section('site.title')
@lang('site.career')
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset('site/assets/css/career.css') }}" />
@endsection
@section('site.content')
    <section class="container-fluid career_header">
        <div class="career_header_text">
            <h1>@lang('site.career_apply')</h1>
            <p>@lang('site.career_content')</p>
            <a href="{{ route('site.careerApply',['slug' => 'apply']) }}">@lang('site.career_apply')</a>
        </div>
        <div class="career_circle1">
            <img src="{{ asset('site/assets/images/career_header_img.png') }}" alt="" />
        </div>
        <div class="career_circle2">
            <img src="{{ asset('site/assets/images/career_header_img.png') }}" alt="" />
        </div>
        <div class="career_circle3">
            <img src="{{ asset('site/assets/images/career_header_img.png') }}" alt="" />
        </div>
        <div class="career_circle4">
            <img src="{{ asset('site/assets/images/career_header_img.png') }}" alt="" />
        </div>
    </section>

    <section class="container-fluid vacancies">
        <h1>@lang('site.activity_vacancy')</h1>
        <div class="vacancies_row">
            @if(!empty($career[0]) && isset($career[0]))
                @foreach($career as $data)
                    <div class="vacancy_card">
                        <h4>{{ !empty($data['title'][$currentLang]) ? $data['title'][$currentLang]: null }}</h4>
                        <div class="vacancy_date">
                            @lang('site.career_datetime') <span>{{ date('d-m-Y', strtotime($data->datetime)) }}</span> <span>{{ date('TH:i', strtotime($data->datetime)) }}</span>
                        </div>
                        <a href="{{ route('site.careerApply',['slug' => !empty($data['slug'][$currentLang]) ? $data['slug'][$currentLang]: null]) }}">
                            @lang('site.more')
                            <img src="{{ asset('site/assets/images/svg/show_more.svg') }}" alt="" />
                        </a>
                    </div>
                @endforeach
            @endif
        </div>
    </section>
@endsection
@section('site.js')
@endsection
