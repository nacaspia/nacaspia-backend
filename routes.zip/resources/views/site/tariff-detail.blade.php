@extends('site.layouts.app')
@section('site.title')
    {{$tariffCategory['title'][$currentLang]?? null}}
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset('site/assets/css/veterinary.css') }}" />
@endsection
@section('site.content')
    <section class="veterinary">
        <h1>{{$tariffCategory['title'][$currentLang]?? null}}</h1>
        <div class="search_div">
            <input type="text" name="search" id="search" placeholder="@lang('site.search')" />
        </div>
        <div class="table">
            <div class="table_row table_row_header">
                <div id="queue">№</div>
                <div class="data_row data_row_header">
                    <div class="data data_name">@lang('site.tariff_name')</div>
                    <div class="group">
                        <div class="data">@lang('site.unit_of_measure')</div>
                        <div class="data">@lang('site.service_charge')</div>
                    </div>
                </div>
            </div>
            @if($tariffCategory['tariffs'][0])
                @foreach($tariffCategory['tariffs'] as $tariffKey => $tariffValue)
                <div class="table_row">
                    <div id="queue">{{++$tariffKey}}</div>
                    <div class="data_row data_row_header">
                        <div class="data data_name">{!! $tariffValue['title'][$currentLang] ?? null !!}</div>
                        <div class="group">
                            <div class="data">{!! $tariffValue['unit_of_measure'][$currentLang] ?? null !!}</div>
                            <div class="data">{!! $tariffValue['service_charge'][$currentLang]?? null !!}</div>
                        </div>
                    </div>
                </div>
                    @if(!empty($tariffValue['parentTariff'][0]))
                        @foreach($tariffValue['parentTariff'] as $parentTariffKey => $parentTariffValue)
                            <div class="table_row">
                                <div id="queue">{{$tariffKey}}.{{++$parentTariffKey}}</div>
                                <div class="data_row data_row_header">
                                    <div class="data data_name">{!! $parentTariffValue['title'][$currentLang] ?? null !!}</div>
                                    <div class="group">
                                        <div class="data">{!! $parentTariffValue['unit_of_measure'][$currentLang] ?? null !!}</div>
                                        <div class="data">{!! $parentTariffValue['service_charge'][$currentLang]?? null !!}</div>
                                    </div>
                                </div>
                            </div>
                            @if(!empty($parentTariffValue['subParentTariff'][0]))
                                @foreach($parentTariffValue['subParentTariff'] as $subParentTariffKey => $subParentTariffValue)
                                    <div class="table_row">
                                        <div id="queue">{{$tariffKey}}.{{$parentTariffKey}}.{{++$subParentTariffKey}}</div>
                                        <div class="data_row data_row_header">
                                            <div class="data data_name">{!! $subParentTariffValue['title'][$currentLang] ?? null !!}</div>
                                            <div class="group">
                                                <div class="data">{!! $subParentTariffValue['unit_of_measure'][$currentLang] ?? null !!}</div>
                                                <div class="data">{!! $subParentTariffValue['service_charge'][$currentLang]?? null !!}</div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            @endif
                        @endforeach
                    @endif
                @endforeach
            @endif
        </div>

        <div id="no-results" style="display: none">
            @lang('site.not_data')
        </div>
    </section>
@endsection
@section('site.js')
    <script src="{{ asset('site/assets/js/veterinary.js') }}"></script>
@endsection
