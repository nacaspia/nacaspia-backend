@extends('site.layouts.app')
@section('site.title')
    {{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset("site/assets/css/about.css") }}" />
@endsection
@section('site.content')
    <section class="container-fluid about_us">
        <div class="row">
            <div class="about_section">
                <div class="col-md-5">
                    <h1>{!! !empty($institutePage['title'][$currentLang])? $institutePage['title'][$currentLang]: NULL !!}</h1>
                </div>
                <div class="col-md-6">
                    <p>{!! !empty($institutePage['text'][$currentLang])? $institutePage['text'][$currentLang]: NULL  !!}</p>
                </div>
            </div>
        </div>
    </section>
    @if(!empty($institutePage['slider_image'][0]))
    <section>
        <div class="swiper">
            <div class="swiper-wrapper">
                @foreach($institutePage['slider_image'] as $slider_image)
                    <div class="swiper-slide">
                    <div href="" class="about_div">
                        <img src="{{ asset('uploads/institute/abouts/'.$slider_image) }}" alt="AQTI" />
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>
    @endif
    <section class="container-fluid about_text">
        {!! !empty($institutePage['fulltext'][$currentLang])? $institutePage['fulltext'][$currentLang]: NULL  !!}
    </section>
@endsection
@section('site.js')
    <script src="{{ asset("site/assets/js/about_us.js") }}"></script>
@endsection
