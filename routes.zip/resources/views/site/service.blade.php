@extends('site.layouts.app')
@section('site.title')
    {{ !empty($service['title'][$currentLang]) ? $service['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.service') }}
@endsection
@section('site.css')
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{ asset('site/assets/css/service.css') }}" />
    <link rel="stylesheet" href="{{ asset('site/assets/css/calculator.css') }}" />
    @if(!empty($service['files'][0]))
        <link rel="stylesheet" href="{{ asset("site/assets/css/useful.css") }}" />
    @endif
@endsection
@section('site.content')
    @if(!empty($service['parentCategories'][0]))
        <div class="linkedTabs">
            @foreach($service['parentCategories'] as $parentCategories)
                <a class="linkedTab" href="{{ route('site.service',$parentCategories['slug'][$currentLang]) }}">{{ !empty($parentCategories['title'][$currentLang])? $parentCategories['title'][$currentLang]: null }}</a>
            @endforeach
        </div>
    @endif
    @if(!empty($service['image']))
        <section class="container-fluid service_page">
            <div class="calculator_section">
                <div class="service_text_calculator">
                    <h1>{{ !empty($service['title'][$currentLang]) ? $service['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.service') }}</h1>
                    <div class="service_img service_img_responsive">
                        <img src="{{ asset('uploads/services/'.$service->image) }}" alt="{{ !empty($service['title'][$currentLang]) ? $service['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.service') }}" />
                    </div>
                    {!! !empty($service['text'][$currentLang]) ? $service['text'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.service') !!}
                    <button id="apply-btn">Müraciət et</button>
                </div>
                @if($service['is_calculator'] ===1)
                    <div class="calculator">
                        <h3>@lang('site.calculator')</h3>
                        <div class="calculator_values">
                            <div class="calculator_values-row">
                                <div class="box">
                                    <p>@lang('site.branch_count')</p>
                                    <h6 id="value1" contenteditable="true">10</h6>
                                    <input type="range" min="0" max="100" value="10" class="slider" id="slider1"/>
                                </div>
                                <div class="box">
                                    <p>@lang('site.total_employees')</p>
                                    <h6 id="value2" contenteditable="true">200</h6>
                                    <input type="range" min="0" max="10000" value="200" class="slider" id="slider2"/>
                                </div>
                            </div>
                            <div class="calculator_values-row">
                                <div class="box">
                                    <p>@lang('site.haccp_count')</p>
                                    <h6 id="value3" contenteditable="true">200</h6>
                                    <input
                                        type="range"
                                        min="0"
                                        max="1000"
                                        value="200"
                                        class="slider"
                                        id="slider3"
                                    />
                                </div>
                                <div class="box">
                                    <p>@lang('site.product_variety')</p>
                                    <h6 id="value4" contenteditable="true">10</h6>
                                    <input type="range" min="0" max="200" value="10" class="slider" id="slider4"/>
                                </div>
                            </div>
                        </div>
                        <div class="calculator_values-text">
                            <div class="input">
                                <label for="">@lang('site.activity_category')</label>
                                <div class="custom-select-wrapper" id="TY">
                                    <div class="custom-select" tabindex="1">
                              <span class="custom-select-trigger">@lang('site.select')
                                <div class="custom-select-arrow">
                                  <img src="{{ asset("site/assets/images/svg/dropdown.svg") }}" alt="" />
                                </div>
                              </span>
                                        <ul class="custom-options">
                                            <li class="custom-option" data-value="option0" data-weight="0">@lang('site.select')</li>
                                            @if(!empty($trainings[0]))
                                                @foreach($trainings as $activityKey => $activityType)
                                                    @if($activityType['type'] == 'activity-category')
                                                        <li class="custom-option" data-value="option{{++$activityKey}}" data-weight="{{ $activityType['weight'] }}">{{$activityType['title'][$currentLang]}}</li>
                                                    @endif
                                                @endforeach
                                            @endif
                                        </ul>
                                    </div>
                                    <select name="custom-select" class="hidden-select">
                                        <option value="option0"></option>
                                        @if(!empty($trainings[0]))
                                            @foreach($trainings as $activityKey => $activityType)
                                                @if($activityType['type'] == 'activity-category')
                                                    <option value="option{{++$activityKey}}"></option>
                                                @endif
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="input">
                                <label for="">@lang('site.complexity_group'):</label>
                                <div class="custom-select-wrapper" id="CC">
                                    <div class="custom-select" tabindex="1">
                              <span class="custom-select-trigger">@lang('site.select')
                                <div class="custom-select-arrow">
                                  <img src="{{ asset("site/assets/images/svg/dropdown.svg") }}" alt="" />
                                </div>
                              </span>
                                        <ul class="custom-options">
                                            <li class="custom-option" data-value="option0" data-weight="0">@lang('site.select')</li>
                                            @if(!empty($trainings[0]))
                                                @foreach($trainings as $complexityKey => $complexityType)
                                                    @if($complexityType['type'] == 'complexity-group')
                                                        <li class="custom-option" data-value="option{{++$complexityKey}}" data-weight="{{ $complexityType['weight'] }}">{{$complexityType['title'][$currentLang]}}</li>
                                                    @endif
                                                @endforeach
                                            @endif
                                        </ul>
                                    </div>
                                    <select name="custom-select" class="hidden-select">
                                        <option value="option0"></option>
                                        @if(!empty($trainings[0]))
                                            @foreach($trainings as $complexityKey => $complexityType)
                                                @if($complexityType['type'] == 'complexity-group')
                                                    <option value="option{{++$complexityKey}}"></option>
                                                @endif
                                            @endforeach
                                        @endif
                                    </select>
                                </div>
                            </div>
                            <div class="input_row">
                                <div class="input">
                                    <label for="">@lang('site.certification_type'):</label>
                                    <div class="custom-select-wrapper">
                                        <div class="custom-select" tabindex="1">
                                    <span class="custom-select-trigger custom-select-trigger-certificate">Seç
                                      <div class="custom-select-arrow">
                                        <img src="{{ asset("site/assets/images/svg/dropdown.svg") }}" alt="" />
                                      </div>
                                    </span>
                                            <ul class="custom-options custom-options-certificate">
                                                @if(!empty($trainings[0]))
                                                    @foreach($trainings as $certificationKey => $certificationType)
                                                        @if($certificationType['type'] == 'certification-type')
                                                            <li class="custom-option" data-value="option{{++$certificationKey}}" data-weight="{{ $certificationType['weight'] }}">{{$certificationType['title'][$currentLang]}}</li>
                                                        @endif
                                                    @endforeach
                                                @endif
                                            </ul>
                                        </div>
                                        <select name="custom-select" class="hidden-select">
                                            @if(!empty($trainings[0]))
                                                @foreach($trainings as $certificationKey => $certificationType)
                                                    @if($certificationType['type'] == 'certification-type')
                                                        <option value="option{{++$certificationKey}}"></option>
                                                    @endif
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                <div class="person_per_day">
                                    <span> @lang('site.certification_duration'):</span>
                                    <div class="person_per_day-amount">
                                        <span class="person_per_day-amount-count">0</span>
                                        <span>@lang('site.person_per_day')</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="total-result">
                            @lang('site.final_amount') <span></span>
                        </div>
                        <div class="calc_formula">
                            <p>
                                @lang('site.note1')
                            </p>
                            <p>
                                @lang('site.note2')
                            </p>
                            <p>
                                @lang('site.note3')
                            </p>
                        </div>
                    </div>
                @endif
            </div>
            <div class="service_img_calculator">
                <img src="{{ asset('uploads/services/'.$service->image) }}" alt="{{ !empty($service['title'][$currentLang]) ? $service['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.service') }}" />
            </div>
        </section>
        <div class="service_modal">
            <div class="service_form">
                <div class="close_head">
                    <div class="close_img">
                        <img src="{{ asset('site/assets/images/svg/close.svg') }}" alt="close" />
                    </div>
                </div>
                <div class="form_scroll">
                    <form id="form" enctype="multipart/form-data">
                        <input type="hidden" name="service_id" id="service_id" value="{{$service['id']}}">
                        <div class="input">
                            <label for="name">@lang('site.applicant_name'):</label>
                            <input type="text" name="full_name" id="full_name" required />
                        </div>
                        <div class="input">
                            <label for="adress">@lang('site.company_name'):</label>
                            <input type="text" name="company_name" id="address" required />
                        </div>

                        <div class="input">
                            <label for="region">@lang('site.regional_section'):</label>
                            <input type="text" name="region_name" id="region_name" required />
                        </div>
                        <div class="input">
                            <label for="veen">@lang('site.tax_id'):</label>
                            <input type="text" name="tin_enterprise" id="tin_enterprise" required />
                        </div>
                        <div class="file_wrapper">
                            <div class="file_wrapper_title cvTitle">@lang('site.application_sample'):</div>
                            <label class="cv-upload">
                                <input type="file" name="application_example" id="application_example" accept=".pdf,.doc,.docx"/>
                                <div class="file-info" style="display: none">
                                    <span class="cvFileName"></span>
                                    <button type="button" class="remove-button">@lang('site.delete')</button>
                                </div>
                            </label>
                        </div>
                        @if($service['is_service_type'] ===1)
                            <div class="service_type_form">
                                <p>@lang('site.service_type'):</p>
                                <div class="service_type_tabs">
                                    <div id="tab1" class="tab">@lang('site.service_tab_1')</div>
                                    <div id="tab2" class="tab">@lang('site.service_tab_2')</div>
                                </div>
                                <div class="input tab1_value hidden">
                                    <label for=""></label>
                                    <div class="custom-select-wrapper">
                                        <div class="custom-select" tabindex="1">
                                    <span class="custom-select-trigger">
                                      @lang('site.select')
                                      <div class="custom-select-arrow">
                                        <img src="{{ asset('site/assets/images/svg/dropdown.svg') }}" alt="" />
                                      </div>
                                    </span>
                                            <ul class="custom-options">
                                                <li class="custom-option" data-value="option0">@lang('site.select')</li>
                                                @if(!empty($trainings[0]))
                                                    @foreach($trainings as $training)
                                                        @if($training['type'] == 'advisory-consulting')
                                                            <li class="custom-option" data-value="{{$training['title'][$currentLang]}}">{{$training['title'][$currentLang]}}</li>
                                                        @endif
                                                    @endforeach
                                                @endif
                                            </ul>
                                        </div>
                                        <select class="hidden-select" name="advisory_consulting" id="advisory_consulting">
                                            <option value="option0">@lang('site.select')</option>
                                            @if(!empty($trainings[0]))
                                                @foreach($trainings as $training)
                                                    @if($training['type'] == 'advisory-consulting')
                                                        <option value="{{$training['title'][$currentLang]}}"></option>
                                                    @endif
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                <div class="input tab2_value hidden">
                                    <label for=""></label>
                                    <div class="custom-select-wrapper">
                                        <div class="custom-select" tabindex="1">
                                    <span class="custom-select-trigger">
                                      @lang('site.select')
                                      <div class="custom-select-arrow">
                                        <img src="{{ asset('site/assets/images/svg/dropdown.svg') }}" alt="" />
                                      </div>
                                    </span>
                                            <ul class="custom-options">
                                                <li class="custom-option" data-value="option0">@lang('site.select')</li>
                                                @if(!empty($trainings[0]))
                                                    @foreach($trainings as $training)
                                                        @if($training['type'] == 'evaluation')
                                                            <li class="custom-option" data-value="{{$training['title'][$currentLang]}}">{{$training['title'][$currentLang]}}</li>
                                                        @endif
                                                    @endforeach
                                                @endif
                                            </ul>
                                        </div>
                                        <select class="hidden-select"  name="evaluation" id="evaluation">
                                            <option value="option0">@lang('site.select')</option>
                                            @if(!empty($trainings[0]))
                                                @foreach($trainings as $training)
                                                    @if($training['type'] == 'evaluation')
                                                        <option value="{{$training['title'][$currentLang]}}"></option>
                                                    @endif
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                            </div>
                        @endif
                        <div class="input">
                            <label for="number">@lang('site.email'):</label>
                            <input type="email" name="email" id="email" value=""  required/>
                        </div>
                        <div class="input">
                            <label for="number">@lang('site.phone'):</label>
                            <input type="tel" name="phone" id="phone" value="+994" pattern="\+994\d*" required/>
                        </div>
                        <div class="input">
                            <label for="bank">@lang('site.bank_visits'):</label>
                            <input type="text" name="bank_visits" id="bank_visits" required />
                        </div>
                        <div class="input">
                            <label for="note">@lang('site.note'):</label>
                            <textarea name="note" id="note" required></textarea>
                        </div>
                        <button type="submit" class="submit_btn">@lang('site.send')</button>
                        <div id="overlay" class="overlay hidden"></div>
                    </form>
                </div>
            </div>
        </div>
    @elseif(!empty($service['files'][0]))
        <section class="container-fluid">
            <div class="row useful_section">
                <h1>{{ !empty($service['title'][$currentLang]) ? $service['title'][$currentLang]: null }}</h1>
                <div class="useful_links">
                    @foreach($service['files'] as $file)
                        <div class="useful_link">
                            <a href="{{ asset('uploads/service/files/'.$file) }}" target="_blank">
                                <div class="a_text">
                                    {!! $file !!}
                                </div>
                                <div>
                                    <img src="{{ asset("site/assets/images/svg/download.svg") }}" alt="{!! !empty($file) ? $file: null !!}" />
                                    <span>@lang('site.download')</span>
                                </div>
                            </a>

                        </div>
                    @endforeach
                </div>
            </div>
        </section>
    @endif
    <div id="overlay" class="overlay hidden"></div>
    <div id="overlay" class="overlay"></div>
    <div id="s_overlay" class="s_overlay hidden"></div>
    <div class="action_popup">
        <div class="close_popup">
            <img src="/site/assets/images/svg/close.svg" alt="close" />
        </div>
        <div class="action">
            <div class="action_img">~
                <img src="" alt="" />
            </div>
        </div>
        <div class="action_text">
            <p></p>
        </div>
    </div>
@endsection
@section('site.js')
    <script src="{{ asset('site/assets/js/service.js') }}"></script>
    <script src="{{ asset('site/assets/js/calculator.js') }}"></script>
@endsection
