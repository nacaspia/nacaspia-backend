@extends('site.layouts.app')
@section('site.title')
@lang('site.write_to_we')
@endsection
@section('site.css')
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{ asset('site/assets/css/write_us.css') }}" />
@endsection
@section('site.content')
    <section class="container-fluid">
        <div class="row write_us">
            <div class="info_write_us">
                <div class="write_us_text">
                <h1>@lang('site.contact_about')</h1>
                <div class="info">
                    <div class="info_row">
                        <span class="info_title_write">@lang('site.address'):</span>
                        <span class="adress adress_write">{{ !empty($setting['address'][$currentLang])? $setting['address'][$currentLang]: NULL }}</span>
                    </div>

                    <div class="info_row">
                        <span class="info_title_write">@lang('site.phone'):</span>
                        <div class="info_numbers info_numbers_write">
                            <a href="tel:+994123770020">(+994 12) 377 00 20</a>
                            <a href="tel:+994123770021">(+994 12) 377 00 21</a>
                        </div>
                    </div>

                    <div class="info_row">
                        <span class="info_title_write">@lang('site.email'):</span>
                        <span>
                  <a href="mailto:{{ !empty($setting['email'])? $setting['email']: NULL }}" class="email email_write">{{ !empty($setting['email'])? $setting['email']: NULL }}</a>
                </span>
                    </div>
                </div>
                </div>
                <div class="write_us_map">
                    <iframe
                        src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d638.4649143589584!2d49.84312851264617!3d40.42949147823856!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4030891672637a91%3A0xe9c6d10f9ebc510a!2zQXrJmXJiYXljYW4gUWlkYSBUyZlobMO8a8mZc2l6bGl5aSDEsG5zdGl0dXR1!5e0!3m2!1sen!2saz!4v1732033880480!5m2!1sen!2saz"
                        width="600"
                        height="540"
                        style="border: 0"
                        allowfullscreen=""
                        loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"
                    ></iframe>
                </div>
            </div>
            <div class="form_div">
                <div class="write_us_text write_us_text_responsive">
                    <h1>@lang('site.contact_about')</h1>
                    <div class="info">
                        <div class="info_row">
                            <span class="info_title_write">@lang('site.address'):</span>
                            <span class="adress adress_write">{{ !empty($setting['address'][$currentLang])? $setting['address'][$currentLang]: NULL }}</span>
                        </div>

                        <div class="info_row">
                            <span class="info_title_write">@lang('site.phone'):</span>
                            <div class="info_numbers info_numbers_write">
                                <a href="tel:+994123770020">(+994 12) 377 00 20</a>
                                <a href="tel:+994123770021">(+994 12) 377 00 21</a>
                            </div>
                        </div>

                        <div class="info_row">
                            <span class="info_title_write">@lang('site.email'):</span>
                            <span>
                                <a href="mailto:{{ !empty($setting['email'])? $setting['email']: NULL }}" class="email email_write">{{ !empty($setting['email'])? $setting['email']: NULL }}</a>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="form_write_us">
                    <h2>@lang('site.write_contact')</h2>
                    <form id="form">
                        <div class="input">
                            <label for="name">@lang('site.name')</label>
                            <input type="text" class="validate"  name="name" id="name" required />
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Ad qeyd edilməli.
                            </small>
                        </div>
                        <div class="input">
                            <label for="name">@lang('site.surname')</label>
                            <input type="text" class="validate"  name="surname" id="surname" required />
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Soyad qeyd edilməli.
                            </small>
                        </div>
                        <div class="input">
                            <label for="email">@lang('site.email')</label>
                            <input type="email" class="validate"  id="email" size="30" name="email" placeholder="example@example.com" required/>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                E-poçt qeyd edilməli.
                            </small>
                        </div>
                        <div class="input">
                            <label for="phone">@lang('site.phone')</label>
                            <input type="tel" class="validate"  name="phone" id="phone" value="+994" required/>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Əlaqə vasitəsi qeyd edilməli.
                            </small>
                        </div>
                        <div class="input">
                            <label for="note">@lang('site.note')</label>
                            <textarea type="text" class="validate"  name="note" id="note" required></textarea>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Təklifiniz qeyd edilməli.
                            </small>
                        </div>
                        <div class="submit_div">
                            <button type="submit" class="submit_btn">@lang('site.send')</button>
                        </div>
                        <div id="overlay" class="overlay hidden"></div>
                        <div class="action_popup">
                            <div class="close_popup">
                                <a href="{{ route('site.contact') }}"><img src="{{ asset('site/assets/images/svg/close.svg') }}" alt="close"/></a>
                            </div>
                            <div class="action">
                                <div class="action_img">
                                    <img src="" alt="" />
                                </div>
                            </div>
                            <div class="action_text">
                                <p></p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
@endsection
@section('site.js')
    <script src="{{ asset('site/assets/js/write_us.js') }}"></script>
@endsection
