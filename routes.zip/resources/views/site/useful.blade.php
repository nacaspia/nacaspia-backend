@extends('site.layouts.app')
@section('site.title')
    {{ !empty($usefulCategory['title'][$currentLang]) ? $usefulCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.useful') }}
@endsection
@section('site.css')
    @if($usefulCategory['page_type'] === 'files')
    <link rel="stylesheet" href="{{ asset("site/assets/css/useful.css") }}" />
    @elseif($usefulCategory['page_type'] === 'file_content')
    <link rel="stylesheet" href="{{ asset('site/assets/css/hiqs.css') }}" />
    @elseif($usefulCategory['page_type'] === 'image_content')
    <link rel="stylesheet" href="{{ asset('site/assets/css/cooperation.css') }}" />
    @endif
@endsection
@section('site.content')
    @if($usefulCategory['page_type'] === 'files')
        <section class="container-fluid">
            <div class="row useful_section">
                <h1>{{ !empty($usefulCategory['title'][$currentLang]) ? $usefulCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.useful') }}</h1>
                <div class="useful_links">
                    @if(!empty($useful[0]))
                        @foreach($useful as $usefulItem)
                            <div class="useful_link">
                                <a href="{{ asset('uploads/useful/file/'.$usefulItem->file) }}" target="_blank">
                                    <div class="a_text">
                                        {!! !empty($usefulItem['title'][$currentLang]) ? $usefulItem['title'][$currentLang]: null !!}
                                    </div>
                                    <div>
                                        <img src="{{ asset("site/assets/images/svg/download.svg") }}" alt="{!! !empty($usefulItem['title'][$currentLang]) ? $usefulItem['title'][$currentLang]: null !!}" />
                                        <span>@lang('site.download')</span>
                                    </div>
                                </a>

                            </div>
                        @endforeach
                    @endif
                </div>
            </div>
        </section>
    @elseif($usefulCategory['page_type'] === 'file_content')
        <section class="container-fluid hiqs_section">
            <h1>{{ !empty($usefulCategory['title'][$currentLang]) ? $usefulCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.useful') }}</h1>
            @if($usefulCategory['id'] === 14)<div class="info">@lang('site.hiqs')</div>@endif
            <div class="pdf_file">
                <div class="row">
                    <div class="files">
                        @if(!empty($useful[0]))
                            @foreach($useful as $usefulItem)
                            <a href="{{ !empty($usefulItem->link)? $usefulItem->link: asset('uploads/useful/file/'.$usefulItem->file) }}" @if(empty($usefulItem->link)) download @endif class="download_button">
                                <div class="pdf_img">
                                    <img src="{{ asset("site/assets/images/svg/pdf.svg") }}" alt="">
                                </div>
                                <div class="a_text">
                                    {!! !empty($usefulItem['title'][$currentLang]) ? $usefulItem['title'][$currentLang]: null !!}
                                </div>
                                @if(empty($usefulItem->link))
                                <div>
                                    <img src="{{ asset("site/assets/images/svg/download.svg") }}" alt="{!! !empty($usefulItem['title'][$currentLang]) ? $usefulItem['title'][$currentLang]: null !!}" />
                                    <span>@lang('site.download')</span>
                                </div>
                                @endif
                            </a>
                            @endforeach
                        @endif
                    </div>
                </div>
            </div>
        </section>
    @elseif($usefulCategory['page_type'] === 'image_content')
        <section class="container-fluid cooperation">
            <h1>{{ !empty($usefulCategory['title'][$currentLang]) ? $usefulCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.useful') }}</h1>
            <section class="container-fluid news_section">
                <div class="row">
                    <div class="cooperation_row">
                        <?php $catSlug = !empty($usefulCategory['slug'][$currentLang]) ? $usefulCategory['slug'][$currentLang]: null; ?>
                        @if(!empty($useful[0]))
                            @foreach($useful as $usefulItem)
                                <?php $slug = !empty($usefulItem['slug'][$currentLang]) ? $usefulItem['slug'][$currentLang]: null; ?>
                                <a href="{{ route('site.usefulDetail',['catSlug' => $catSlug, 'slug' => $slug ]) }}" class="news">
                                    <div class="news_arrow">
                                        <div class="news_arrow_inner">
                                            <img src="{{ asset('site/assets/images/svg/arrow_black.svg') }}" alt="" />
                                            <img src="{{ asset('site/assets/images/svg/arrow_hover.svg') }}" alt="" class="arrow_hover"/>
                                        </div>
                                    </div>
                                    <div class="news_info">
                                        <div class="news_img">
                                            <img src="{{ asset('uploads/useful/image/'.$usefulItem->image) }}" alt="{!! !empty($usefulItem['title'][$currentLang])? $usefulItem['title'][$currentLang]: null !!}" />
                                        </div>
                                        <div class="news_text">
                                            <h5>{!! !empty($usefulItem['title'][$currentLang]) ? $usefulItem['title'][$currentLang]: null !!}</h5>
                                            <div class="moving_text">
                                                <p>{!! !empty($usefulItem['text'][$currentLang]) ? $usefulItem['text'][$currentLang]: null !!}</p>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            @endforeach
                        @endif
                    </div>
                </div>
            </section>
        </section>
    @endif
@endsection
@section('site.js')
    @if($usefulCategory['page_type'] === 'image_content')
        <script src="{{ asset('site/assets/js/cooperation.js') }}"></script>
    @endif
@endsection
