@extends('site.layouts.app')
@section('site.title')
    {{ !empty($career['title'][$currentLang]) ? $career['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('site.career_apply') }}
@endsection
@section('site.css')
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{ asset('site/assets/css/apply.css') }}" />
@endsection
@section('site.content')
    <section class="container-fluid apply1">
        <div class="row">
            <h1>@lang('site.apply_form')</h1>
            <div class="steps_div">
                <div class="step active">
                    <div class="number">01</div>
                    <span>@lang('site.about_your')</span>
                </div>
                <div class="step">
                    <div class="number">02</div>
                    <span>@lang('site.educations')</span>
                </div>
                <div class="step">
                    <div class="number">03</div>
                    <span>@lang('site.work')</span>
                </div>
                <div class="step">
                    <div class="number">04</div>
                    <span>@lang('site.lang_skill')</span>
                </div>
                <div class="step">
                    <div class="number">05</div>
                    <span>@lang('site.other')</span>
                </div>
            </div>
        </div>
    </section>

    <section class="container-fluid">
        <div class="row">
            <form id="form" enctype="multipart/form-data">
                <input type="hidden" name="career_id" id="career_id" value="{{ !empty($career['id']) ? $career['id']: null }}">
                <input type="hidden" name="is_vacancy" id="is_vacancy" value="1">
                <div class="slide active">
                    <div class="form_wrapper">
                        <div class="input">
                            <label for="name">@lang('site.name')</label>
                            <input type="text" class="validate" name="name" id="name" required />
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Ad qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input">
                            <label for="surname">@lang('site.surname')</label>
                            <input type="text" class="validate" name="surname" id="surname" required />
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Soyadı qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input">
                            <label for="patronymic">@lang('site.father_name')</label>
                            <input type="text" class="validate" name="patronymic" id="patronymic" required />
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Ata adı qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input">
                            <label for="number">@lang('site.phone')</label>
                            <input type="tel" class="validate" name="number" id="number" value="" required/>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Əlaqə nömrəsi qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input">
                            <label for="adress">@lang('site.address_city_region')</label>
                            <input class="validate" type="text" name="adress" id="adress" required />
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Ünvan qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input">
                            <label for="email">@lang('site.email')</label>
                            <input type="email" class="validate" id="email" size="30" name="email" placeholder="example@example.com" required/>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                E-poçt qeyd edilməlidir.
                            </small>
                        </div>
                    </div>
                </div>

                <div class="slide no-gap">
                    <div class="form_wrapper">
                        <div class="form_row education-row">
                            <div class="input">
                                <label for="education_org">@lang('site.education_org')</label>
                                <input class="validate" type="text" name="education_org" id="education_org" required/>
                                <small class="error-message" style="color: red; display: none; font-size: 12px">
                                    Təhsil müəssisəsi qeyd edilməlidir.
                                </small>
                            </div>
                            <div class="input">
                                <label for="start-date">@lang('site.start_date')</label>
                                <div class="date-input-wrapper">
                                    <input type="date" name="start-date" class="date-input start-date" max="3000-12-31" placeholder="gün/ay/il" onchange="updateEndDateMin(this, '.end-date-edu')"/>
                                </div>
                            </div>
                            <div class="input">
                                <label for="end-date">@lang('site.end_date')</label>
                                <div class="date-input-wrapper">
                                    <input type="date" name="end-date" id="end-date" class="date-input end-date-edu" max="3000-12-31">
                                </div>
                            </div>
                        </div>
                        <div class="add_button">@lang('site.add')</div>
                    </div>
                </div>

                <div class="slide no-gap">
                    <div class="form_wrapper">
                        <div class="form_row work-row">
                            <div class="input">
                                <label for="institution_org">@lang('site.institution_org')</label>
                                <input type="text" class="validate" name="institution_org" id="institution_org" required/>
                                <small class="error-message" style="color: red; display: none; font-size: 12px">
                                    Müəssisə adı qeyd edilməlidir.
                                </small>
                            </div>
                            <div class="input">
                                <label for="position">@lang('site.position')</label>
                                <input type="text" class="validate" name="position" id="position" required />
                                <small class="error-message" style="color: red; display: none; font-size: 12px">
                                    Vəzifə qeyd edilməlidir.
                                </small>
                            </div>
                            <div class="input">
                                <label for="start-date-work">@lang('site.work_start_date')</label>
                                <div class="date-input-wrapper">
                                    <input type="date" name="start-date-work" id="start-date-work" class="date-input start-date" max="3000-12-31" onchange="updateEndDateMin(this, '.end-date-work')"/>
                                </div>
                            </div>
                            <div class="sub_row">
                                <div class="input">
                                    <label for="end-date-work">@lang('site.work_end_date')</label>
                                    <div class="date-input-wrapper">
                                        <input type="date" name="end-date-work" id="end-date-work" class="date-input end-date-work" max="3000-12-31"/>
                                    </div>
                                </div>
                                <div class="input">
                                    <label for="leaving_reason">@lang('site.leaving_reason')</label>
                                    <textarea type="text" name="leaving_reason" id="leaving_reason" required></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="add_button">@lang('site.add')</div>
                    </div>
                </div>

                <div class="slide">
                    <div class="form_wrapper">
                        <div class="language-form" id="languageForm">
                            @foreach($languages as $language)
                                <div class="language-row">
                                    <label for="{{$language}}">{{ ucfirst($language) }}</label>
                                    <div class="radio-group">
                                        <label id="excellent">
                                            <input type="checkbox" name="{{$language}}" value="Əla" />
                                            <span></span>
                                        </label>
                                        <label id="good">
                                            <input type="checkbox" name="{{$language}}" value="Yaxşı" />
                                            <span></span>
                                        </label>
                                        <label id="poor">
                                            <input type="checkbox" name="{{$language}}" value="Zəif" />
                                            <span></span>
                                        </label>
                                        <label id="idk">
                                            <input type="checkbox" name="{{$language}}" value="Bilmirəm" />
                                            <span></span>
                                        </label>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                <div class="slide">
                    <div class="form_wrapper">
                        <div class="file-upload-container">
                            <div class="file_wrapper">
                                <div class="file_wrapper_title photoTitle">@lang('site.add_image')</div>
                                <label class="file-input" id="photoInput">
                                    <input type="file" name="photoInput" accept="image/*"/>
                                    <div class="placeholder">
                                        <img src="" alt="" id="photoPreview" style="display: none"/>
                                    </div>
                                </label>
                            </div>

                            <div class="file_wrapper">
                                <div class="file_wrapper_title cvTitle">@lang('site.add_cv')</div>
                                <label class="cv-upload" id="cvInput">
                                    <input type="file" name="cvInput" accept=".pdf,.doc,.docx" required/>
                                    <div class="file-info" style="display: none">
                                        <span id="cvFileName"></span>
                                        <button type="button" class="remove-button" id="removeCvButton">@lang('site.delete')</button>
                                    </div>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="buttons_slider">
                    <div class="next_button"><button class="previous">@lang('site.previous')</button></div>
                    <div class="next_button"><button class="next">@lang('site.next')</button></div>
                </div>
                <div id="overlay" class="s_overlay hidden"></div>
                <div class="action_popup">
                    <div class="close_popup">
                        <a href="{{ route('site.careerApply',['slug' => 'apply']) }}"><img src="{{ asset('site/assets/images/svg/close.svg') }}" alt="close"/></a>
                    </div>
                    <div class="action">
                        <div class="action_img">
                            <img src="" alt="" />
                        </div>
                    </div>
                    <div class="action_text">
                        <p></p>
                    </div>
                </div>
            </form>
        </div>
    </section>
@endsection
@section('site.js')
    <script>
        window.languages = @json(config('languages.languages'));
    </script>
    <script src="{{ asset('site/assets/js/apply.js') }}"></script>
@endsection
