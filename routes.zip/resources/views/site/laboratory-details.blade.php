@extends('site.layouts.app')
@section('site.title')
    {{ !empty($laboratory['title'][$currentLang]) ? $laboratory['title'][$currentLang]: null }}
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset("site/assets/css/cooperation_inner.css") }}" />
@endsection
@section('site.content')
    <?php
    $catSlug = !empty($laboratoryCategory['slug'][$currentLang]) ? $laboratoryCategory['slug'][$currentLang] : null;
    $slug = !empty($laboratory['slug'][$currentLang]) ? $laboratory['slug'][$currentLang] : null;
    $shareUrl = url()->current() . '/laboratory/'. '/'. $catSlug . '/' . $slug;
    ?>
    <div>
        <ol class="breadcrumb">
            <li><a href="{{ route('site.laboratory',[ 'slug' => $catSlug ]) }}">{{ !empty($laboratoryCategory['title'][$currentLang]) ? $laboratoryCategory['title'][$currentLang]: null }}</a></li>
            <li>
                <a href="{{ route('site.laboratoryDetails',[ 'catSlug' => $catSlug, 'slug' => $slug ]) }}">{{ !empty($laboratory['title'][$currentLang]) ? $laboratory['title'][$currentLang]: null }}</a>
            </li>
        </ol>
    </div>
    <section class="container-fluid cooperation_inner">
        <div class="row">
            <h1>{{ !empty($laboratory['title'][$currentLang]) ? $laboratory['title'][$currentLang]: null }}</h1>
            <div class="slide_show">
                <div class="slide_show_main_image">
                    <img src="{{ asset('uploads/laboratory/'.$laboratory->image) }}" alt="{{ !empty($laboratory['title'][$currentLang]) ? $laboratory['title'][$currentLang]: null }}" />
                </div>
                @if(!empty($laboratory['slider_image']))
                    <div class="slide_show_images">
                        @foreach($laboratory['slider_image'] as $slider_image)
                            <div class="slide_show_image">
                                <img src="{{ asset('uploads/laboratory/slider_image/'.$slider_image) }}" alt="" data-id="1" />
                            </div>
                        @endforeach
                    </div>
                @endif
            </div>
            <div class="text_cooperation">
{{--                <div class="date"><span>{{ date('d-m-Y', strtotime($laboratory->datetime)) }}</span> <span>{{ date('H:i', strtotime($laboratory->datetime)) }}</span></div>--}}
                <div class="text_info">
                    {!! !empty($laboratory['fulltext'][$currentLang]) ? $laboratory['fulltext'][$currentLang]: null  !!}
                </div>
            </div>
        </div>
    </section>

    <section class="container-fluid social_media_block_section">
        <div class="row">
            <div class="social_media_block">
                <div class="social_media_header">@lang('site.share'):</div>

                <div class="social_media_icons">
                    <div class="social_media_icon">
                        <a href="mailto:?subject=Faydalı məqalə&body={{ urlencode($shareUrl) }}"><img src="{{ asset('site/assets/images/svg/cooperation_inner_email.svg') }}" alt="email"/></a>
                    </div>
                    <div class="social_media_icon">
                        <a href="https://twitter.com/intent/tweet?url={{ urlencode($shareUrl) }}&text=Bu%20maraqlı%20məqaləyə%20baxın"><img src="{{ asset('site/assets/images/svg/cooperation_inner_x.svg') }}" alt="x"/></a>
                    </div>
                    <div class="social_media_icon">
                        <a href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode($shareUrl) }}" target="_blank" rel="noopener noreferrer">
                            <img src="{{ asset('site/assets/images/svg/cooperation_inner_facebook.svg') }}" alt="facebook"/>
                        </a>
                    </div>
                    <div class="social_media_icon">
                        <a href="https://www.youtube.com/?url={{ urlencode($shareUrl) }}"><img src="{{ asset('site/assets/images/svg/cooperation_inner_youtube.svg') }}" alt="youtube"/></a>
                    </div>
                    <div class="social_media_icon">
                        <a href="https://www.linkedin.com/sharing/share-offsite/?url={{ urlencode($shareUrl) }}" target="_blank" rel="noopener noreferrer">
                            <img src="{{ asset('site/assets/images/svg/cooperation_inner_linkedin.svg') }}" alt="linkedin"/>
                        </a>
                    </div>
                    <div class="social_media_icon">
                        <a href="https://www.instagram.com/?url={{ urlencode($shareUrl) }}" target="_blank" rel="noopener noreferrer">
                            <img src="{{ asset('site/assets/images/svg/cooperation_inner_instagram.svg') }}" alt="instagram"/>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
@section('site.js')
    <script src="{{ asset("site/assets/js/cooperation_inner.js") }}"></script>
@endsection
