@extends('site.layouts.app')
@section('site.title')
    {{ !empty($newsCategory['title'][$currentLang]) ? $newsCategory['title'][$currentLang]: null }}
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset("site/assets/css/cooperation.css") }}" />
@endsection
@section('site.content')
    <section class="container-fluid cooperation">
        <h1>{{ !empty($newsCategory['title'][$currentLang]) ? $newsCategory['title'][$currentLang]: null }}</h1>
        <section class="container-fluid news_section">
            <div class="row">
                <div class="cooperation_row">
                    @if(!empty($newsCategory['news'][0]))
                        @foreach($newsCategory['news'] as $newKey=>$newItem)
                            @if(!empty($newItem->image))
                            <?php
                            $catSlug = !empty($newsCategory['slug'][$currentLang]) ? $newsCategory['slug'][$currentLang] : null;
                            $slug = !empty($newItem['slug'][$currentLang]) ? $newItem['slug'][$currentLang] : null;
                            ?>
                            <a href="@if(!empty($newItem['slug'][$currentLang])) {{ route('site.newsDetails',['catSlug'=>$catSlug,'slug'=>$slug]) }} @endif" class="news">
                                <div class="news_arrow">
                                    <div class="news_arrow_inner">
                                        <img src="{{ asset('site/assets/images/svg/arrow_black.svg') }}" alt="" />
                                        <img src="{{ asset('site/assets/images/svg/arrow_hover.svg') }}" alt="" class="arrow_hover"/>
                                    </div>
                                </div>
                                <div class="news_info">
                                    <div class="news_img">
                                        <img src="{{ asset('uploads/news/'.$newItem->image) }}" alt="{!! !empty($newItem['title'][$currentLang])? $newItem['title'][$currentLang]: null !!}" />
                                    </div>
                                    <div class="news_text">
                                        <h5>{!! !empty($newItem['title'][$currentLang])? $newItem['title'][$currentLang]: null !!}</h5>
                                        <div class="moving_text">
                                            <p>{{ date('d-m-Y H:i', strtotime($newItem->datetime)) }}</p>
                                            <p>{!! !empty($newItem['title'][$currentLang])? substr($newItem['title'][$currentLang], 0, 200).'...': null !!}</p>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            @endif
                        @endforeach
                    @endif
                </div>
            </div>
        </section>
    </section>
    @if(!empty($newsCategory['news'][0]) && isset($newsCategory['news'][0]))
        {{ $newsCategory['news']->appends(request()->except('page'))->links('components.site.pagination',['posts' => $newsCategory['news']]) }}
    @endif
@endsection
@section('site.js')
    <script src="{{ asset("site/assets/js/home.js") }}"></script>
@endsection
