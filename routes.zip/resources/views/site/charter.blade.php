@extends('site.layouts.app')
@section('site.title')
    {{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}
@endsection
@section('site.css')
    <link rel="stylesheet" href="{{ asset("site/assets/css/bylaws.css") }}" />
@endsection
@section('site.content')
    <section class="container-fluid bylaws">
        <div class="row">
            <h2>{!! !empty($institutePage['title'][$currentLang])? $institutePage['title'][$currentLang]: NULL !!}</h2>
            <div class="bylaws_name">
                <p class="bylaws_paragraph_name"></p>
            </div>

            <div class="bylaws_text">
                {!! !empty($institutePage['fulltext'][$currentLang])? $institutePage['fulltext'][$currentLang]: NULL !!}
            </div>
        </div>
    </section>

    <section class="container-fluid pdf_file">
        <div class="row">
            <a href="{{ asset('uploads/institute/charter/'.$institutePage['file'] ) }}" download class="download_button">
                {!! !empty($institutePage['text'][$currentLang])? $institutePage['text'][$currentLang]: NULL !!}
                <div>
                    <img src="{{ asset('site/assets/images/svg/download.svg') }}" alt="PDF" />
                    <span>Yüklə</span>
                </div>
            </a>
        </div>
    </section>
@endsection
@section('site.js')
@endsection
