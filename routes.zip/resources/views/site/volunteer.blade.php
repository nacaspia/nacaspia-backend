@extends('site.layouts.app')
@section('site.title')
    @lang('site.volunteer')
@endsection
@section('site.css')
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{ asset('site/assets/css/apply.css') }}" />
@endsection
@section('site.content')
    <section class="container-fluid apply1">
        <div class="row">
            <h1>@lang('site.volunteer')</h1>
            <p class="descr">@lang('site.volunteer_content')</p>
            <div class="steps_div">
                <div class="step active">
                    <div class="number">01</div>
                    <span>@lang('site.about_your')</span>
                </div>
                <div class="step">
                    <div class="number">02</div>
                    <span>@lang('site.educations')</span>
                </div>
                <div class="step">
                    <div class="number">03</div>
                    <span>@lang('site.lang_skill')</span>
                </div>
                <div class="step">
                    <div class="number">04</div>
                    <span>@lang('site.other')</span>
                </div>
            </div>
        </div>
    </section>
    <section class="container-fluid">
        <div class="row">
            <form id="form" enctype="multipart/form-data">
                <div class="slide active">
                    <div class="form_wrapper">
                        <div class="input">
                            <label for="name">@lang('site.name')</label>
                            <input type="text" class="validate" name="name" id="name" required />
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Ad qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input">
                            <label for="surname">@lang('site.surname')</label>
                            <input type="text" class="validate" name="surname" id="surname" required />
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Soyad qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input">
                            <label for="patronymic">@lang('site.father_name')</label>
                            <input type="text" class="validate" name="patronymic" id="patronymic" required />
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Valdeyn adı qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input">
                            <label for="dob">@lang('site.birthday')</label>
                            <div class="date-input-wrapper">
                                <input type="date" class="validate" name="dob" id="dob" class="date-input" />
                            </div>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Doğum tarixi qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input">
                            <label for="gender">@lang('site.gender')</label>
                            <div class="custom-select">
                                <select id="gender-select" class="validate" name="gender" required>
                                    <option value="" disabled selected>@lang('site.choose_gender')</option>
                                    <option value="male">@lang('site.male')</option>
                                    <option value="female">@lang('site.female')</option>
                                </select>
                            </div>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Cins qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input">
                            <label for="number">@lang('site.phone')</label>
                            <input type="tel" class="validate" name="number" id="number" value="" required/>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Əlaqə vasitəsi qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input">
                            <label for="email">@lang('site.email')</label>
                            <input type="email" class="validate" id="email" size="30" name="email" placeholder="example@example.com" required/>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                E-poçt qeyd edilməlidir.
                            </small>
                        </div>
                        <div></div>
                        <div class="input large">
                            <label for="adress">@lang('site.voluntary_address')</label>
                            <input type="text" class="validate" name="adress" id="adress" required />
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Ünvan qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input large">
                            <label for="actual-address">@lang('site.actual_address')</label>
                            <input type="text" class="validate" name="actual_address" id="actual_address" required/>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Faktiki ünvan qeyd edilməlidir.
                            </small>
                        </div>
                    </div>
                </div>

                <div class="slide">
                    <div class="form_wrapper education-row">
                        <div class="input large">
                            <label for="education_org">@lang('site.education_org')</label>
                            <input type="text" class="validate" name="education_org" id="education_org" required/>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Təhsil müəssisəsi qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input">
                            <label for="start-date">@lang('site.start_date')</label>
                            <div class="date-input-wrapper">
                                <input type="date" name="start-date" id="start-date" class="date-input"/>
                            </div>

                        </div>
                        <div class="input">
                            <label for="end-date">@lang('site.end_date')</label>
                            <div class="date-input-wrapper">
                                <input type="date" name="end-date" id="end-date" class="date-input"/>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="slide">
                    <div class="form_wrapper">
                        <div class="language-form" id="languageForm">
                            @foreach($languages as $language)
                                <div class="language-row">
                                    <label for="{{$language}}">{{ ucfirst($language) }}</label>
                                    <div class="radio-group">
                                        <label id="excellent">
                                            <input type="checkbox" name="{{$language}}" value="Əla" />
                                            <span></span>
                                        </label>
                                        <label id="good">
                                            <input type="checkbox" name="{{$language}}" value="Yaxşı" />
                                            <span></span>
                                        </label>
                                        <label id="poor">
                                            <input type="checkbox" name="{{$language}}" value="Zəif" />
                                            <span></span>
                                        </label>
                                        <label id="idk">
                                            <input type="checkbox" name="{{$language}}" value="Bilmirəm" />
                                            <span></span>
                                        </label>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                <div class="slide">
                    <div class="form_wrapper">
                        <div class="input large">
                            <label for="expectations">@lang('site.expectations')</label>
                            <input type="text" class="validate" name="volunteer_expectations" id="volunteer_expectations" required/>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Gözləntiləriniz qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input large">
                            <label for="differences">@lang('site.differences')</label>
                            <input type="text" class="validate" name="volunteer_differences" id="volunteer_differences" required/>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                Fərqləndirən cəhət qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input large">
                            <label for="voluntary">@lang('site.voluntary')</label>
                            <div class="voluntary_radio">
                                <label>
                                    <input type="radio" class="validate" name="voluntary" id="voluntary" value="Bəli" /> @lang('site.yes')
                                </label>
                                <label>
                                    <input type="radio" class="validate" name="voluntary" id="voluntary" value="Xeyr" /> @lang('site.no')
                                </label>
                                <label>
                                    <input type="radio" class="validate" name="voluntary" value="Digər" id="voluntary_other"/>@lang('site.other')
                                </label>
                            </div>
                            <input type="text" name="voluntary_other_text" id="voluntary_other_text" disabled/>
                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                @lang('site.voluntary') cəhət qeyd edilməlidir.
                            </small>
                        </div>
                        <div class="input large">
                            <label for="leaving_reason">@lang('site.voluntary_leaving_reason')</label>
                            <textarea type="text" class="validate" name="volunteer_leaving_reason" id="leaving_reason" required></textarea>

                            <small class="error-message" style="color: red; display: none; font-size: 12px">
                                @lang('site.voluntary_leaving_reason') cəhət qeyd edilməlidir.
                            </small>
                        </div>
                    </div>
                </div>

                <div class="buttons_slider">
                    <div class="next_button">
                        <button class="previous">@lang('site.previous')</button>
                    </div>
                    <div class="next_button">
                        <button class="next">@lang('site.next')</button>
                    </div>
                </div>
                <div id="overlay" class="s_overlay  hidden"></div>
                <div class="action_popup">
                    <div class="close_popup"></div>
                    <div class="action">
                        <div class="action_img">
                            <img src="" alt="" />
                        </div>
                    </div>
                    <div class="action_text">
                        <p></p>
                    </div>
                </div>
            </form>
        </div>
    </section>
@endsection
@section('site.js')
    <script>
        window.languages = @json(config('languages.languages'));
    </script>
    <script src="{{ asset('site/assets/js/volunteer.js') }}"></script>
@endsection
