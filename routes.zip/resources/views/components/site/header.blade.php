<a href="#top" class="arrow_to_top">
    <img src="{{ asset('site/assets/images/svg/arrow_white.svg') }}" alt="arrow" />
</a>
@if(Route::currentRouteName() === 'site.index')
    <section class="container-fluid no_overflow">
        <div class="row">
            <div class="header_one" id="top">
                <div class="connect">
                    <div class="dropdown">
                        <button class="dropbtn" id="selectedLanguage">
                            {{ ucwords($currentLang) }}
                            <img src="{{ asset("site/assets/images/svg/union-1.png") }}" alt="" />
                        </button>
                        <div class="dropdown-content">
                            @foreach($languages as $localeCode => $properties)
                                @if($properties['code'] != $currentLang)
                                    <a href="{{ LaravelLocalization::getLocalizedURL($properties['code'], route('site.index')) }}" hreflang="{{ $properties['code'] }}">
                                        {{ ucwords($properties['code']) }}
                                    </a>
                                @endif
                            @endforeach
                        </div>
                    </div>
                    <div class="phone">
                        <img src="{{ asset("site/assets/images/svg/phone.svg") }}" alt="" />
                        <span><a href="tel:+{{ !empty($setting['phone'])? $setting['phone']: NULL }}">{{ !empty($setting['phone'])? $setting['phone']: NULL }}</a></span>
                    </div>
                    <div class="social_media">
                        <a href="mailto:{{ !empty($setting['email'])? $setting['email']: NULL }}" target="_blank" aria-label="Email">
                            <img src="{{ asset("site/assets/images/svg/email.svg") }}" alt="Email" />
                        </a>
                        <a href="{{ !empty($setting['twitter'])? $setting['twitter']: NULL }}" target="_blank" aria-label="X">
                            <img src="{{ asset("site/assets/images/svg/x.svg") }}" alt="X" />
                        </a>
                        <a href="{{ !empty($setting['facebook'])? $setting['facebook']: NULL }}" target="_blank" aria-label="Facebook">
                            <img src="{{ asset("site/assets/images/svg/facebook.svg") }}" alt="Facebook" />
                        </a>
                        <a href="{{ !empty($setting['youtube'])? $setting['youtube']: NULL }}" target="_blank" aria-label="YouTube">
                            <img src="{{ asset("site/assets/images/svg/youtube.svg") }}" alt="YouTube" />
                        </a>
                        <a href="{{ !empty($setting['linkedin'])? $setting['linkedin']: NULL }}" target="_blank" aria-label="LinkedIn">
                            <img src="{{ asset("site/assets/images/svg/linkedin.svg") }}" alt="LinkedIn" />
                        </a>
                        <a href="{{ !empty($setting['instagram'])? $setting['instagram']: NULL }}" target="_blank" aria-label="Instagram">
                            <img src="{{ asset("site/assets/images/svg/instagram.svg") }}" alt="Instagram" />
                        </a>
                    </div>
                </div>
                <div class="search-container">
                    <form action="{{ route('site.search') }}" style="display: flex; align-items: center; width: 100%;!important;">
                        <input type="text"  name="q" placeholder="Axtar" class="search-input" value="{{ !empty($_GET['q'])? $_GET['q']: '' }}" />
                        <button class="search-button" aria-label="Search">
                            <img src="{{ asset("site/assets/images/svg/magnifier.svg") }}" alt="Search"/>
                        </button>
                    </form>
                </div>
                <div class="header_one_buttons">
                    <div class="career_sub_menu">
                        <a class="karyera_btn" href="#">@lang('site.career')</a>
                        <div class="career_dropdown">
                            <ul>
                                <li><a href="{{ route('site.career') }}">@lang('site.vacancies')</a></li>
                                <li><a href="{{ route('site.volunteer') }}">@lang('site.volunteer')</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="career_sub_menu lab_sub_menu">
                        <a href="" class="karyera_btn button_link">@lang('site.virtual_laboratory')</a>
                        <div class="career_dropdown lab_dropdown">
                            <ul>
                                @if(!empty($virtualLaboratory[0]))
                                    @foreach($virtualLaboratory as $virtual)
                                        <li><a href="{{ $virtual['link'] }}" target="_blank">{{!empty($virtual['title'][$currentLang])? $virtual['title'][$currentLang]: null}}</a></li>
                                    @endforeach
                                @endif
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="container-fluid main">
        <div class="row">
            <div class="main_menu">
                <a href="{{ route('site.index') }}" class="main_logo">
                    @if(!empty($setting['header_logo']))
                        <div class="logo_img">
                            <img src="{{ asset('uploads/settings/'.$setting['header_logo']) }}" alt="{{ !empty($setting['title'][$currentLang])? $setting['title'][$currentLang]: NULL }}" />
                        </div>
                    @endif
                    <div class="logo_text">
                        {{ !empty($setting['title'][$currentLang])? $setting['title'][$currentLang]: NULL }}
                    </div>
                </a>
                <button class="menu-toggle" aria-label="Open menu">
                    <div class="div_menu_responsive">
                        <img src="{{ asset("site/assets/images/svg/responsive_menu.svg") }}" alt="" />
                    </div>
                </button>
                <nav class="menu">
                    <ul class="menu-level">
                        <li class="menu-item">
                            <a href="#">@lang('site.institute')</a>
                            @if(!empty($instituteCategory[0]))
                                <ul class="submenu">
                                    @foreach($instituteCategory as $key => $instituteCat)
                                        <li class="submenu-item">
                                            <a href="{{ route('site.institute',$instituteCat['slug'][$currentLang]) }}">{{ !empty($instituteCat['title'][$currentLang])? $instituteCat['title'][$currentLang]: null }}</a>
                                            @if(!empty($instituteCat['parentCategories'][0]))
                                                <ul class="submenu">
                                                    @foreach($instituteCat['parentCategories'] as $instituteParentCategories)
                                                        @if(empty($instituteParentCategories['subParentCategories'][0]))
                                                            <li class="submenu-item"> <a href="{{ route('site.institute',$instituteParentCategories['slug'][$currentLang]) }}">{{ !empty($instituteParentCategories['title'][$currentLang])? $instituteParentCategories['title'][$currentLang]: null }}</a></li>
                                                        @else
                                                            <li class="submenu-item">
                                                                <div class="accordion-menu">
                                                                    <button class="accordion-toggle">{{ !empty($instituteParentCategories['title'][$currentLang])? $instituteParentCategories['title'][$currentLang]: null }}</button>
                                                                    <div class="accordion-header-content">
                                                                        <ul>
                                                                            @foreach($instituteParentCategories['subParentCategories'] as $instituteSubCategories)
                                                                                <li><a href="{{ route('site.institute',$instituteSubCategories['slug'][$currentLang]) }}">{{ !empty($instituteSubCategories['title'][$currentLang])? $instituteSubCategories['title'][$currentLang]: null }}</a></li>
                                                                            @endforeach
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        @endif
                                                    @endforeach
                                                </ul>
                                            @endif
                                        </li>
                                    @endforeach
                                </ul>
                            @endif
                        </li>
                        <li class="menu-item">
                            <a href="#">@lang('site.laboratory')</a>
                            @if(!empty($laboratoryCategory[0]))
                                <ul class="submenu">
                                    @foreach($laboratoryCategory as $key => $laboratoryCat)
                                        <li class="submenu-item">
                                            <a href="{{ route('site.laboratory',$laboratoryCat['slug'][$currentLang]) }}">{{ !empty($laboratoryCat['title'][$currentLang])? $laboratoryCat['title'][$currentLang]: null }}</a>
                                            @if(!empty($laboratoryCat['parentCategories'][0]))
                                                <ul class="submenu">
                                                    @foreach($laboratoryCat['parentCategories'] as $laboratoryParentCategories)
                                                        @if(empty($laboratoryParentCategories['subParentCategories'][0]))
                                                            <li class="submenu-item"> <a href="{{ route('site.laboratory',$laboratoryParentCategories['slug'][$currentLang]) }}">{{ !empty($laboratoryParentCategories['title'][$currentLang])? $laboratoryParentCategories['title'][$currentLang]: null }}</a></li>
                                                        @else
                                                            <li class="submenu-item">
                                                                <div class="accordion-menu">
                                                                    <button class="accordion-toggle">{{ !empty($laboratoryParentCategories['title'][$currentLang])? $laboratoryParentCategories['title'][$currentLang]: null }}</button>
                                                                    <div class="accordion-header-content">
                                                                        <ul>
                                                                            @foreach($laboratoryParentCategories['subParentCategories'] as $laboratorySubCategories)
                                                                                <li><a href="{{ route('site.laboratory',$laboratorySubCategories['slug'][$currentLang]) }}">{{ !empty($laboratorySubCategories['title'][$currentLang])? $laboratorySubCategories['title'][$currentLang]: null }}</a></li>
                                                                            @endforeach
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        @endif
                                                    @endforeach
                                                </ul>
                                            @endif
                                        </li>
                                    @endforeach
                                </ul>
                            @endif
                        </li>
                        <li class="menu-item">
                            <a href="#">@lang('site.services')</a>
                            @if(!empty($services[0]))
                                <ul class="submenu">
                                    @foreach($services as $key => $servicesCat)
                                        <li class="submenu-item">
                                            <a href="{{ route('site.service',$servicesCat['slug'][$currentLang]) }}">{{ !empty($servicesCat['title'][$currentLang])? $servicesCat['title'][$currentLang]: null }}</a>
                                            @if(!empty($servicesCat['parentCategories'][0]))
                                                <ul class="submenu">
                                                    @foreach($servicesCat['parentCategories'] as $servicesParentCategories)
                                                        @if(empty($servicesParentCategories['subParentCategories'][0]))
                                                            <li class="submenu-item"> <a href="{{ route('site.service',$servicesParentCategories['slug'][$currentLang]) }}">{{ !empty($servicesParentCategories['title'][$currentLang])? $servicesParentCategories['title'][$currentLang]: null }}</a></li>
                                                        @else
                                                            <li class="submenu-item">
                                                                <div class="accordion-menu">
                                                                    <button class="accordion-toggle">{{ !empty($servicesParentCategories['title'][$currentLang])? $servicesParentCategories['title'][$currentLang]: null }}</button>
                                                                    <div class="accordion-header-content">
                                                                        <ul>
                                                                            @foreach($servicesParentCategories['subParentCategories'] as $servicesSubCategories)
                                                                                <li><a href="{{ route('site.service',$servicesSubCategories['slug'][$currentLang]) }}">{{ !empty($servicesSubCategories['title'][$currentLang])? $servicesSubCategories['title'][$currentLang]: null }}</a></li>
                                                                            @endforeach
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        @endif
                                                    @endforeach
                                                </ul>
                                            @endif
                                        </li>
                                    @endforeach
                                </ul>
                            @endif
                        </li>
                        <li class="menu-item">
                            <a href="#">@lang('site.useful')</a>
                            @if(!empty($usefulCategory))
                                <ul class="submenu">
                                    @foreach($usefulCategory as $key => $usefulCat)
                                        <li class="submenu-item">
                                            <a href="{{ route('site.useful',$usefulCat['slug'][$currentLang]) }}">{{ !empty($usefulCat['title'][$currentLang])? $usefulCat['title'][$currentLang]: null }}</a>
                                            @if(!empty($usefulCat['parentCategories'][0]))
                                                <ul class="submenu">
                                                    @foreach($usefulCat['parentCategories'] as $usefulParentCategories)
                                                        @if(empty($usefulParentCategories['subParentCategories'][0]))
                                                            <li class="submenu-item"> <a href="{{ route('site.useful',$usefulParentCategories['slug'][$currentLang]) }}">{{ !empty($usefulParentCategories['title'][$currentLang])? $usefulParentCategories['title'][$currentLang]: null }}</a></li>
                                                        @else
                                                            <li class="submenu-item">
                                                                <div class="accordion-menu">
                                                                    <button class="accordion-toggle">{{ !empty($usefulParentCategories['title'][$currentLang])? $usefulParentCategories['title'][$currentLang]: null }}</button>
                                                                    <div class="accordion-header-content">
                                                                        <ul>
                                                                            @foreach($usefulParentCategories['subParentCategories'] as $usefulSubCategories)
                                                                                <li><a href="{{ route('site.useful',$usefulSubCategories['slug'][$currentLang]) }}">{{ !empty($usefulSubCategories['title'][$currentLang])? $usefulSubCategories['title'][$currentLang]: null }}</a></li>
                                                                            @endforeach
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        @endif
                                                    @endforeach
                                                </ul>
                                            @endif
                                        </li>
                                    @endforeach
                                </ul>
                            @endif
                        </li>

                        @if(!empty($pages[0]))
                            @foreach($pages as $page)
                                @if(!empty($page['slug'][$currentLang]))
                                    <li class="menu-item">
                                        <a href="#">{{ !empty($page['title'][$currentLang])? $page['title'][$currentLang]: null }}</a>
                                        <ul class="submenu">
                                            @if(!empty($page['parentPage'][0]))
                                                @foreach($page['parentPage'] as $pageContent)
                                                    @if(!empty($pageContent['slug'][$currentLang]))
                                                        <li class="submenu-item">
                                                            <a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' => null, 'subParentCategories' => null]) }}">{{ !empty($pageContent['title'][$currentLang])? $pageContent['title'][$currentLang]: null }}</a>
                                                            @if(!empty($pageContent['parentCategories'][0]))
                                                                <ul class="submenu">
                                                                    @foreach($pageContent['parentCategories'] as $pageParentCategories)
                                                                        @if(empty($pageParentCategories['subParentCategories'][0]))
                                                                            <li class="submenu-item"><a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' =>  $pageParentCategories['slug'][$currentLang], 'subParentCategories' => null]) }}">{{ !empty($pageParentCategories['title'][$currentLang])? $pageParentCategories['title'][$currentLang]: null }}</a></li>
                                                                        @else
                                                                            <li class="submenu-item">
                                                                                <div class="accordion-menu">
                                                                                    <button class="accordion-toggle">{{ !empty($pageParentCategories['title'][$currentLang])? $pageParentCategories['title'][$currentLang]: null }}</button>
                                                                                    <div class="accordion-header-content">
                                                                                        <ul>
                                                                                            @foreach($pageParentCategories['subParentCategories'] as $pageSubCategories)
                                                                                                @if(!empty($pageSubCategories['slug'][$currentLang]))
                                                                                                    <li><a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' =>  $pageParentCategories['slug'][$currentLang], 'subParentCategories' => $pageSubCategories['slug'][$currentLang]]) }}">{{ !empty($pageSubCategories['title'][$currentLang])? $pageSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                                @endif
                                                                                            @endforeach
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                        @endif
                                                                    @endforeach
                                                                </ul>
                                                            @endif
                                                        </li>
                                                    @endif
                                                @endforeach
                                            @endif
                                        </ul>
                                    </li>
                                @endif
                            @endforeach
                        @endif
                        <li class="menu-item">
                            <a href="#">@lang('site.education')</a>
                            @if(!empty($newsCategory))
                                <ul class="submenu">
                                    @foreach($newsCategory as $key => $newsCat)
                                        <li class="submenu-item">
                                            <a href="{{ route('site.news',$newsCat['slug'][$currentLang]) }}">{{ !empty($newsCat['title'][$currentLang])? $newsCat['title'][$currentLang]: null }}</a>
                                            @if(!empty($newsCat['parentCategories'][0]))
                                                <ul class="submenu">
                                                    @foreach($newsCat['parentCategories'] as $newsParentCategories)
                                                        @if(empty($newsParentCategories['subParentCategories'][0]))
                                                            <li class="submenu-item"> <a href="{{ route('site.news',$newsParentCategories['slug'][$currentLang]) }}">{{ !empty($newsParentCategories['title'][$currentLang])? $newsParentCategories['title'][$currentLang]: null }}</a></li>
                                                        @else
                                                            <li class="submenu-item">
                                                                <div class="accordion-menu">
                                                                    <button class="accordion-toggle">{{ !empty($newsParentCategories['title'][$currentLang])? $newsParentCategories['title'][$currentLang]: null }}</button>
                                                                    <div class="accordion-header-content">
                                                                        <ul>
                                                                            @foreach($newsParentCategories['subParentCategories'] as $newsSubCategories)
                                                                                <li><a href="{{ route('site.news',$newsSubCategories['slug'][$currentLang]) }}">{{ !empty($newsSubCategories['title'][$currentLang])? $newsSubCategories['title'][$currentLang]: null }}</a></li>
                                                                            @endforeach
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        @endif
                                                    @endforeach
                                                </ul>
                                            @endif
                                        </li>
                                    @endforeach
                                </ul>
                            @endif
                            {{-- <ul class="submenu">
                                 @if(!empty($newsCategory[0]))
                                     @foreach($newsCategory as $newsCat)
                                         <?php $catSlug = !empty($newsCat['slug'][$currentLang]) ? $newsCat['slug'][$currentLang] : null; ?>
                                         <li class="submenu-item"><a href="{{ route('site.news',['slug' => $catSlug ]) }}">{{ !empty($newsCat['title'][$currentLang])? $newsCat['title'][$currentLang]: null }}</a></li>
                                     @endforeach
                                 @endif
                             </ul>--}}
                        </li>
                        <li class="menu-item">
                            <a href="#">@lang('site.our_contact')</a>
                            <ul class="submenu" id="contact-submenu">
                                <li class="submenu-item"><a href="{{ route('site.contact') }}">@lang('site.write_to_we')</a></li>
                                <li class="submenu-item"><a href="{{ route('site.receptionDays') }}">@lang('site.reception_days')</a></li>
                                <li class="submenu-item"><a href="{{ route('site.complaints') }}">@lang('site.complaints')</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>

                <nav class="responsive_menu" id="responsive-menu">
                    <button class="menu-toggle" aria-label="Open menu">
                        <div class="div_menu_responsive">
                            <img src="{{ asset("site/assets/images/svg/responsive_menu.svg") }}" alt="" />
                        </div>
                    </button>
                    <div class="accordion accordion_responsive">
                        <div class="accordion-item accordion-item_responsive">
                            <button class="accordion-header accordion-header_responsive">
                                @lang('site.institute')
                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                            </button>
                            <div class="accordion-content">
                                @if(!empty($instituteCategory[0]))
                                    <ul>
                                        @foreach($instituteCategory as $key => $instituteCat)
                                            @if(!empty($instituteCat['parentCategories'][0]))
                                                <li>
                                                    <div class="accordion-item">
                                                        <button class="nested-accordion-header">
                                                            {{ !empty($instituteCat['title'][$currentLang])? $instituteCat['title'][$currentLang]: null }}
                                                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                        </button>
                                                        <div class="nested-accordion-content">
                                                            <ul>
                                                                @foreach($instituteCat['parentCategories'] as $instituteParentCategories)
                                                                    @if(empty($instituteParentCategories['subParentCategories'][0]))
                                                                        <li><a href="{{ route('site.institute',$instituteParentCategories['slug'][$currentLang]) }}">{{ !empty($instituteParentCategories['title'][$currentLang])? $instituteParentCategories['title'][$currentLang]: null }}</a></li>
                                                                    @else
                                                                        <li>
                                                                            <div class="accordion-item">
                                                                                <button class="nested-accordion-header">
                                                                                    {{ !empty($instituteParentCategories['title'][$currentLang])? $instituteParentCategories['title'][$currentLang]: null }}
                                                                                    <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                                </button>
                                                                                <div class="nested-accordion-content">
                                                                                    <ul>
                                                                                        @foreach($instituteParentCategories['subParentCategories'] as $instituteSubCategories)
                                                                                            <li><a href="{{ route('site.institute',$instituteSubCategories['slug'][$currentLang]) }}">{{ !empty($instituteSubCategories['title'][$currentLang])? $instituteSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                        @endforeach
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                    @endif
                                                                @endforeach
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                            @else
                                                <li>
                                                    <a href="{{ route('site.institute',$instituteCat['slug'][$currentLang]) }}">{{ !empty($instituteCat['title'][$currentLang])? $instituteCat['title'][$currentLang]: null }}</a>
                                                </li>
                                            @endif
                                        @endforeach
                                    </ul>
                                @endif
                            </div>
                        </div>

                        <div class="accordion-item accordion-item_responsive">
                            <button class="accordion-header accordion-header_responsive">
                                @lang('site.laboratory')
                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                            </button>
                            <div class="accordion-content">
                                @if(!empty($laboratoryCategory[0]))
                                    <ul>
                                        @foreach($laboratoryCategory as $key => $laboratoryCat)
                                            @if(!empty($laboratoryCat['parentCategories'][0]))
                                                <li>
                                                    <div class="accordion-item">
                                                        <button class="nested-accordion-header">
                                                            {{ !empty($laboratoryCat['title'][$currentLang])? $laboratoryCat['title'][$currentLang]: null }}
                                                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                        </button>
                                                        <div class="nested-accordion-content">
                                                            <ul>
                                                                @foreach($laboratoryCat['parentCategories'] as $laboratoryParentCategories)
                                                                    @if(empty($laboratoryParentCategories['subParentCategories'][0]))
                                                                        <li><a href="{{ route('site.laboratory',$laboratoryParentCategories['slug'][$currentLang]) }}">{{ !empty($laboratoryParentCategories['title'][$currentLang])? $laboratoryParentCategories['title'][$currentLang]: null }}</a></li>
                                                                    @else
                                                                        <li>
                                                                            <div class="accordion-item">
                                                                                <button class="nested-accordion-header">
                                                                                    {{ !empty($laboratoryParentCategories['title'][$currentLang])? $laboratoryParentCategories['title'][$currentLang]: null }}
                                                                                    <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                                </button>
                                                                                <div class="nested-accordion-content">
                                                                                    <ul>
                                                                                        @foreach($laboratoryParentCategories['subParentCategories'] as $laboratorySubCategories)
                                                                                            <li><a href="{{ route('site.laboratory',$laboratorySubCategories['slug'][$currentLang]) }}">{{ !empty($laboratorySubCategories['title'][$currentLang])? $laboratorySubCategories['title'][$currentLang]: null }}</a></li>
                                                                                        @endforeach
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                    @endif
                                                                @endforeach
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                            @else
                                                <li>
                                                    <a href="{{ route('site.laboratory',$laboratoryCat['slug'][$currentLang]) }}">{{ !empty($laboratoryCat['title'][$currentLang])? $laboratoryCat['title'][$currentLang]: null }}</a>
                                                </li>
                                            @endif
                                        @endforeach
                                    </ul>
                                @endif
                            </div>
                        </div>

                        <div class="accordion-item accordion-item_responsive">
                            <button class="accordion-header accordion-header_responsive">
                                @lang('site.services')
                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                            </button>
                            <div class="accordion-content">
                                @if(!empty($services[0]))
                                    <ul>
                                        @foreach($services as $key => $servicesCat)
                                            @if(!empty($servicesCat['parentCategories'][0]))
                                                <li>
                                                    <div class="accordion-item">
                                                        <button class="nested-accordion-header">
                                                            {{ !empty($servicesCat['title'][$currentLang])? $servicesCat['title'][$currentLang]: null }}
                                                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                        </button>
                                                        <div class="nested-accordion-content">
                                                            <ul>
                                                                @foreach($servicesCat['parentCategories'] as $servicesParentCategories)
                                                                    @if(empty($servicesParentCategories['subParentCategories'][0]))
                                                                        <li><a href="{{ route('site.service',$servicesParentCategories['slug'][$currentLang]) }}">{{ !empty($servicesParentCategories['title'][$currentLang])? $servicesParentCategories['title'][$currentLang]: null }}</a></li>
                                                                    @else
                                                                        <li>
                                                                            <div class="accordion-item">
                                                                                <button class="nested-accordion-header">
                                                                                    {{ !empty($servicesParentCategories['title'][$currentLang])? $servicesParentCategories['title'][$currentLang]: null }}
                                                                                    <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                                </button>
                                                                                <div class="nested-accordion-content">
                                                                                    <ul>
                                                                                        @foreach($servicesParentCategories['subParentCategories'] as $serviceSubCategories)
                                                                                            <li><a href="{{ route('site.service',$serviceSubCategories['slug'][$currentLang]) }}">{{ !empty($serviceSubCategories['title'][$currentLang])? $serviceSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                        @endforeach
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                    @endif
                                                                @endforeach
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                            @else
                                                <li>
                                                    <a href="{{ route('site.service',$servicesCat['slug'][$currentLang]) }}">{{ !empty($servicesCat['title'][$currentLang])? $servicesCat['title'][$currentLang]: null }}</a>
                                                </li>
                                            @endif
                                        @endforeach
                                    </ul>
                                @endif
                            </div>
                        </div>

                        <div class="accordion accordion_responsive">
                            <div class="accordion-item accordion-item_responsive">
                                <button class="accordion-header accordion-header_responsive">
                                    @lang('site.useful')
                                    <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                </button>
                                <div class="accordion-content">
                                    @if(!empty($usefulCategory))
                                        <ul>
                                            @foreach($usefulCategory as $key => $usefulCat)
                                                @if(!empty($usefulCat['parentCategories'][0]))
                                                    <li>
                                                        <div class="accordion-item">
                                                            <button class="nested-accordion-header">
                                                                {{ !empty($usefulCat['title'][$currentLang])? $usefulCat['title'][$currentLang]: null }}
                                                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                            </button>
                                                            <div class="nested-accordion-content">
                                                                <ul>
                                                                    @foreach($usefulCat['parentCategories'] as $usefulParentCategories)
                                                                        @if(empty($usefulParentCategories['subParentCategories'][0]))
                                                                            <li><a href="{{ route('site.useful',$usefulSubCategories['slug'][$currentLang]) }}">{{ !empty($usefulParentCategories['title'][$currentLang])? $usefulParentCategories['title'][$currentLang]: null }}</a></li>
                                                                        @else
                                                                            <li>
                                                                                <div class="accordion-item">
                                                                                    <button class="nested-accordion-header">
                                                                                        {{ !empty($usefulParentCategories['title'][$currentLang])? $usefulParentCategories['title'][$currentLang]: null }}
                                                                                        <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                                    </button>
                                                                                    <div class="nested-accordion-content">
                                                                                        <ul>
                                                                                            @foreach($usefulParentCategories['subParentCategories'] as $usefulSubCategories)
                                                                                                <li><a href="{{ route('site.useful',$usefulSubCategories['slug'][$currentLang]) }}">{{ !empty($usefulSubCategories['title'][$currentLang])? $usefulSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                            @endforeach
                                                                                        </ul>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                        @endif
                                                                    @endforeach
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </li>
                                                @else
                                                    <li>
                                                        <a href="{{ route('site.useful',$usefulCat['slug'][$currentLang]) }}">{{ !empty($usefulCat['title'][$currentLang])? $usefulCat['title'][$currentLang]: null }}</a>
                                                    </li>
                                                @endif
                                            @endforeach
                                        </ul>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item accordion-item_responsive">
                            <button class="accordion-header accordion-header_responsive">
                                @lang('site.education')
                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                            </button>
                            <div class="accordion-content">
                                @if(!empty($newsCategory[0]))
                                    <ul>
                                        @foreach($newsCategory as $key => $newsCat)
                                            @if(!empty($newsCat['parentCategories'][0]))
                                                <li>
                                                    <div class="accordion-item">
                                                        <button class="nested-accordion-header">
                                                            {{ !empty($newsCat['title'][$currentLang])? $newsCat['title'][$currentLang]: null }}
                                                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                        </button>
                                                        <div class="nested-accordion-content">
                                                            <ul>
                                                                @foreach($newsCat['parentCategories'] as $newsParentCategories)
                                                                    @if(empty($newsParentCategories['subParentCategories'][0]))
                                                                        <li><a href="{{ route('site.news',$newsParentCategories['slug'][$currentLang]) }}">{{ !empty($newsParentCategories['title'][$currentLang])? $newsParentCategories['title'][$currentLang]: null }}</a></li>
                                                                    @else
                                                                        <li>
                                                                            <div class="accordion-item">
                                                                                <button class="nested-accordion-header">
                                                                                    {{ !empty($newsParentCategories['title'][$currentLang])? $newsParentCategories['title'][$currentLang]: null }}
                                                                                    <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                                </button>
                                                                                <div class="nested-accordion-content">
                                                                                    <ul>
                                                                                        @foreach($newsParentCategories['subParentCategories'] as $newsSubCategories)
                                                                                            <li><a href="{{ route('site.news',$newsSubCategories['slug'][$currentLang]) }}">{{ !empty($newsSubCategories['title'][$currentLang])? $newsSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                        @endforeach
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                    @endif
                                                                @endforeach
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                            @else
                                                <li>
                                                    <a href="{{ route('site.news',$newsCat['slug'][$currentLang]) }}">{{ !empty($newsCat['title'][$currentLang])? $newsCat['title'][$currentLang]: null }}</a>
                                                </li>
                                            @endif
                                        @endforeach
                                    </ul>
                                @endif
                                {{--<ul>
                                    @if(!empty($newsCategory[0]))
                                        @foreach($newsCategory as $newsCat)
                                            <?php $catSlug = !empty($newsCat['slug'][$currentLang]) ? $newsCat['slug'][$currentLang] : null; ?>
                                            <li><a href="{{ route('site.news',['slug' => $catSlug ]) }}">{{ !empty($newsCat['title'][$currentLang])? $newsCat['title'][$currentLang]: null }}</a></li>
                                        @endforeach
                                    @endif
                                </ul>--}}
                            </div>
                        </div>


                        @if(!empty($pages[0]))
                            @foreach($pages as $page)
                                @if(!empty($page['slug'][$currentLang]))
                                    <div class="accordion accordion_responsive">
                                        <div class="accordion-item accordion-item_responsive">
                                            <button class="accordion-header accordion-header_responsive">
                                                {{ !empty($page['title'][$currentLang])? $page['title'][$currentLang]: null }}
                                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                            </button>
                                            <div class="accordion-content">
                                                @if(!empty($page['parentPage'][0]))
                                                    <ul>
                                                        @foreach($page['parentPage'] as $pageContent)
                                                            @if(!empty($pageContent['parentCategories'][0]))
                                                                <li>
                                                                    <div class="accordion-item">
                                                                        <button class="nested-accordion-header">
                                                                            {{ !empty($pageContent['title'][$currentLang])? $pageContent['title'][$currentLang]: null }}
                                                                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                        </button>
                                                                        <div class="nested-accordion-content">
                                                                            <ul>
                                                                                @foreach($pageContent['parentCategories'] as $pageParentCategories)
                                                                                    @if(empty($pageParentCategories['subParentCategories'][0]))
                                                                                        <li><a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' =>  $pageParentCategories['slug'][$currentLang], 'subParentCategories' => null]) }}">{{ !empty($pageParentCategories['title'][$currentLang])? $pageParentCategories['title'][$currentLang]: null }}</a></li>
                                                                                    @else
                                                                                        <li>
                                                                                            <div class="accordion-item">
                                                                                                <button class="nested-accordion-header">
                                                                                                    {{ !empty($pageParentCategories['title'][$currentLang])? $pageParentCategories['title'][$currentLang]: null }}
                                                                                                    <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                                                </button>
                                                                                                <div class="nested-accordion-content">
                                                                                                    <ul>
                                                                                                        @foreach($pageParentCategories['subParentCategories'] as $pageSubCategories)
                                                                                                            @if(!empty($pageSubCategories['slug'][$currentLang]))
                                                                                                                <li><a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' =>  $pageParentCategories['slug'][$currentLang], 'subParentCategories' => $pageSubCategories['slug'][$currentLang]]) }}">{{ !empty($pageSubCategories['title'][$currentLang])? $pageSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                                            @endif
                                                                                                        @endforeach
                                                                                                    </ul>
                                                                                                </div>
                                                                                            </div>
                                                                                        </li>
                                                                                    @endif
                                                                                @endforeach
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                            @else
                                                                @if(!empty($pageContent['slug'][$currentLang]))
                                                                    <li>
                                                                        <a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' => null, 'subParentCategories' => null]) }}">{{ !empty($pageContent['title'][$currentLang])? $pageContent['title'][$currentLang]: null }}</a>
                                                                    </li>
                                                                @endif
                                                            @endif
                                                        @endforeach
                                                    </ul>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                @endif
                            @endforeach
                        @endif


                        <div class="accordion-item accordion-item_responsive">
                            <button class="accordion-header accordion-header_responsive">
                                @lang('site.our_contact')
                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                            </button>
                            <div class="accordion-content">
                                <ul>
                                    <li><a href="{{ route('site.contact') }}">@lang('site.write_to_we')</a></li>
                                    <li><a href="{{ route('site.receptionDays') }}">@lang('site.reception_days')</a></li>
                                    <li><a href="{{ route('site.complaints') }}">@lang('site.complaints')</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="accordion-item">
                            <a href="{{ route('site.career') }}" class="accordion-header accordion-link">@lang('site.vacancies')</a>
                        </div>
                    </div>
                </nav>
            </div>
            @if(!empty($sliders[0]))
                @foreach($sliders as $sliderKey => $slider)
                    <div class="main_content @if(++$sliderKey == 1)active @endif">
                        <img src="{{ asset('uploads/sliders/'.$slider->image) }}" alt="{{$sliderKey}}" />
                        <h2 class="main_title">
                            {!! !empty($slider['title'][$currentLang]) ? $slider['title'][$currentLang] : null !!}
                        </h2>
                        <div class="main_descr">
                            {{ !empty($slider['text'][$currentLang])? $slider['text'][$currentLang]: null }}
                        </div>
                        <a href="{{ !empty($slider['link'])? $slider['link']: route('site.contact') }}"  class="main_btn">@lang('site.more')</a>
                    </div>
                @endforeach
            @endif
        </div>
        @if(!empty($sliders[0]))
            <div class="points">
                @foreach($sliders as $sliderKey => $slider)
                    <div class="point_line @if(++$sliderKey == 1)active @endif" data-index="{{$sliderKey-1}}"></div>
                @endforeach
            </div>
        @endif
    </section>
@else
    <div class="header_one">
        <div class="connect">
            <div class="dropdown">
                <button class="dropbtn" id="selectedLanguage">
                    {{ ucwords($currentLang) }}
                    <img src="{{ asset("site/assets/images/svg/union-1.png") }}" alt="" />
                </button>
                <div class="dropdown-content">
                    @foreach($languages as $localeCode => $properties)
                        @if($properties['code'] != $currentLang)
                            <a href="{{ LaravelLocalization::getLocalizedURL($properties['code'], route('site.index')) }}" hreflang="{{ $properties['code'] }}">
                                {{ ucwords($properties['code']) }}
                            </a>
                        @endif
                    @endforeach

                </div>
            </div>
            <div class="phone">
                <img src="{{ asset("site/assets/images/svg/phone.svg") }}" alt="" />
                <span><a href="tel:+{{ !empty($setting['phone'])? $setting['phone']: NULL }}">{{ !empty($setting['phone'])? $setting['phone']: NULL }}</a></span>
            </div>
            <div class="social_media">
                <a href="mailto:{{ !empty($setting['email'])? $setting['email']: NULL }}" target="_blank" aria-label="Email">
                    <img src="{{ asset("site/assets/images/svg/email.svg") }}" alt="Email" />
                </a>
                <a href="{{ !empty($setting['twitter'])? $setting['twitter']: NULL }}" target="_blank" aria-label="X">
                    <img src="{{ asset("site/assets/images/svg/x.svg") }}" alt="X" />
                </a>
                <a href="{{ !empty($setting['facebook'])? $setting['facebook']: NULL }}" target="_blank" aria-label="Facebook">
                    <img src="{{ asset("site/assets/images/svg/facebook.svg") }}" alt="Facebook" />
                </a>
                <a href="{{ !empty($setting['youtube'])? $setting['youtube']: NULL }}" target="_blank" aria-label="YouTube">
                    <img src="{{ asset("site/assets/images/svg/youtube.svg") }}" alt="YouTube" />
                </a>
                <a href="{{ !empty($setting['linkedin'])? $setting['linkedin']: NULL }}" target="_blank" aria-label="LinkedIn">
                    <img src="{{ asset("site/assets/images/svg/linkedin.svg") }}" alt="LinkedIn" />
                </a>
                <a href="{{ !empty($setting['instagram'])? $setting['instagram']: NULL }}" target="_blank" aria-label="Instagram">
                    <img src="{{ asset("site/assets/images/svg/instagram.svg") }}" alt="Instagram" />
                </a>
            </div>
        </div>
        <div class="search-container">
            <form action="{{ route('site.search') }}" style="display: flex; align-items: center; width: 100%;!important;">
                <input type="text"  name="q" placeholder="Axtar" class="search-input" value="{{ !empty($_GET['q'])? $_GET['q']: '' }}" />
                <button class="search-button" aria-label="Search">
                    <img src="{{ asset("site/assets/images/svg/magnifier.svg") }}" alt="Search"/>
                </button>
            </form>
        </div>
        <div class="header_one_buttons">
            <div class="career_sub_menu">
                <a class="karyera_btn" href="#">@lang('site.career')</a>
                <div class="career_dropdown">
                    <ul>
                        <li><a href="{{ route('site.career') }}">@lang('site.vacancies')</a></li>
                        <li><a href="{{ route('site.volunteer') }}">@lang('site.volunteer')</a></li>
                    </ul>
                </div>
            </div>
            <a href="" class="button_link">@lang('site.virtual_laboratory')</a>
        </div>
    </div>
    <div class="header">
        <div class="main_menu">
            <a href="{{ route('site.index') }}" class="main_logo">
                @if(!empty($setting['footer_logo']))
                    <div class="logo_img">
                        <img src="{{ asset('uploads/settings/'.$setting['footer_logo']) }}" alt="{{ !empty($setting['title'][$currentLang])? $setting['title'][$currentLang]: NULL }}" />
                    </div>
                @endif
                <div class="logo_text">
                    {{ !empty($setting['title'][$currentLang])? $setting['title'][$currentLang]: NULL }}
                </div>
            </a>
            <button class="menu-toggle" aria-label="Open menu">
                <div class="div_menu_responsive">
                    <img src="{{ asset("site/assets/images/svg/responsive_menu.svg") }}" alt="" />
                </div>
            </button>
            <nav class="menu">
                <ul class="menu-level">

                    <li class="menu-item">
                        <a href="#">@lang('site.institute')</a>
                        @if(!empty($instituteCategory[0]))
                            <ul class="submenu">
                                @foreach($instituteCategory as $key => $instituteCat)
                                    <li class="submenu-item">
                                        <a href="{{ route('site.institute',$instituteCat['slug'][$currentLang]) }}">{{ !empty($instituteCat['title'][$currentLang])? $instituteCat['title'][$currentLang]: null }}</a>
                                        @if(!empty($instituteCat['parentCategories'][0]))
                                            <ul class="submenu">
                                                @foreach($instituteCat['parentCategories'] as $instituteParentCategories)
                                                    @if(empty($instituteParentCategories['subParentCategories'][0]))
                                                        <li class="submenu-item"> <a href="{{ route('site.institute',$instituteParentCategories['slug'][$currentLang]) }}">{{ !empty($instituteParentCategories['title'][$currentLang])? $instituteParentCategories['title'][$currentLang]: null }}</a></li>
                                                    @elseif(!empty($instituteParentCategories['subParentCategories'][0]))
                                                        <li class="submenu-item">
                                                            <div class="accordion-menu">
                                                                <button class="accordion-toggle">{{ !empty($instituteParentCategories['title'][$currentLang])? $instituteParentCategories['title'][$currentLang]: null }}</button>
                                                                <div class="accordion-header-content">
                                                                    <ul>
                                                                        @foreach($instituteParentCategories['subParentCategories'] as $instituteSubCategories)
                                                                            <li><a href="{{ route('site.institute',$instituteSubCategories['slug'][$currentLang]) }}">{{ !empty($instituteSubCategories['title'][$currentLang])? $instituteSubCategories['title'][$currentLang]: null }}</a></li>
                                                                        @endforeach
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    @endif
                                                @endforeach
                                            </ul>
                                        @endif
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    </li>
                    <li class="menu-item">
                        <a href="#">@lang('site.laboratory')</a>
                        @if(!empty($laboratoryCategory[0]))
                            <ul class="submenu">
                                @foreach($laboratoryCategory as $key => $laboratoryCat)
                                    <li class="submenu-item">
                                        <a href="{{ route('site.laboratory',$laboratoryCat['slug'][$currentLang]) }}">{{ !empty($laboratoryCat['title'][$currentLang])? $laboratoryCat['title'][$currentLang]: null }}</a>
                                        @if(!empty($laboratoryCat['parentCategories'][0]))
                                            <ul class="submenu">
                                                @foreach($laboratoryCat['parentCategories'] as $laboratoryParentCategories)
                                                    @if(empty($laboratoryParentCategories['subParentCategories'][0]))
                                                        <li class="submenu-item"> <a href="{{ route('site.laboratory',$laboratoryParentCategories['slug'][$currentLang]) }}">{{ !empty($laboratoryParentCategories['title'][$currentLang])? $laboratoryParentCategories['title'][$currentLang]: null }}</a></li>
                                                    @else
                                                        <li class="submenu-item">
                                                            <div class="accordion-menu">
                                                                <button class="accordion-toggle">{{ !empty($laboratoryParentCategories['title'][$currentLang])? $laboratoryParentCategories['title'][$currentLang]: null }}</button>
                                                                <div class="accordion-header-content">
                                                                    <ul>
                                                                        @foreach($laboratoryParentCategories['subParentCategories'] as $laboratorySubCategories)
                                                                            <li><a href="{{ route('site.laboratory',$laboratorySubCategories['slug'][$currentLang]) }}">{{ !empty($laboratorySubCategories['title'][$currentLang])? $laboratorySubCategories['title'][$currentLang]: null }}</a></li>
                                                                        @endforeach
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    @endif
                                                @endforeach
                                            </ul>
                                        @endif
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    </li>
                    <li class="menu-item">
                        <a href="#">@lang('site.services')</a>
                        @if(!empty($services[0]))
                            <ul class="submenu">
                                @foreach($services as $key => $servicesCat)
                                    <li class="submenu-item">
                                        <a href="{{ route('site.service',$servicesCat['slug'][$currentLang]) }}">{{ !empty($servicesCat['title'][$currentLang])? $servicesCat['title'][$currentLang]: null }}</a>
                                        @if(!empty($servicesCat['parentCategories'][0]))
                                            <ul class="submenu">
                                                @foreach($servicesCat['parentCategories'] as $servicesParentCategories)
                                                    @if(empty($servicesParentCategories['subParentCategories'][0]))
                                                        <li class="submenu-item"> <a href="{{ route('site.service',$servicesParentCategories['slug'][$currentLang]) }}">{{ !empty($servicesParentCategories['title'][$currentLang])? $servicesParentCategories['title'][$currentLang]: null }}</a></li>
                                                    @else
                                                        <li class="submenu-item">
                                                            <div class="accordion-menu">
                                                                <button class="accordion-toggle">{{ !empty($servicesParentCategories['title'][$currentLang])? $servicesParentCategories['title'][$currentLang]: null }}</button>
                                                                <div class="accordion-header-content">
                                                                    <ul>
                                                                        @foreach($servicesParentCategories['subParentCategories'] as $servicesSubCategories)
                                                                            <li><a href="{{ route('site.service',$servicesSubCategories['slug'][$currentLang]) }}">{{ !empty($servicesSubCategories['title'][$currentLang])? $servicesSubCategories['title'][$currentLang]: null }}</a></li>
                                                                        @endforeach
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    @endif
                                                @endforeach
                                            </ul>
                                        @endif
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    </li>
                    <li class="menu-item">
                        <a href="#">@lang('site.useful')</a>
                        @if(!empty($usefulCategory))
                            <ul class="submenu">
                                @foreach($usefulCategory as $key => $usefulCat)
                                    <li class="submenu-item">
                                        <a href="{{ route('site.useful',$usefulCat['slug'][$currentLang]) }}">{{ !empty($usefulCat['title'][$currentLang])? $usefulCat['title'][$currentLang]: null }}</a>
                                        @if(!empty($usefulCat['parentCategories'][0]))
                                            <ul class="submenu">
                                                @foreach($usefulCat['parentCategories'] as $usefulParentCategories)
                                                    @if(empty($usefulParentCategories['subParentCategories'][0]))
                                                        <li class="submenu-item"> <a href="{{ route('site.useful',$usefulParentCategories['slug'][$currentLang]) }}">{{ !empty($usefulParentCategories['title'][$currentLang])? $usefulParentCategories['title'][$currentLang]: null }}</a></li>
                                                    @else
                                                        <li class="submenu-item">
                                                            <div class="accordion-menu">
                                                                <button class="accordion-toggle">{{ !empty($usefulParentCategories['title'][$currentLang])? $usefulParentCategories['title'][$currentLang]: null }}</button>
                                                                <div class="accordion-header-content">
                                                                    <ul>
                                                                        @foreach($usefulParentCategories['subParentCategories'] as $usefulSubCategories)
                                                                            <li><a href="{{ route('site.useful',$usefulSubCategories['slug'][$currentLang]) }}">{{ !empty($usefulSubCategories['title'][$currentLang])? $usefulSubCategories['title'][$currentLang]: null }}</a></li>
                                                                        @endforeach
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    @endif
                                                @endforeach
                                            </ul>
                                        @endif
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    </li>
                    @if(!empty($pages[0]))
                        @foreach($pages as $page)
                            @if(!empty($page['slug'][$currentLang]))
                                <li class="menu-item">
                                    <a href="#">{{ !empty($page['title'][$currentLang])? $page['title'][$currentLang]: null }}</a>
                                    <ul class="submenu">
                                        @if(!empty($page['parentPage'][0]))
                                            @foreach($page['parentPage'] as $pageContent)
                                                @if(!empty($pageContent['slug'][$currentLang]))
                                                    <li class="submenu-item">
                                                        <a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' => null, 'subParentCategories' => null]) }}">{{ !empty($pageContent['title'][$currentLang])? $pageContent['title'][$currentLang]: null }}</a>
                                                        @if(!empty($pageContent['parentCategories'][0]))
                                                            <ul class="submenu">
                                                                @foreach($pageContent['parentCategories'] as $pageParentCategories)
                                                                    @if(empty($pageParentCategories['subParentCategories'][0]))
                                                                        <li class="submenu-item"><a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' =>  $pageParentCategories['slug'][$currentLang], 'subParentCategories' => null]) }}">{{ !empty($pageParentCategories['title'][$currentLang])? $pageParentCategories['title'][$currentLang]: null }}</a></li>
                                                                    @else
                                                                        <li class="submenu-item">
                                                                            <div class="accordion-menu">
                                                                                <button class="accordion-toggle">{{ !empty($pageParentCategories['title'][$currentLang])? $pageParentCategories['title'][$currentLang]: null }}</button>
                                                                                <div class="accordion-header-content">
                                                                                    <ul>
                                                                                        @foreach($pageParentCategories['subParentCategories'] as $pageSubCategories)
                                                                                            @if(!empty($pageSubCategories['slug'][$currentLang]))
                                                                                                <li><a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' =>  $pageParentCategories['slug'][$currentLang], 'subParentCategories' => $pageSubCategories['slug'][$currentLang]]) }}">{{ !empty($pageSubCategories['title'][$currentLang])? $pageSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                            @endif
                                                                                        @endforeach
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                    @endif
                                                                @endforeach
                                                            </ul>
                                                        @endif
                                                    </li>
                                                @endif
                                            @endforeach
                                        @endif
                                    </ul>
                                </li>
                            @endif
                        @endforeach
                    @endif
                    {{--@if(!empty($pages[0]))
                        @foreach($pages as $page)
                            <li class="menu-item">
                                <a href="#">{{ !empty($page['title'][$currentLang])? $page['title'][$currentLang]: null }}</a>
                                <ul class="submenu">
                                    @if(!empty($page['parentPage'][0]))
                                        @foreach($page['parentPage'] as $pageContent)
                                            <li class="submenu-item">
                                                <a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang]]) }}">{{ !empty($pageContent['title'][$currentLang])? $pageContent['title'][$currentLang]: null }}</a>
                                            </li>
                                        @endforeach
                                    @endif
                                </ul>
                            </li>
                        @endforeach
                    @endif--}}
                    <li class="menu-item">
                        <a href="#">@lang('site.education')</a>
                        @if(!empty($newsCategory))
                            <ul class="submenu">
                                @foreach($newsCategory as $key => $newsCat)
                                    <li class="submenu-item">
                                        <a href="{{ route('site.news',$newsCat['slug'][$currentLang]) }}">{{ !empty($newsCat['title'][$currentLang])? $newsCat['title'][$currentLang]: null }}</a>
                                        @if(!empty($newsCat['parentCategories'][0]))
                                            <ul class="submenu">
                                                @foreach($newsCat['parentCategories'] as $newsParentCategories)
                                                    @if(empty($newsParentCategories['subParentCategories'][0]))
                                                        <li class="submenu-item"> <a href="{{ route('site.news',$newsParentCategories['slug'][$currentLang]) }}">{{ !empty($newsParentCategories['title'][$currentLang])? $newsParentCategories['title'][$currentLang]: null }}</a></li>
                                                    @else
                                                        <li class="submenu-item">
                                                            <div class="accordion-menu">
                                                                <button class="accordion-toggle">{{ !empty($newsParentCategories['title'][$currentLang])? $newsParentCategories['title'][$currentLang]: null }}</button>
                                                                <div class="accordion-header-content">
                                                                    <ul>
                                                                        @foreach($newsParentCategories['subParentCategories'] as $newsSubCategories)
                                                                            <li><a href="{{ route('site.news',$newsSubCategories['slug'][$currentLang]) }}">{{ !empty($newsSubCategories['title'][$currentLang])? $newsSubCategories['title'][$currentLang]: null }}</a></li>
                                                                        @endforeach
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    @endif
                                                @endforeach
                                            </ul>
                                        @endif
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                        {{--<ul class="submenu">
                            @if(!empty($newsCategory[0]))
                                @foreach($newsCategory as $newsCat)
                                    <?php $catSlug = !empty($newsCat['slug'][$currentLang]) ? $newsCat['slug'][$currentLang] : null; ?>
                                    <li class="submenu-item"><a href="{{ route('site.news',['slug' => $catSlug ]) }}">{{ !empty($newsCat['title'][$currentLang])? $newsCat['title'][$currentLang]: null }}</a></li>
                                @endforeach
                            @endif
                        </ul>--}}
                    </li>
                    <li class="menu-item">
                        <a href="#">@lang('site.our_contact')</a>
                        <ul class="submenu" id="contact-submenu">
                            <li class="submenu-item"><a href="{{ route('site.contact') }}">@lang('site.write_to_we')</a></li>
                            <li class="submenu-item"><a href="{{ route('site.receptionDays') }}">@lang('site.reception_days')</a></li>
                            <li class="submenu-item"><a href="{{ route('site.complaints') }}">@lang('site.complaints')</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
            <nav class="responsive_menu" id="responsive-menu">
                <button class="menu-toggle" aria-label="Open menu">
                    <div class="div_menu_responsive">
                        <img src="{{ asset("site/assets/images/svg/responsive_menu.svg") }}" alt="" />
                    </div>
                </button>
                <div class="accordion accordion_responsive">
                    <div class="accordion-item accordion-item_responsive">
                        <button class="accordion-header accordion-header_responsive">
                            @lang('site.institute')
                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                        </button>
                        <div class="accordion-content">
                            @if(!empty($instituteCategory[0]))
                                <ul>
                                    @foreach($instituteCategory as $key => $instituteCat)
                                        @if(!empty($instituteCat['parentCategories'][0]))
                                            <li>
                                                <div class="accordion-item">
                                                    <button class="nested-accordion-header">
                                                        {{ !empty($instituteCat['title'][$currentLang])? $instituteCat['title'][$currentLang]: null }}
                                                        <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                    </button>
                                                    <div class="nested-accordion-content">
                                                        <ul>
                                                            @foreach($instituteCat['parentCategories'] as $instituteParentCategories)
                                                                @if(empty($instituteParentCategories['subParentCategories'][0]))
                                                                    <li><a href="{{ route('site.institute',$instituteParentCategories['slug'][$currentLang]) }}">{{ !empty($instituteParentCategories['title'][$currentLang])? $instituteParentCategories['title'][$currentLang]: null }}</a></li>
                                                                @else
                                                                    <li>
                                                                        <div class="accordion-item">
                                                                            <button class="nested-accordion-header">
                                                                                {{ !empty($instituteParentCategories['title'][$currentLang])? $instituteParentCategories['title'][$currentLang]: null }}
                                                                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                            </button>
                                                                            <div class="nested-accordion-content">
                                                                                <ul>
                                                                                    @foreach($instituteParentCategories['subParentCategories'] as $instituteSubCategories)
                                                                                        <li><a href="{{ route('site.institute',$instituteSubCategories['slug'][$currentLang]) }}">{{ !empty($instituteSubCategories['title'][$currentLang])? $instituteSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                    @endforeach
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                @endif
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            </li>
                                        @else
                                            <li>
                                                <a href="{{ route('site.institute',$instituteCat['slug'][$currentLang]) }}">{{ !empty($instituteCat['title'][$currentLang])? $instituteCat['title'][$currentLang]: null }}</a>
                                            </li>
                                        @endif
                                    @endforeach
                                </ul>
                            @endif
                        </div>
                    </div>


                    <div class="accordion-item accordion-item_responsive">
                        <button class="accordion-header accordion-header_responsive">
                            @lang('site.laboratory')
                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                        </button>
                        <div class="accordion-content">
                            @if(!empty($laboratoryCategory[0]))
                                <ul>
                                    @foreach($laboratoryCategory as $key => $laboratoryCat)
                                        @if(!empty($laboratoryCat['parentCategories'][0]))
                                            <li>
                                                <div class="accordion-item">
                                                    <button class="nested-accordion-header">
                                                        {{ !empty($laboratoryCat['title'][$currentLang])? $laboratoryCat['title'][$currentLang]: null }}
                                                        <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                    </button>
                                                    <div class="nested-accordion-content">
                                                        <ul>
                                                            @foreach($laboratoryCat['parentCategories'] as $laboratoryParentCategories)
                                                                @if(empty($laboratoryParentCategories['subParentCategories'][0]))
                                                                    <li><a href="{{ route('site.laboratory',$laboratoryParentCategories['slug'][$currentLang]) }}">{{ !empty($laboratoryParentCategories['title'][$currentLang])? $laboratoryParentCategories['title'][$currentLang]: null }}</a></li>
                                                                @else
                                                                    <li>
                                                                        <div class="accordion-item">
                                                                            <button class="nested-accordion-header">
                                                                                {{ !empty($laboratoryParentCategories['title'][$currentLang])? $laboratoryParentCategories['title'][$currentLang]: null }}
                                                                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                            </button>
                                                                            <div class="nested-accordion-content">
                                                                                <ul>
                                                                                    @foreach($laboratoryParentCategories['subParentCategories'] as $laboratorySubCategories)
                                                                                        <li><a href="{{ route('site.laboratory',$laboratorySubCategories['slug'][$currentLang]) }}">{{ !empty($laboratorySubCategories['title'][$currentLang])? $laboratorySubCategories['title'][$currentLang]: null }}</a></li>
                                                                                    @endforeach
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                @endif
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            </li>
                                        @else
                                            <li>
                                                <a href="{{ route('site.laboratory',$laboratoryCat['slug'][$currentLang]) }}">{{ !empty($laboratoryCat['title'][$currentLang])? $laboratoryCat['title'][$currentLang]: null }}</a>
                                            </li>
                                        @endif
                                    @endforeach
                                </ul>
                            @endif
                        </div>
                    </div>

                    <div class="accordion-item accordion-item_responsive">
                        <button class="accordion-header accordion-header_responsive">
                            @lang('site.services')
                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                        </button>
                        <div class="accordion-content">
                            @if(!empty($services[0]))
                                <ul>
                                    @foreach($services as $key => $servicesCat)
                                        @if(!empty($servicesCat['parentCategories'][0]))
                                            <li>
                                                <div class="accordion-item">
                                                    <button class="nested-accordion-header">
                                                        {{ !empty($servicesCat['title'][$currentLang])? $servicesCat['title'][$currentLang]: null }}
                                                        <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                    </button>
                                                    <div class="nested-accordion-content">
                                                        <ul>
                                                            @foreach($servicesCat['parentCategories'] as $servicesParentCategories)
                                                                @if(empty($servicesParentCategories['subParentCategories'][0]))
                                                                    <li><a href="{{ route('site.service',$servicesParentCategories['slug'][$currentLang]) }}">{{ !empty($servicesParentCategories['title'][$currentLang])? $servicesParentCategories['title'][$currentLang]: null }}</a></li>
                                                                @else
                                                                    <li>
                                                                        <div class="accordion-item">
                                                                            <button class="nested-accordion-header">
                                                                                {{ !empty($servicesParentCategories['title'][$currentLang])? $servicesParentCategories['title'][$currentLang]: null }}
                                                                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                            </button>
                                                                            <div class="nested-accordion-content">
                                                                                <ul>
                                                                                    @foreach($servicesParentCategories['subParentCategories'] as $serviceSubCategories)
                                                                                        <li><a href="{{ route('site.service',$serviceSubCategories['slug'][$currentLang]) }}">{{ !empty($serviceSubCategories['title'][$currentLang])? $serviceSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                    @endforeach
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                @endif
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            </li>
                                        @else
                                            <li>
                                                <a href="{{ route('site.service',$servicesCat['slug'][$currentLang]) }}">{{ !empty($servicesCat['title'][$currentLang])? $servicesCat['title'][$currentLang]: null }}</a>
                                            </li>
                                        @endif
                                    @endforeach
                                </ul>
                            @endif
                        </div>
                    </div>

                    <div class="accordion accordion_responsive">
                        <div class="accordion-item accordion-item_responsive">
                            <button class="accordion-header accordion-header_responsive">
                                @lang('site.useful')
                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                            </button>
                            <div class="accordion-content">
                                @if(!empty($usefulCategory))
                                    <ul>
                                        @foreach($usefulCategory as $key => $usefulCat)
                                            @if(!empty($usefulCat['parentCategories'][0]))
                                                <li>
                                                    <div class="accordion-item">
                                                        <button class="nested-accordion-header">
                                                            {{ !empty($usefulCat['title'][$currentLang])? $usefulCat['title'][$currentLang]: null }}
                                                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                        </button>
                                                        <div class="nested-accordion-content">
                                                            <ul>
                                                                @foreach($usefulCat['parentCategories'] as $usefulParentCategories)
                                                                    @if(empty($usefulParentCategories['subParentCategories'][0]))
                                                                        <li><a href="{{ route('site.useful',$usefulSubCategories['slug'][$currentLang]) }}">{{ !empty($usefulParentCategories['title'][$currentLang])? $usefulParentCategories['title'][$currentLang]: null }}</a></li>
                                                                    @else
                                                                        <li>
                                                                            <div class="accordion-item">
                                                                                <button class="nested-accordion-header">
                                                                                    {{ !empty($usefulParentCategories['title'][$currentLang])? $usefulParentCategories['title'][$currentLang]: null }}
                                                                                    <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                                </button>
                                                                                <div class="nested-accordion-content">
                                                                                    <ul>
                                                                                        @foreach($usefulParentCategories['subParentCategories'] as $usefulSubCategories)
                                                                                            <li><a href="{{ route('site.useful',$usefulSubCategories['slug'][$currentLang]) }}">{{ !empty($usefulSubCategories['title'][$currentLang])? $usefulSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                        @endforeach
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                    @endif
                                                                @endforeach
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                            @else
                                                <li>
                                                    <a href="{{ route('site.useful',$usefulCat['slug'][$currentLang]) }}">{{ !empty($usefulCat['title'][$currentLang])? $usefulCat['title'][$currentLang]: null }}</a>
                                                </li>
                                            @endif
                                        @endforeach
                                    </ul>
                                @endif
                            </div>
                        </div>
                    </div>
                    @if(!empty($pages[0]))
                        @foreach($pages as $page)
                            @if(!empty($page['slug'][$currentLang]))
                                <div class="accordion accordion_responsive">
                                    <div class="accordion-item accordion-item_responsive">
                                        <button class="accordion-header accordion-header_responsive">
                                            {{ !empty($page['title'][$currentLang])? $page['title'][$currentLang]: null }}
                                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                        </button>
                                        <div class="accordion-content">
                                            @if(!empty($page['parentPage'][0]))
                                                <ul>
                                                    @foreach($page['parentPage'] as $pageContent)
                                                        @if(!empty($pageContent['parentCategories'][0]))
                                                            <li>
                                                                <div class="accordion-item">
                                                                    <button class="nested-accordion-header">
                                                                        {{ !empty($pageContent['title'][$currentLang])? $pageContent['title'][$currentLang]: null }}
                                                                        <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                    </button>
                                                                    <div class="nested-accordion-content">
                                                                        <ul>
                                                                            @foreach($pageContent['parentCategories'] as $pageParentCategories)
                                                                                @if(empty($pageParentCategories['subParentCategories'][0]))
                                                                                    <li><a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' =>  $pageParentCategories['slug'][$currentLang], 'subParentCategories' => null]) }}">{{ !empty($pageParentCategories['title'][$currentLang])? $pageParentCategories['title'][$currentLang]: null }}</a></li>
                                                                                @else
                                                                                    <li>
                                                                                        <div class="accordion-item">
                                                                                            <button class="nested-accordion-header">
                                                                                                {{ !empty($pageParentCategories['title'][$currentLang])? $pageParentCategories['title'][$currentLang]: null }}
                                                                                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                                            </button>
                                                                                            <div class="nested-accordion-content">
                                                                                                <ul>
                                                                                                    @foreach($pageParentCategories['subParentCategories'] as $pageSubCategories)
                                                                                                        @if(!empty($pageSubCategories['slug'][$currentLang]))
                                                                                                            <li><a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' =>  $pageParentCategories['slug'][$currentLang], 'subParentCategories' => $pageSubCategories['slug'][$currentLang]]) }}">{{ !empty($pageSubCategories['title'][$currentLang])? $pageSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                                        @endif
                                                                                                    @endforeach
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                @endif
                                                                            @endforeach
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        @else
                                                            @if(!empty($pageContent['slug'][$currentLang]))
                                                                <li>
                                                                    <a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' => null, 'subParentCategories' => null]) }}">{{ !empty($pageContent['title'][$currentLang])? $pageContent['title'][$currentLang]: null }}</a>
                                                                </li>
                                                            @endif
                                                        @endif
                                                    @endforeach
                                                </ul>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            @endif
                        @endforeach
                    @endif
                    {{-- @if(!empty($pages[0]))
                         @foreach($pages as $page)
                             <div class="accordion-item accordion-item_responsive">
                                 <button class="accordion-header accordion-header_responsive">
                                     {{ !empty($page['title'][$currentLang])? $page['title'][$currentLang]: null }}
                                     <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                 </button>
                                 <div class="accordion-content">
                                     <ul>
                                         @if(!empty($page['parentPage'][0]))
                                             @foreach($page['parentPage'] as $pageContent)
                                                 <li>
                                                     <a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang]]) }}">{{ !empty($pageContent['title'][$currentLang])? $pageContent['title'][$currentLang]: null }}</a>
                                                 </li>
                                             @endforeach
                                         @endif
                                     </ul>
                                 </div>
                             </div>
                         @endforeach
                     @endif--}}
                    <div class="accordion-item accordion-item_responsive">
                        <button class="accordion-header accordion-header_responsive">
                            @lang('site.education')
                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                        </button>
                        <div class="accordion-content">
                            @if(!empty($newsCategory[0]))
                                <ul>
                                    @foreach($newsCategory as $key => $newsCat)
                                        @if(!empty($newsCat['parentCategories'][0]))
                                            <li>
                                                <div class="accordion-item">
                                                    <button class="nested-accordion-header">
                                                        {{ !empty($newsCat['title'][$currentLang])? $newsCat['title'][$currentLang]: null }}
                                                        <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                    </button>
                                                    <div class="nested-accordion-content">
                                                        <ul>
                                                            @foreach($newsCat['parentCategories'] as $newsParentCategories)
                                                                @if(empty($newsParentCategories['subParentCategories'][0]))
                                                                    <li><a href="{{ route('site.news',$newsParentCategories['slug'][$currentLang]) }}">{{ !empty($newsParentCategories['title'][$currentLang])? $newsParentCategories['title'][$currentLang]: null }}</a></li>
                                                                @else
                                                                    <li>
                                                                        <div class="accordion-item">
                                                                            <button class="nested-accordion-header">
                                                                                {{ !empty($newsParentCategories['title'][$currentLang])? $newsParentCategories['title'][$currentLang]: null }}
                                                                                <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                                                            </button>
                                                                            <div class="nested-accordion-content">
                                                                                <ul>
                                                                                    @foreach($newsParentCategories['subParentCategories'] as $newsSubCategories)
                                                                                        <li><a href="{{ route('site.news',$newsSubCategories['slug'][$currentLang]) }}">{{ !empty($newsSubCategories['title'][$currentLang])? $newsSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                    @endforeach
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                @endif
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            </li>
                                        @else
                                            <li>
                                                <a href="{{ route('site.news',$newsCat['slug'][$currentLang]) }}">{{ !empty($newsCat['title'][$currentLang])? $newsCat['title'][$currentLang]: null }}</a>
                                            </li>
                                        @endif
                                    @endforeach
                                </ul>
                            @endif
                        </div>
                    </div>

                    <div class="accordion-item accordion-item_responsive">
                        <button class="accordion-header accordion-header_responsive">
                            @lang('site.our_contact')
                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                        </button>
                        <div class="accordion-content">
                            <ul>
                                <li><a href="{{ route('site.contact') }}">@lang('site.write_to_we')</a></li>
                                <li><a href="{{ route('site.receptionDays') }}">@lang('site.reception_days')</a></li>
                                <li><a href="{{ route('site.complaints') }}">@lang('site.complaints')</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <a href="{{ route('site.career') }}" class="accordion-header accordion-link">@lang('site.vacancies')</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
@endif
