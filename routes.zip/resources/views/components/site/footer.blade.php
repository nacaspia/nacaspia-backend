<footer class="container-fluid">
    <div class="row footer_width">
        <div class="contact">
            <div class="responsive_footer_info col-md-6 wow slideInLeft" data-wow-duration="1.5s">
                <div class="info">
                    <div class="info_row">
                        <span class="info_title">@lang('site.address'):</span>
                        <span class="adress">{{ !empty($setting['address'][$currentLang])? $setting['address'][$currentLang]: NULL }}</span>
                    </div>

                    <div class="info_row">
                        <span class="info_title">@lang('site.phone'):</span>
                        <div class="info_numbers">
                            <a href="tel:+994123770020">(+994 12) 377 00 20</a>
                            <a href="tel:+994123770021">(+994 12) 377 00 21</a>
                        </div>
                    </div>

                    <div class="info_row">
                        <span class="info_title">@lang('site.email'):</span>
                        <span>
                          <a href="mailto:{{ !empty($setting['email'])? $setting['email']: NULL }}" class="email">{{ !empty($setting['email'])? $setting['email']: NULL }}</a>
                        </span>
                    </div>
                </div>

                <div class="social_media social_media_footer">
                    <a href="mailto:{{ !empty($setting['email'])? $setting['email']: NULL }}" target="_blank" aria-label="Email">
                        <img src="{{ asset("site/assets/images/svg/email.svg") }}" alt="Email" />
                    </a>
                    <a href="{{ !empty($setting['twitter'])? $setting['twitter']: NULL }}" target="_blank" aria-label="X">
                        <img src="{{ asset("site/assets/images/svg/x.svg") }}" alt="X" />
                    </a>
                    <a href="{{ !empty($setting['facebook'])? $setting['facebook']: NULL }}" target="_blank" aria-label="Facebook">
                        <img src="{{ asset("site/assets/images/svg/facebook.svg") }}" alt="Facebook" />
                    </a>
                    <a href="{{ !empty($setting['youtube'])? $setting['youtube']: NULL }}" target="_blank" aria-label="YouTube">
                        <img src="{{ asset("site/assets/images/svg/youtube.svg") }}" alt="YouTube" />
                    </a>
                    <a href="{{ !empty($setting['linkedin'])? $setting['linkedin']: NULL }}" target="_blank" aria-label="LinkedIn">
                        <img src="{{ asset("site/assets/images/svg/linkedin.svg") }}" alt="LinkedIn" />
                    </a>
                    <a href="{{ !empty($setting['instagram'])? $setting['instagram']: NULL }}" target="_blank" aria-label="Instagram">
                        <img src="{{ asset("site/assets/images/svg/instagram.svg") }}" alt="Instagram" />
                    </a>
                </div>
                <div class="copyright">
                    <span>@lang('site.copyright')</span>
                </div>
            </div>
            <div class="col-md-5 footer_menu wow slideInRight" data-wow-duration="1.5s">
                <div class="accordion">


                    <div class="accordion-item">
                        <button class="accordion-header">@lang('site.institute')
                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                        </button>
                        <div class="accordion-content">
                            <ul>
                                @if(!empty($instituteCategory[0]))
                                    @foreach($instituteCategory as $key => $instituteCat)
                                        <li>
                                            @if(!empty($instituteCat['parentCategories'][0]))
                                                <div class="accordion-item">
                                                    <button class="nested-accordion-header">{{ !empty($instituteCat['title'][$currentLang])? $instituteCat['title'][$currentLang]: null }}
                                                        <span><img src="{{ asset('site/assets/images/svg/plus.svg') }}" alt=""/></span>
                                                    </button>
                                                    <div class="nested-accordion-content">
                                                        <ul>
                                                            @foreach($instituteCat['parentCategories'] as $instituteParentCategories)
                                                                @if(empty($instituteParentCategories['subParentCategories'][0]))
                                                                    <li> <a href="{{ route('site.institute',$instituteParentCategories['slug'][$currentLang]) }}">{{ !empty($instituteParentCategories['title'][$currentLang])? $instituteParentCategories['title'][$currentLang]: null }}</a></li>
                                                                @else
                                                                    <li>
                                                                        <div class="accordion-item">
                                                                            <button class="nested-accordion-header">{{ !empty($instituteParentCategories['title'][$currentLang])? $instituteParentCategories['title'][$currentLang]: null }}
                                                                                <span><img src="{{ asset('site/assets/images/svg/plus.svg') }}" alt=""/></span>
                                                                            </button>
                                                                            <div class="nested-accordion-content">
                                                                                <ul>
                                                                                    @foreach($instituteParentCategories['subParentCategories'] as $instituteSubCategories)
                                                                                        <li><a href="{{ route('site.institute',$instituteSubCategories['slug'][$currentLang]) }}">{{ !empty($instituteSubCategories['title'][$currentLang])? $instituteSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                    @endforeach
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                @endif
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            @else
                                                <a href="{{ route('site.institute',$instituteCat['slug'][$currentLang]) }}">{{ !empty($instituteCat['title'][$currentLang])? $instituteCat['title'][$currentLang]: null }}</a>
                                            @endif
                                        </li>
                                    @endforeach
                                @endif
                            </ul>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <button class="accordion-header">@lang('site.laboratory')
                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                        </button>
                        <div class="accordion-content">
                            <ul>
                                @if(!empty($laboratoryCategory[0]))
                                    @foreach($laboratoryCategory as $key => $laboratoryCat)
                                        <li>
                                            @if(!empty($laboratoryCat['parentCategories'][0]))
                                                <div class="accordion-item">
                                                    <button class="nested-accordion-header">{{ !empty($laboratoryCat['title'][$currentLang])? $laboratoryCat['title'][$currentLang]: null }}
                                                        <span><img src="{{ asset('site/assets/images/svg/plus.svg') }}" alt=""/></span>
                                                    </button>
                                                    <div class="nested-accordion-content">
                                                        <ul>
                                                            @foreach($laboratoryCat['parentCategories'] as $laboratoryParentCategories)
                                                                @if(empty($laboratoryParentCategories['subParentCategories'][0]))
                                                                    <li> <a href="{{ route('site.laboratory',$laboratoryParentCategories['slug'][$currentLang]) }}">{{ !empty($laboratoryParentCategories['title'][$currentLang])? $laboratoryParentCategories['title'][$currentLang]: null }}</a></li>
                                                                @else
                                                                    <li>
                                                                        <div class="accordion-item">
                                                                            <button class="nested-accordion-header">{{ !empty($laboratoryParentCategories['title'][$currentLang])? $laboratoryParentCategories['title'][$currentLang]: null }}
                                                                                <span><img src="{{ asset('site/assets/images/svg/plus.svg') }}" alt=""/></span>
                                                                            </button>
                                                                            <div class="nested-accordion-content">
                                                                                <ul>
                                                                                    @foreach($laboratoryParentCategories['subParentCategories'] as $laboratorySubCategories)
                                                                                        <li><a href="{{ route('site.laboratory',$laboratorySubCategories['slug'][$currentLang]) }}">{{ !empty($laboratorySubCategories['title'][$currentLang])? $laboratorySubCategories['title'][$currentLang]: null }}</a></li>
                                                                                    @endforeach
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                @endif
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            @else
                                                <a href="{{ route('site.laboratory',$laboratoryCat['slug'][$currentLang]) }}">{{ !empty($laboratoryCat['title'][$currentLang])? $laboratoryCat['title'][$currentLang]: null }}</a>
                                            @endif
                                        </li>
                                    @endforeach
                                @endif
                            </ul>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <button class="accordion-header">@lang('site.services')
                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                        </button>
                        <div class="accordion-content">
                            <ul>
                                @if(!empty($services[0]))
                                    @foreach($services as $key => $servicesCat)
                                        <li>
                                            @if(!empty($servicesCat['parentCategories'][0]))
                                                <div class="accordion-item">
                                                    <button class="nested-accordion-header">{{ !empty($servicesCat['title'][$currentLang])? $servicesCat['title'][$currentLang]: null }}
                                                        <span><img src="{{ asset('site/assets/images/svg/plus.svg') }}" alt=""/></span>
                                                    </button>
                                                    <div class="nested-accordion-content">
                                                        <ul>
                                                            @foreach($servicesCat['parentCategories'] as $servicesParentCategories)
                                                                @if(empty($servicesParentCategories['subParentCategories'][0]))
                                                                    <li> <a href="{{ route('site.service',$servicesParentCategories['slug'][$currentLang]) }}">{{ !empty($servicesParentCategories['title'][$currentLang])? $servicesParentCategories['title'][$currentLang]: null }}</a></li>
                                                                @else
                                                                    <li>
                                                                        <div class="accordion-item">
                                                                            <button class="nested-accordion-header">{{ !empty($servicesParentCategories['title'][$currentLang])? $servicesParentCategories['title'][$currentLang]: null }}
                                                                                <span><img src="{{ asset('site/assets/images/svg/plus.svg') }}" alt=""/></span>
                                                                            </button>
                                                                            <div class="nested-accordion-content">
                                                                                <ul>
                                                                                    @foreach($servicesParentCategories['subParentCategories'] as $servicesSubCategories)
                                                                                        <li><a href="{{ route('site.service',$servicesSubCategories['slug'][$currentLang]) }}">{{ !empty($servicesSubCategories['title'][$currentLang])? $servicesSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                    @endforeach
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                @endif
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            @else
                                                <a href="{{ route('site.service',$servicesCat['slug'][$currentLang]) }}">{{ !empty($servicesCat['title'][$currentLang])? $servicesCat['title'][$currentLang]: null }}</a>
                                            @endif
                                        </li>
                                    @endforeach
                                @endif
                            </ul>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <button class="accordion-header">@lang('site.useful')
                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                        </button>
                        <div class="accordion-content">
                            <ul>
                                @if(!empty($usefulCategory[0]))
                                    @foreach($usefulCategory as $key => $usefulCat)
                                        <li>
                                            @if(!empty($usefulCat['parentCategories'][0]))
                                                <div class="accordion-item">
                                                    <button class="nested-accordion-header">{{ !empty($usefulCat['title'][$currentLang])? $usefulCat['title'][$currentLang]: null }}
                                                        <span><img src="{{ asset('site/assets/images/svg/plus.svg') }}" alt=""/></span>
                                                    </button>
                                                    <div class="nested-accordion-content">
                                                        <ul>
                                                            @foreach($usefulCat['parentCategories'] as $usefulParentCategories)
                                                                @if(empty($usefulParentCategories['subParentCategories'][0]))
                                                                    <li> <a href="{{ route('site.useful',$usefulParentCategories['slug'][$currentLang]) }}">{{ !empty($usefulParentCategories['title'][$currentLang])? $usefulParentCategories['title'][$currentLang]: null }}</a></li>
                                                                @else
                                                                    <li>
                                                                        <div class="accordion-item">
                                                                            <button class="nested-accordion-header">{{ !empty($usefulParentCategories['title'][$currentLang])? $usefulParentCategories['title'][$currentLang]: null }}
                                                                                <span><img src="{{ asset('site/assets/images/svg/plus.svg') }}" alt=""/></span>
                                                                            </button>
                                                                            <div class="nested-accordion-content">
                                                                                <ul>
                                                                                    @foreach($usefulParentCategories['subParentCategories'] as $usefulSubCategories)
                                                                                        <li><a href="{{ route('site.useful',$usefulSubCategories['slug'][$currentLang]) }}">{{ !empty($usefulSubCategories['title'][$currentLang])? $usefulSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                    @endforeach
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                @endif
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            @else
                                                <a href="{{ route('site.useful',$usefulCat['slug'][$currentLang]) }}">{{ !empty($usefulCat['title'][$currentLang])? $usefulCat['title'][$currentLang]: null }}</a>
                                            @endif
                                        </li>
                                    @endforeach
                                @endif
                            </ul>
                        </div>
                    </div>
                    @if(!empty($pages[0]))
                        @foreach($pages as $page)
                            @if(!empty($page['slug'][$currentLang]))
                                <div class="accordion-item">
                                    <button class="accordion-header">
                                        {{ !empty($page['title'][$currentLang])? $page['title'][$currentLang]: null }}
                                        <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                                    </button>
                                    <div class="accordion-content">
                                        <ul>
                                            @if(!empty($page['parentPage'][0]))
                                                @foreach($page['parentPage'] as $pageContent)
                                                    @if(!empty($pageContent['slug'][$currentLang]))
                                                        <li>
                                                            @if(!empty($pageContent['parentCategories'][0]))
                                                                <div class="accordion-item">
                                                                    <button class="nested-accordion-header">
                                                                        {{ !empty($pageContent['title'][$currentLang])? $pageContent['title'][$currentLang]: null }}
                                                                        <span><img src="{{ asset('site/assets/images/svg/plus.svg') }}" alt=""/></span>
                                                                    </button>
                                                                    <div class="nested-accordion-content">
                                                                        <ul>
                                                                            @foreach($pageContent['parentCategories'] as $pageParentCategories)
                                                                                @if(empty($pageParentCategories['subParentCategories'][0]))
                                                                                    <li><a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' =>  $pageParentCategories['slug'][$currentLang], 'subParentCategories' => null]) }}">{{ !empty($pageParentCategories['title'][$currentLang])? $pageParentCategories['title'][$currentLang]: null }}</a></li>
                                                                                @else
                                                                                    <li>
                                                                                        <div class="accordion-item">
                                                                                            <button class="nested-accordion-header">{{ !empty($pageParentCategories['title'][$currentLang])? $pageParentCategories['title'][$currentLang]: null }}
                                                                                                <span><img src="{{ asset('site/assets/images/svg/plus.svg') }}" alt=""/></span>
                                                                                            </button>
                                                                                            <div class="nested-accordion-content">
                                                                                                <ul>
                                                                                                    @foreach($pageParentCategories['subParentCategories'] as $pageSubCategories)
                                                                                                        @if(!empty($pageSubCategories['slug'][$currentLang]))
                                                                                                            <li><a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' =>  $pageParentCategories['slug'][$currentLang], 'subParentCategories' => $pageSubCategories['slug'][$currentLang]]) }}">{{ !empty($pageSubCategories['title'][$currentLang])? $pageSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                                        @endif
                                                                                                    @endforeach
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                @endif
                                                                            @endforeach
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            @else
                                                                <a href="{{ route('site.page',['slug' => $page['slug'][$currentLang],'parentSlug' => $pageContent['slug'][$currentLang], 'pageParentCategories' => null, 'subParentCategories' => null]) }}">{{ !empty($pageContent['title'][$currentLang])? $pageContent['title'][$currentLang]: null }}</a>
                                                            @endif
                                                        </li>
                                                    @endif
                                                @endforeach
                                            @endif
                                            {{--@if(!empty($newsCategory[0]))
                                                @foreach($newsCategory as $newsCat)
                                                        <?php $catSlug = !empty($newsCat['slug'][$currentLang]) ? $newsCat['slug'][$currentLang] : null; ?>
                                                    <li><a href="{{ route('site.news',['slug' => $catSlug ]) }}">{{ !empty($newsCat['title'][$currentLang])? $newsCat['title'][$currentLang]: null }}</a></li>
                                                @endforeach
                                            @endif--}}
                                        </ul>
                                    </div>
                                </div>
                            @endif
                        @endforeach
                    @endif
                    <div class="accordion-item">
                        <button class="accordion-header">@lang('site.education')
                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                        </button>
                        <div class="accordion-content">
                            <ul>
                                @if(!empty($newsCategory[0]))
                                    @foreach($newsCategory as $key => $newsCat)
                                        <li>
                                            @if(!empty($newsCat['parentCategories'][0]))
                                                <div class="accordion-item">
                                                    <button class="nested-accordion-header">{{ !empty($newsCat['title'][$currentLang])? $newsCat['title'][$currentLang]: null }}
                                                        <span><img src="{{ asset('site/assets/images/svg/plus.svg') }}" alt=""/></span>
                                                    </button>
                                                    <div class="nested-accordion-content">
                                                        <ul>
                                                            @foreach($newsCat['parentCategories'] as $newsParentCategories)
                                                                @if(empty($newsParentCategories['subParentCategories'][0]))
                                                                    <li> <a href="{{ route('site.news',$newsParentCategories['slug'][$currentLang]) }}">{{ !empty($newsParentCategories['title'][$currentLang])? $newsParentCategories['title'][$currentLang]: null }}</a></li>
                                                                @else
                                                                    <li>
                                                                        <div class="accordion-item">
                                                                            <button class="nested-accordion-header">{{ !empty($newsParentCategories['title'][$currentLang])? $newsParentCategories['title'][$currentLang]: null }}
                                                                                <span><img src="{{ asset('site/assets/images/svg/plus.svg') }}" alt=""/></span>
                                                                            </button>
                                                                            <div class="nested-accordion-content">
                                                                                <ul>
                                                                                    @foreach($newsParentCategories['subParentCategories'] as $newsSubCategories)
                                                                                        <li><a href="{{ route('site.news',$newsSubCategories['slug'][$currentLang]) }}">{{ !empty($newsSubCategories['title'][$currentLang])? $newsSubCategories['title'][$currentLang]: null }}</a></li>
                                                                                    @endforeach
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </li>
                                                                @endif
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                </div>
                                            @else
                                                <a href="{{ route('site.news',$newsCat['slug'][$currentLang]) }}">{{ !empty($newsCat['title'][$currentLang])? $usefulCat['title'][$currentLang]: null }}</a>
                                            @endif
                                        </li>
                                    @endforeach
                                @endif
                                {{--@if(!empty($newsCategory[0]))
                                    @foreach($newsCategory as $newsCat)
                                            <?php $catSlug = !empty($newsCat['slug'][$currentLang]) ? $newsCat['slug'][$currentLang] : null; ?>
                                        <li><a href="{{ route('site.news',['slug' => $catSlug ]) }}">{{ !empty($newsCat['title'][$currentLang])? $newsCat['title'][$currentLang]: null }}</a></li>
                                    @endforeach
                                @endif--}}
                            </ul>
                        </div>
                    </div>

                    <div class="accordion-item">
                        <button class="accordion-header">@lang('site.our_contact')
                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                        </button>
                        <div class="accordion-content">
                            <ul>
                                <li><a href="{{ route('site.contact') }}">@lang('site.write_to_we')</a></li>
                                <li><a href="{{ route('site.receptionDays') }}">@lang('site.reception_days')</a></li>
                                <li><a href="{{ route('site.complaints') }}">@lang('site.complaints')</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <button class="accordion-header">@lang('site.career')
                            <span><img src="{{ asset("site/assets/images/svg/plus.svg") }}" alt=""/></span>
                        </button>
                        <div class="accordion-content">
                            <ul>
                                <li><a href="{{ route('site.career') }}">@lang('site.vacancies')</a></li>
                                <li><a href="{{ route('site.volunteer') }}">@lang('site.volunteer')</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<script src="{{ asset("site/assets/plugins/swiper/js/swiper-bundle.min.js") }}"></script>
<script src="{{ asset("site/assets/plugins/wow/js/wow.min.js") }}"></script>
<script src="{{ asset('site/assets/js/main.js') }}"></script>
@yield('site.js')
</body>
</html>
