@extends('admin.layouts.app')
@section('admin.title')
    @lang('admin.categories')
@endsection
@section('admin.css')
    <meta name="_token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{ asset('admin/assets/vendor/css/jquery.uploader.css') }}">
@endsection
@section('admin.content')
    <!-- main content start -->
    <div class="main-content">
        @include('components.admin.error')
        <div class="row">
            <div class="col-12">
                <div class="panel">

                    <div class="panel-header">
                        <h2>@lang('admin.services')</h2>
                        @can('services-create')
                            <a class="btn btn-sm btn-primary" href="{{ route('admin.service.create') }}">
                                <i class="fa-light fa-plus"></i> @lang('admin.add')
                            </a>
                        @endcan
                    </div>
                    <div class="panel-body">
                        <div class="row" id="sortable">
                            @if(!empty($servicesCategories[0]) && isset($servicesCategories[0]))
                                @foreach($servicesCategories as $data)
                                    @if(empty($data['parent_id']))
                                        <div class="col-sm-6" data-id="{{ $data['id'] }}">
                                            <div class="card">
                                                <div class="card-header">
                                                    {{ !empty($data['title'][$currentLang])? $data['title'][$currentLang]: null }}
                                                    @if(!empty($data['parentCategories'][0]) && isset($data['parentCategories'][0]))
                                                        <button class="btn btn-sm btn-icon btn-primary" data-bs-toggle="modal"
                                                                data-bs-target="#eyeMain{{$data['id']}}"><i
                                                                class="fa-light fa-eye"></i>
                                                        </button>
                                                    @endif
                                                    @can('services-edit')
                                                        <a href="{{ route('admin.service.edit',$data['id']) }}" class="btn btn-sm btn-icon btn-primary" title="@lang('admin.edit')">
                                                            <i class="fa-light fa-edit"></i>
                                                        </a>
                                                    @endcan
                                                    @can('services-delete')
                                                        <button class="btn btn-sm btn-icon btn-danger" data-bs-toggle="modal" data-bs-target="#deleteMain{{$data['id']}}">
                                                            <i class="fa-light fa-trash-can"></i>
                                                        </button>
                                                    @endcan
                                                </div>
                                                @if(!empty($data['image']))
                                                <div class="card-body animation-card">
                                                    <div class="text-center" data-aos="flip-left">
                                                        <img src="{{ asset('uploads/services/'.$data->image) }}" alt="{{ !empty($data['title'][$currentLang])? $data['title'][$currentLang]: null }}">
                                                    </div>
                                                </div>
                                                @endif
                                            </div>
                                        </div>
                                    @endif
                                @endforeach
                            @endif
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- main content end -->
    @if(!empty($servicesCategories[0]) && isset($servicesCategories[0]))
        @foreach($servicesCategories as $value)
            @if(empty($value['parent_id']))
                <!-- edit task modal -->
                <div class="modal fade" id="deleteMain{{$value['id']}}" tabindex="-1" aria-labelledby="deleteMain{{$value['id']}}Label" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h2 class="modal-title" id="deleteMain{{$value['id']}}Label">@lang('admin.delete')</h2>
                                <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                                    <i class="fa-light fa-times"></i>
                                </button>
                            </div>
                            <form action="{{ route('admin.service.destroy',$value['id']) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <div class="modal-body">
                                    <h2>@lang('admin.delete_about')</h2>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.not')</button>
                                    <button type="submit" class="btn btn-sm btn-primary">@lang('admin.yes')</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @if(!empty($value['parentCategories'][0]) && isset($value['parentCategories'][0]))
                    <!-- edit task modal -->
                    <div class="modal fade" id="eyeMain{{$value['id']}}" tabindex="-1" aria-labelledby="eyeMain{{$value['id']}}Label" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                            <div class="modal-content">
                                <div class="row" id="sortable">
                                    @if(!empty($value['parentCategories'][0]) && isset($value['parentCategories'][0]))
                                        @foreach($value['parentCategories'] as $parentCategory)
                                            <div class="col-sm-6" data-id="{{ $parentCategory['id'] }}">
                                                <div class="card">
                                                    <div class="card-header">
                                                        {{ !empty($parentCategory['title'][$currentLang])? $parentCategory['title'][$currentLang]: null }}
                                                        @if(!empty($parentCategory['subParentCategories'][0]) && isset($parentCategory['subParentCategories'][0]))
                                                            <button class="btn btn-sm btn-icon btn-primary" data-bs-toggle="modal"
                                                                    data-bs-target="#eyeParent{{$parentCategory['id']}}"><i
                                                                    class="fa-light fa-eye"></i>
                                                            </button>
                                                        @endif
                                                        @can('services-edit')
                                                            <a href="{{ route('admin.service.edit',$parentCategory['id']) }}" class="btn btn-sm btn-icon btn-primary" title="@lang('admin.edit')">
                                                                <i class="fa-light fa-edit"></i>
                                                            </a>
                                                        @endcan
                                                        @can('services-delete')
                                                            <button class="btn btn-sm btn-icon btn-danger" data-bs-toggle="modal" data-bs-target="#deleteParent{{$parentCategory['id']}}">
                                                                <i class="fa-light fa-trash-can"></i>
                                                            </button>
                                                        @endcan
                                                    </div>
                                                    @if(!empty($parentCategory['image']))
                                                    <div class="card-body animation-card">
                                                        <div class="text-center" data-aos="flip-left">
                                                            <img src="{{ asset('uploads/services/'.$parentCategory->image) }}" alt="{{ !empty($parentCategory['title'][$currentLang])? $parentCategory['title'][$currentLang]: null }}">
                                                        </div>
                                                    </div>
                                                    @endif
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- edit task modal -->
                    @foreach($value['parentCategories'] as $parentCategory)
                        <div class="modal fade" id="deleteParent{{$parentCategory['id']}}" tabindex="-1" aria-labelledby="deleteParent{{$parentCategory['id']}}Label" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h2 class="modal-title" id="deletecategory{{$parentCategory['id']}}Label">@lang('admin.delete')</h2>
                                        <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                                            <i class="fa-light fa-times"></i>
                                        </button>
                                    </div>
                                    <form action="{{ route('admin.service.destroy',$parentCategory['id']) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <div class="modal-body">
                                            <h2>@lang('admin.delete_about')</h2>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.not')</button>
                                            <button type="submit" class="btn btn-sm btn-primary">@lang('admin.yes')</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        @if(!empty($parentCategory['subParentCategories'][0]) && isset($parentCategory['subParentCategories'][0]))
                            <div class="modal fade" id="eyeParent{{$parentCategory['id']}}" tabindex="-1" aria-labelledby="eyeParent{{$parentCategory['id']}}Label" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                    <div class="modal-content">
                                        <div class="row" id="sortable">
                                            @if(!empty($parentCategory['subParentCategories']) && isset($parentCategory['subParentCategories']))
                                                @foreach($parentCategory['subParentCategories'] as $subParentCategory)
                                                    <div class="col-sm-6" data-id="{{ $subParentCategory['id'] }}">
                                                        <div class="card">
                                                            <div class="card-header">
                                                                {{ !empty($subParentCategory['title'][$currentLang])? $subParentCategory['title'][$currentLang]: null }}
                                                                @can('services-edit')
                                                                    <a href="{{ route('admin.service.edit',$subParentCategory['id']) }}" class="btn btn-sm btn-icon btn-primary" title="@lang('admin.edit')">
                                                                        <i class="fa-light fa-edit"></i>
                                                                    </a>
                                                                @endcan
                                                                @can('services-delete')
                                                                    <button class="btn btn-sm btn-icon btn-danger" data-bs-toggle="modal" data-bs-target="#deleteSubParent{{$subParentCategory['id']}}">
                                                                        <i class="fa-light fa-trash-can"></i>
                                                                    </button>
                                                                @endcan
                                                            </div>
                                                            @if(empty($subParentCategory['image']))
                                                            <div class="card-body animation-card">
                                                                <div class="text-center" data-aos="flip-left">
                                                                    <img src="{{ asset('uploads/services/'.$subParentCategory->image) }}" alt="{{ !empty($subParentCategory['title'][$currentLang])? $subParentCategory['title'][$currentLang]: null }}">
                                                                </div>
                                                            </div>
                                                            @endif
                                                        </div>
                                                    </div>
                                                @endforeach
                                            @endif
                                        </div>

                                    </div>
                                </div>
                            </div>
                            @foreach($parentCategory['subParentCategories'] as $subParentCategory)
                                <div class="modal fade" id="deleteSubParent{{$subParentCategory['id']}}" tabindex="-1" aria-labelledby="deleteSubParent{{$subParentCategory['id']}}Label" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h2 class="modal-title" id="deleteSubParent{{$subParentCategory['id']}}Label">@lang('admin.delete')</h2>
                                                <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                                                    <i class="fa-light fa-times"></i>
                                                </button>
                                            </div>
                                            <form action="{{ route('admin.service.destroy',$subParentCategory['id']) }}" method="POST">
                                                @csrf
                                                @method('DELETE')
                                                <div class="modal-body">
                                                    <h2>@lang('admin.delete_about')</h2>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.not')</button>
                                                    <button type="submit" class="btn btn-sm btn-primary">@lang('admin.yes')</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        @endif
                    @endforeach
                @endif
            @endif
        @endforeach
    @endif
@endsection
@section('admin.js')
    <script>
        $(document).ready(function () {
            $('#input-category').on('change', function () {
                let parentId = $(this).val();
                let subCategoryWrapper = $('#sub-category-wrapper');
                let subCategorySelect = $('#input-sub-category');

                // Əgər parent_id boşdursa, sub_category selectini gizlədirik
                if (!parentId) {
                    subCategoryWrapper.hide();
                    subCategorySelect.html('<option value="">@lang("admin.choose")</option>');
                    return;
                }

                // AJAX ilə alt kateqoriyaları gətiririk
                $.ajax({
                    url: '{{ route('admin.laboratory-category.getParentCategories') }}', // Bu URL `web.php` faylında göstərilməlidir
                    type: 'GET',
                    data: { category_id: parentId },
                    success: function (response) {
                        if (response.success && response.parentCategories.length > 0) {
                            // Alt kateqoriyaları doldur
                            subCategorySelect.html('<option value="">@lang("admin.choose")</option>');
                            $.each(response.parentCategories, function (index, subCategory) {
                                subCategorySelect.append(
                                    `<option value="${subCategory.id}">${subCategory.title}</option>`
                                );
                            });
                            subCategoryWrapper.show();
                        } else {
                            // Alt kateqoriya yoxdursa, seçimi gizlət
                            subCategoryWrapper.hide();
                            subCategorySelect.html('<option value="">@lang("admin.choose")</option>');
                        }
                    },
                    error: function () {
                        alert('@lang("admin.error_loading_categories")');
                    }
                });
            });
        });
    </script>
    <script src="{{ asset('admin/assets/vendor/js/jquery.uploader.min.js') }}"></script>
    <script src="{{ asset('admin/assets/js/category.js') }}"></script>
@endsection
