@extends('admin.layouts.app')
@section('admin.title')
    @lang('admin.edit')
@endsection
@section('admin.css')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.css">
@endsection
@section('admin.content')
    <div class="main-content">
        <div class="dashboard-breadcrumb mb-25">
            <h2>@lang('admin.add')</h2>
        </div>
        @include('components.admin.error')
        <div class="row">
            <div class="col-12">
                <form action="{{ route('admin.page-content.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="panel">
                        <div class="panel-body">
                            <ul class="nav nav-pills nav-justified" role="tablist">
                                @if(!empty($locales))
                                    @foreach($locales as $key => $lang)
                                        <li class="nav-item waves-effect waves-light">
                                            <a class="nav-link @if(++$key ==1) active @endif" data-bs-toggle="tab"
                                               href="#{{$lang->code}}" role="tab">
                                                <span class="d-none d-sm-block">{{$lang->code}}</span>
                                            </a>
                                        </li>
                                    @endforeach
                                @endif
                                <li class="nav-item waves-effect waves-light">
                                    <a class="nav-link" data-bs-toggle="tab"
                                       href="#other" role="tab">
                                        <span class="d-none d-sm-block">@lang('admin.other')</span>
                                    </a>
                                </li>
                            </ul>
                            <div class="tab-content p-3 text-muted">
                                @if(!empty($locales))
                                    @foreach($locales as $key => $lang)
                                        <div class="tab-pane @if(++$key ==1) active @endif" id="{{$lang['code']}}"
                                             role="tabpanel">
                                            <div class="row g-3">
                                                <div class="col-12">
                                                    <label class="form-label">@lang('admin.title') - {{$lang['code']}}</label>
                                                    <input type="text" class="form-control" name="title[{{$lang['code']}}]">
                                                </div>
                                                <div class="col-12">
                                                    <label class="form-label">@lang('admin.text') - {{$lang['code']}}</label>
                                                    <textarea class="form-control" type="text" name="text[{{$lang['code']}}]" ></textarea>
                                                </div>
                                                <div class="col-12">
                                                    <label class="form-label">@lang('admin.full_text') - {{$lang['code']}}</label>
                                                    <textarea class="editor form-control"
                                                              data-locale="{{ $lang['code'] }}"
                                                              data-csrf-token="{{ csrf_token() }}"
                                                              name="fulltext[{{$lang['code']}}]"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                @endif
                                <div class="tab-pane" id="other" role="tabpanel">
                                    <div class="row g-3">
                                        <div class="col-md-4">
                                            <label for="page_id" class="form-label">@lang('admin.main_page')</label>
                                            <select class="form-control" name="page_id" id="page_id">
                                                <option value="">@lang('admin.choose')</option>
                                                @foreach($mainPages as $page)
                                                    <option value="{{ $page->id }}">
                                                        {{ json_decode($page, true)['title'][$currentLang] ?? null }}
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="col-md-4" id="parent-page-wrapper" style="display: none;">
                                            <label for="parent_page_id" class="form-label">@lang('admin.parent_page')</label>
                                            <select class="form-control" name="parent_page_id" id="parent_page_id">
                                                <option value="" data-type="">@lang('admin.choose')</option>
                                            </select>
                                        </div>
                                        <div class="col-md-12 mt-3">
                                            <label for="parent-category" class="form-label">@lang('admin.parent_category')</label>
                                            <select class="form-control" name="page_parent_id" id="parent-category" disabled>
                                                <option value="">@lang('admin.choose')</option>
                                            </select>
                                        </div>
                                        <div class="col-md-12 mt-3">
                                            <label for="sub-category" class="form-label">@lang('admin.sub_category')</label>
                                            <select class="form-control" name="page_sub_parent_id" id="sub-category" disabled>
                                                <option value="">@lang('admin.choose')</option>
                                            </select>
                                        </div>


                                        <div class="col-sm-4">
                                            <label class="form-label">@lang('admin.status')</label>
                                            <select class="form-control" name="status">
                                                <option value="1" >@lang('admin.active')</option>
                                                <option value="0" >@lang('admin.nonactive')</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6" id="file-input-wrapper" style="display: none;">
                                            <label class="form-label">@lang('admin.file')</label>
                                            <input  class="form-control" type="file" name="file" >
                                        </div>
                                        <div class="col-md-6" id="slider-input-wrapper" style="display: none;">
                                            <div class="col-xxl-9 col-sm-8">
                                                <label class="form-label">@lang('admin.slider_image')</label>
                                                <input type="file" id="multipleUpload" name="slider_image[]" multiple>
                                                <p> Şəkilin maksimum ölçüsü  1228x1228 piksel olmalıdır. Şəkil faylının maksimum ölçüsü 226 KB olmalıdır.</p>
                                                <div id="sliderImagePreview" style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;"></div>
                                            </div>
                                        </div>
                                        <div class="col-sm-12" id="image-input-wrapper" style="display: none;">

                                            <div class="col-sm-4" >
                                                <label class="form-label">@lang('admin.datetime')</label>
                                                <input type="datetime-local" class="form-control" name="datetime">
                                            </div>
                                            <div class="col-lg-8 col-md-7">
                                                <div class="card component-jquery-uploader">
                                                    <div class="card-header">
                                                        @lang('admin.images')
                                                    </div>
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-xxl-9 col-sm-8">
                                                                <label class="form-label">@lang('admin.main_image')</label>
                                                                <input type="file" name="image" id="mainImageUpload">
                                                                <p> Şəkilin maksimum ölçüsü  1228x1228 piksel olmalıdır. Şəkil faylının maksimum ölçüsü 226 KB olmalıdır.</p>
                                                                <div id="mainImagePreview" style="margin-top: 10px;"></div>
                                                            </div>
                                                            <div class="col-xxl-9 col-sm-8">
                                                                <label class="form-label">@lang('admin.slider_image')</label>
                                                                <input type="file" id="multipleUpload" name="slider_image[]" multiple>
                                                                <p> Şəkilin maksimum ölçüsü  1228x1228 piksel olmalıdır. Şəkil faylının maksimum ölçüsü 226 KB olmalıdır.</p>
                                                                <div id="sliderImagePreview" style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary">@lang('admin.save')</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
@section('admin.js')
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const pageParentSelect = document.getElementById('parent_page_id');
            const sliderWrapper = document.getElementById('slider-input-wrapper');
            const fileWrapper = document.getElementById('file-input-wrapper');
            const imageWrapper = document.getElementById('image-input-wrapper');

            // Son seçimi localStorage-da saxlamaq
            const savedDataType = localStorage.getItem('selectedDataType');
            const savedParentType = localStorage.getItem('selectedParentType');
            const savedSubParentType = localStorage.getItem('selectedSubParentType');

            // Əgər saxlanmış data-* varsa, uyğun olaraq görünən elementi təyin et
            if (savedDataType || savedParentType || savedSubParentType) {
                showElementByType(savedDataType, savedParentType, savedSubParentType);
            }

            // Seçim dəyişdikdə
            pageParentSelect.addEventListener('change', function () {
                const selectedOption = pageParentSelect.options[pageParentSelect.selectedIndex];
                const dataType = selectedOption.getAttribute('data-type');
                const parentType = selectedOption.getAttribute('data-parentType');
                const subParentType = selectedOption.getAttribute('data-subParentType');

                // Son seçimi localStorage-da saxla
                localStorage.setItem('selectedDataType', dataType);
                localStorage.setItem('selectedParentType', parentType);
                localStorage.setItem('selectedSubParentType', subParentType);

                // Seçimə uyğun olaraq elementi göstər
                showElementByType(dataType, parentType, subParentType);
            });

            // Məlumat tipinə uyğun olaraq uyğun elementi göstərmək üçün funksiya
            function showElementByType(dataType, parentType, subParentType) {
                // Hamısını gizlət
                sliderWrapper.style.display = 'none';
                fileWrapper.style.display = 'none';
                imageWrapper.style.display = 'none';

                // Dəyərlərə görə göstər
                if(dataType === 'slider' || parentType === 'slider' || subParentType === 'slider'){
                    sliderWrapper.style.display = 'block';
                }else if(dataType === 'file_content' || parentType === 'file_content' || subParentType === 'file_content'){
                    fileWrapper.style.display = 'block';
                }else if(dataType === 'image_content' || parentType === 'image_content' || subParentType === 'image_content'){
                    imageWrapper.style.display = 'block';
                }
            }
        });


        /*  document.addEventListener('DOMContentLoaded', function () {
              const pageParentSelect = document.getElementById('parent_page_id');
              const sliderWrapper = document.getElementById('slider-input-wrapper');
              const fileWrapper = document.getElementById('file-input-wrapper');
              const imageWrapper = document.getElementById('image-input-wrapper');

              pageParentSelect.addEventListener('change', function () {
                  const selectedOption = pageParentSelect.options[pageParentSelect.selectedIndex];
                  const dataType = selectedOption.getAttribute('data-type');

                  // Hamısını gizlət
                  sliderWrapper.style.display = 'none';
                  fileWrapper.style.display = 'none';
                  imageWrapper.style.display = 'none';

                  // Dəyərlərə görə göstər
                  if (dataType === 'slider') {
                      sliderWrapper.style.display = 'block';
                  } else if (dataType === 'file_content') {
                      fileWrapper.style.display = 'block';
                  } else if (dataType === 'image_content') {
                      imageWrapper.style.display = 'block';
                  }
              });
          });*/
    </script>

    <script>
        $(document).ready(function () {
            // Main Page seçildikdə
            $('#page_id').on('change', function () {
                let pageId = $(this).val();
                let parentWrapper = $('#parent-page-wrapper');
                let parentSelect = $('#parent_page_id');

                // Seçim boşdursa
                if (!pageId) {
                    parentWrapper.hide();
                    parentSelect.html('<option value="">@lang("admin.choose")</option>');
                    return;
                }

                // AJAX ilə parent səhifələri əldə et
                $.ajax({
                    url: '{{ route('admin.pages.getParentPage') }}',
                    type: 'GET',
                    data: { parent_id: pageId },
                    success: function (response) {
                        if (response.success && response.parentPage.length > 0) {
                            parentSelect.html('<option value="" data-type="">@lang("admin.choose")</option>');
                            $.each(response.parentPage, function (index, parent) {
                                parentSelect.append(
                                    `<option value="${parent.id}" data-type="${parent.page_type}">${parent.title}</option>`
                                );
                            });
                            parentWrapper.show();
                        } else {
                            parentWrapper.hide();
                            parentSelect.html('<option value="" data-type="">@lang("admin.choose")</option>');
                        }
                    },
                    error: function () {
                        alert('@lang("admin.error_loading_categories")');
                    }
                });
            });

            // Parent seçildikdə Sub-kateqoriyaları yüklə
            $('#parent_page_id').on('change', function () {
                let parentId = $(this).val();
                let parentCategorySelect = $('#parent-category');

                // Seçim boşdursa
                if (!parentId) {
                    parentCategorySelect.prop('disabled', true);
                    parentCategorySelect.html('<option value="" data-parentType="">@lang("admin.choose")</option>');
                    return;
                }

                // AJAX ilə sub-kateqoriyaları əldə et
                $.ajax({
                    url: '{{ route('admin.pages-category.getParentCategories') }}',
                    type: 'GET',
                    data: { page_parent_id: parentId },
                    success: function (response) {
                        if (response.success && response.parentCategories.length > 0) {
                            parentCategorySelect.html('<option value="" data-parentType="">@lang("admin.choose")</option>');
                            $.each(response.parentCategories, function (index, category) {
                                parentCategorySelect.append(
                                    `<option value="${category.id}"  data-parentType="${category.page_type}">${category.title}</option>`
                                );
                            });
                            parentCategorySelect.prop('disabled', false);
                        } else {
                            parentCategorySelect.html('<option value="" data-parentType="">@lang("admin.choose")</option>');
                            parentCategorySelect.prop('disabled', true);
                        }
                    },
                    error: function () {
                        alert('@lang("admin.error_loading_categories")');
                    }
                });
            });

            // Sub-category seçildikdə Alt-sub-kateqoriyalar yüklə
            $('#parent-category').on('change', function () {
                let parentCategoryId = $(this).val();
                let subCategorySelect = $('#sub-category');

                // Seçim boşdursa
                if (!parentCategoryId) {
                    subCategorySelect.prop('disabled', true);
                    subCategorySelect.html('<option value="" data-subParentType="">@lang("admin.choose")</option>');
                    return;
                }

                // AJAX ilə sub-sub-kateqoriyaları əldə et
                $.ajax({
                    url: '{{ route('admin.pages-category.getSubParentCategories') }}',
                    type: 'GET',
                    data: { page_sub_parent_id: parentCategoryId },
                    success: function (response) {
                        if (response.success && response.subParentCategories.length > 0) {
                            subCategorySelect.html('<option value="" data-subParentType="">@lang("admin.choose")</option>');
                            $.each(response.subParentCategories, function (index, subCategory) {
                                subCategorySelect.append(
                                    `<option value="${subCategory.id}"  data-subParentType="${subCategory.page_type}">${subCategory.title}</option>`
                                );
                            });
                            subCategorySelect.prop('disabled', false);
                        } else {
                            subCategorySelect.html('<option value="" data-subParentType="">@lang("admin.choose")</option>');
                            subCategorySelect.prop('disabled', true);
                        }
                    },
                    error: function () {
                        alert('@lang("admin.error_loading_sub_categories")');
                    }
                });
            });
        });

    </script>
  {{--  <script>
        document.addEventListener('DOMContentLoaded', function () {
            const pageParentSelect = document.getElementById('parent_page_id');
            const sliderWrapper = document.getElementById('slider-input-wrapper');
            const fileWrapper = document.getElementById('file-input-wrapper');
            const imageWrapper = document.getElementById('image-input-wrapper');

            pageParentSelect.addEventListener('change', function () {
                const selectedOption = pageParentSelect.options[pageParentSelect.selectedIndex];
                const dataType = selectedOption.getAttribute('data-type');

                // Hamısını gizlət
                sliderWrapper.style.display = 'none';
                fileWrapper.style.display = 'none';
                imageWrapper.style.display = 'none';

                // Dəyərlərə görə göstər
                if (dataType === 'slider') {
                    sliderWrapper.style.display = 'block';
                } else if (dataType === 'file_content') {
                    fileWrapper.style.display = 'block';
                } else if (dataType === 'image_content') {
                    imageWrapper.style.display = 'block';
                }
            });
        });

    </script>
    <script>
        $(document).ready(function () {
            // Main Category seçildikdə
            $('#page_id').on('change', function () {
                let pageId = $(this).val();
                let parentWrapper = $('#parent-page-wrapper');
                let parentSelect = $('#parent_page_id');

                // Seçim boşdursa
                if (!pageId) {
                    parentWrapper.hide();
                    parentSelect.html('<option value="">@lang("admin.choose")</option>');
                    return;
                }

                // AJAX ilə parent kateqoriyaları əldə et
                $.ajax({
                    url: '{{ route('admin.pages.getParentPage') }}',
                    type: 'GET',
                    data: { parent_id: pageId },
                    success: function (response) {
                        if (response.success && response.parentPage.length > 0) {
                            parentSelect.html('<option value="" data-type="">@lang("admin.choose")</option>');
                            $.each(response.parentPage, function (index, parent) {
                                parentSelect.append(
                                    `<option value="${parent.id}" data-type="${parent.page_type}">${parent.title}</option>`
                                );
                            });
                            parentWrapper.show();
                        } else {
                            parentWrapper.hide();
                            parentSelect.html('<option value="" data-type="">@lang("admin.choose")</option>');
                        }
                    },
                    error: function () {
                        alert('@lang("admin.error_loading_categories")');
                    }
                });
            });
        });
    </script>--}}
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Tek resim için: Dosya adını göster
            document.getElementById('mainImageUpload').addEventListener('change', function (event) {
                const mainImagePreview = document.getElementById('mainImagePreview');
                mainImagePreview.innerHTML = ''; // Önizleme alanını temizle
                const file = event.target.files[0];
                if (file) {
                    const img = document.createElement('img');
                    img.src = URL.createObjectURL(file); // Resmin src'sini ayarla
                    img.style.width = '150px';
                    img.style.height = 'auto';
                    img.style.border = '1px solid #ccc';
                    img.style.padding = '5px';
                    img.style.marginTop = '5px';

                    // Önizleme alanına resmi ekle
                    mainImagePreview.appendChild(img);
                }
            });

            // Çoklu resim için: Sadece resim önizlemelerini göster ve silme özelliği ekle
            document.getElementById('multipleUpload').addEventListener('change', function (event) {
                const sliderImagePreview = document.getElementById('sliderImagePreview');
                sliderImagePreview.innerHTML = ''; // Önizleme alanını temizle

                Array.from(event.target.files).forEach((file, index) => {
                    const wrapper = document.createElement('div');
                    wrapper.style.display = 'inline-block';
                    wrapper.style.position = 'relative';
                    wrapper.style.marginRight = '5px';

                    const img = document.createElement('img');
                    img.src = URL.createObjectURL(file);
                    img.style.width = '100px';
                    img.style.height = 'auto';
                    img.style.border = '1px solid #ccc';
                    img.style.padding = '5px';

                    // Silme düyməsi əlavə et
                    const removeButton = document.createElement('button');
                    removeButton.textContent = 'X';
                    removeButton.style.position = 'absolute';
                    removeButton.style.top = '5px';
                    removeButton.style.right = '5px';
                    removeButton.style.background = 'red';
                    removeButton.style.color = 'white';
                    removeButton.style.border = 'none';
                    removeButton.style.borderRadius = '50%';
                    removeButton.style.cursor = 'pointer';
                    removeButton.style.width = '20px';
                    removeButton.style.height = '20px';

                    // Silme funksiyası
                    removeButton.addEventListener('click', function () {
                        wrapper.remove(); // Resmi önizlemeden kaldır
                        const fileList = Array.from(event.target.files);
                        fileList.splice(index, 1); // Input'daki dosyayı sil
                        const dataTransfer = new DataTransfer();
                        fileList.forEach(file => dataTransfer.items.add(file)); // Geri kalan dosyaları yeniden ekle
                        event.target.files = dataTransfer.files; // Input'u güncelle
                    });

                    wrapper.appendChild(img);
                    wrapper.appendChild(removeButton);
                    sliderImagePreview.appendChild(wrapper);
                });
            });
        });
    </script>
    <script src="{{ asset('summernote/summernote-bs4.min.js') }}"></script>
    <script src="{{ asset('summernote/editor_summernote.js') }}"></script>
@endsection
