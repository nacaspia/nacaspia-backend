@extends('admin.layouts.app')
@section('admin.title')
    {{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}
@endsection
@section('admin.css')
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.css">
    @if ($instituteCategory['page_type'] == 'slide_content')
        <link rel="stylesheet" href="{{ asset('admin/assets/vendor/css/swiper-bundle.min.css') }}">
    @elseif ($instituteCategory['page_type'] == 'file_content')
    @elseif ($instituteCategory['page_type'] == 'image_content')
        <meta name="_token" content="{{ csrf_token() }}">
        <link rel="stylesheet" href="{{ asset('admin/assets/vendor/css/aos.css') }}">
    @endif
@endsection
@section('admin.content')
    @if ($instituteCategory['page_type'] == 'slide_content')
        <div class="main-content">
            <div class="dashboard-breadcrumb mb-25">
                <h2>{{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}</h2>
            </div>
            @include('components.admin.error')
            <div class="row">
                <div class="col-12">
                    <form action=" @if(!empty($institutePage['id'])) {{ route('admin.institute.update',$institutePage['id']) }} @else{{ route('admin.institute.store') }}@endif" method="POST" enctype="multipart/form-data">
                        @csrf
                        @if(!empty($institutePage['id']))
                            @method('PUT')
                        @endif
                        <input type="hidden" name="category_slug" value="{{ !empty($instituteCategory['slug'][$currentLang]) ? $instituteCategory['slug'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}">
                        <div class="panel">
                            <div class="panel-body">
                                <ul class="nav nav-pills nav-justified" role="tablist">
                                    @if(!empty($locales))
                                        @foreach($locales as $key => $lang)
                                            <li class="nav-item waves-effect waves-light">
                                                <a class="nav-link @if(++$key ==1) active @endif" data-bs-toggle="tab"
                                                   href="#{{$lang->code}}" role="tab">
                                                    <span class="d-none d-sm-block">{{$lang->code}}</span>
                                                </a>
                                            </li>
                                        @endforeach
                                    @endif
                                    <li class="nav-item waves-effect waves-light">
                                        <a class="nav-link" data-bs-toggle="tab"
                                           href="#other" role="tab">
                                            <span class="d-none d-sm-block">@lang('admin.other')</span>
                                        </a>
                                    </li>
                                </ul>
                                <div class="tab-content p-3 text-muted">
                                    @if(!empty($locales))
                                        @foreach($locales as $key => $lang)
                                            <div class="tab-pane @if(++$key ==1) active @endif" id="{{$lang['code']}}"
                                                 role="tabpanel">
                                                <div class="row g-3">
                                                    <div class="col-12">
                                                        <label class="form-label">@lang('admin.title') - {{$lang['code']}}</label>
                                                        <input type="text" class="form-control" name="title[{{$lang['code']}}]" value="{{ !empty($institutePage['title'][$lang['code']])? $institutePage['title'][$lang['code']]: NULL }}">
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="form-label">@lang('admin.text') - {{$lang['code']}}</label>
                                                        <textarea class="form-control" type="text" name="text[{{$lang['code']}}]" >{{ !empty($institutePage['text'][$lang['code']])? $institutePage['text'][$lang['code']]: NULL }}</textarea>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="form-label">@lang('admin.full_text') - {{$lang['code']}}</label>
                                                        <textarea class="editor form-control" data-locale="{{ $lang['code'] }}" data-csrf-token="{{ csrf_token() }}" name="fulltext[{{$lang['code']}}]">{{ !empty($institutePage['fulltext'][$lang['code']])? $institutePage['fulltext'][$lang['code']]: NULL }}</textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif
                                    <div class="tab-pane" id="other" role="tabpanel">
                                        <div class="row g-3">
                                            <div class="col-sm-12">

                                                <div class="col-lg-8 col-md-7">
                                                    <div class="card component-jquery-uploader">
                                                        <div class="card-header">
                                                            @lang('admin.images')
                                                        </div>
                                                        <div class="card-body">
                                                            <div class="row">
                                                                <div class="col-xxl-9 col-sm-8">
                                                                    <label class="form-label">@lang('admin.slider_image')</label>
                                                                    <input type="file" id="multipleUpload" name="slider_image[]" multiple>
                                                                    <p> Şəkilin maksimum ölçüsü 1600x1066 piksel olmalıdır. Şəkil faylının maksimum ölçüsü 237 KB olmalıdır.</p>
                                                                    <div id="sliderImagePreview" style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            @if(!empty($institutePage['slider_image']))
                                                <div class="col-md-5">
                                                    <div class="slider-images" style="display: flex; flex-wrap: wrap; gap: 10px;">
                                                        @foreach($institutePage['slider_image'] as $slider_image)
                                                            <div style="flex: 0 0 30%; position: relative;">
                                                                <img src="{{ asset('uploads/institute/abouts/'.$slider_image) }}" style="width:100%; height: auto; padding: 10px!important;">
                                                                <button type="button" class="btn btn-danger btn-sm delete-image" data-image="{{ $slider_image }}" style="position: absolute; top: 5px; right: 5px;">Sil</button>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>
                                            @endif

                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-sm btn-primary">@lang('admin.save')</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @elseif ($instituteCategory['page_type'] == 'file_content')
        <div class="main-content">
            <div class="dashboard-breadcrumb mb-25">
                <h2>{{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}</h2>
            </div>
            @include('components.admin.error')
            <div class="row">
                <div class="col-12">
                    <form action=" @if(!empty($institutePage['id'])) {{ route('admin.institute.update',$institutePage['id']) }} @else{{ route('admin.institute.store') }}@endif" method="POST" enctype="multipart/form-data">
                        @csrf
                        @if(!empty($institutePage['id']))
                            @method('PUT')
                        @endif
                        <input type="hidden" name="category_slug" value="{{ !empty($instituteCategory['slug'][$currentLang]) ? $instituteCategory['slug'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}">
                        <div class="panel">
                            <div class="panel-body">
                                <ul class="nav nav-pills nav-justified" role="tablist">
                                    @if(!empty($locales))
                                        @foreach($locales as $key => $lang)
                                            <li class="nav-item waves-effect waves-light">
                                                <a class="nav-link @if(++$key ==1) active @endif" data-bs-toggle="tab"
                                                   href="#{{$lang->code}}" role="tab">
                                                    <span class="d-none d-sm-block">{{$lang->code}}</span>
                                                </a>
                                            </li>
                                        @endforeach
                                    @endif
                                    <li class="nav-item waves-effect waves-light">
                                        <a class="nav-link" data-bs-toggle="tab"
                                           href="#other" role="tab">
                                            <span class="d-none d-sm-block">@lang('admin.other')</span>
                                        </a>
                                    </li>
                                </ul>
                                <div class="tab-content p-3 text-muted">
                                    @if(!empty($locales))
                                        @foreach($locales as $key => $lang)
                                            <div class="tab-pane @if(++$key ==1) active @endif" id="{{$lang['code']}}"
                                                 role="tabpanel">
                                                <div class="row g-3">
                                                    <div class="col-12">
                                                        <label class="form-label">@lang('admin.title') - {{$lang['code']}}</label>
                                                        <input type="text" class="form-control" name="title[{{$lang['code']}}]" value="{{ !empty($institutePage['title'][$lang['code']])? $institutePage['title'][$lang['code']]: NULL }}">
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="form-label">@lang('admin.text') - {{$lang['code']}}</label>
                                                        <textarea class="form-control" type="text" name="text[{{$lang['code']}}]" >{{ !empty($institutePage['text'][$lang['code']])? $institutePage['text'][$lang['code']]: NULL }}</textarea>
                                                    </div>
                                                    <div class="col-12">
                                                        <label class="form-label">@lang('admin.full_text') - {{$lang['code']}}</label>
                                                        <textarea class="editor form-control" data-locale="{{ $lang['code'] }}" data-csrf-token="{{ csrf_token() }}" name="fulltext[{{$lang['code']}}]">{{ !empty($institutePage['fulltext'][$lang['code']])? $institutePage['fulltext'][$lang['code']]: NULL }}</textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif
                                    <div class="tab-pane" id="other" role="tabpanel">
                                        <div class="row g-3">
                                            <div class="col-sm-12">
                                                <div class="col-lg-8 col-md-7">
                                                    <label class="form-label">@lang('admin.file')</label>
                                                    <input type="file" name="file" multiple>
                                                    <div id="sliderImagePreview" style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px;"></div>
                                                </div>
                                            </div>
                                            @if(!empty($institutePage['file']))
                                                <div class="col-md-5">
                                                   <a href="{{ asset('uploads/institute/charter/'.$institutePage['file'] ) }}" target="_blank">Fayl aç</a>
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-sm btn-primary">@lang('admin.save')</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    @elseif ($instituteCategory['page_type'] == 'image_content')
        <?php $instituteCategorySlug = !empty($instituteCategory['slug'][$currentLang]) ? $instituteCategory['slug'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') ?>
        <div class="main-content">
            <div class="dashboard-breadcrumb mb-25">
                <h2>{{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}</h2>
                <a class="btn btn-sm btn-primary" href="{{ route('admin.institute.create',$instituteCategorySlug) }}">
                    <i class="fa-light fa-plus"></i> @lang('admin.add')
                </a>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="panel">
                        <div class="panel-body">
                            @if(!empty($institutePage[0]) && isset($institutePage[0]))
                                @foreach($institutePage as $institute)
                                    <h3>{{ $institute['title'][$currentLang] }}</h3>
                                    <div class="row" id="sortable{{ $institute['id'] }}">
                                        @foreach($institute['leadership'] as $data)
                                            @if($data['category_id'] == $instituteCategory['id'])
                                        <div class="col-sm-6"  data-id="{{ $data['id'] }}">
                                            <div class="card">
                                                <div class="card-header">
                                                    {{ !empty($data['full_name'][$currentLang])? $data['full_name'][$currentLang]: null }}
                                                    <a href="{{ route('admin.institute.edit',['id'=>$data['id'],'slug'=>$instituteCategorySlug]) }}" class="btn btn-sm btn-icon btn-primary" title="@lang('admin.edit')">
                                                        <i class="fa-light fa-edit"></i>
                                                    </a>
                                                    <button class="btn btn-sm btn-icon btn-danger" data-bs-toggle="modal" data-bs-target="#delete{{$data['id']}}">
                                                        <i class="fa-light fa-trash-can"></i>
                                                    </button>
                                                </div>
                                                <div class="card-body animation-card">
                                                    <div class="text-center" data-aos="flip-left">
                                                        <img src="{{ asset('uploads/institute/leadership/'.$data->image) }}" alt="{{ !empty($data['full_name'][$currentLang])? $data['full_name'][$currentLang]: null }}">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                            @endif
                                        @endforeach
                                    </div>
                                @endforeach
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- main content end -->
        @if(!empty($institutePage[0]) && isset($institutePage[0]))
            @foreach($institutePage as $value)
                @foreach($value['leadership'] as $delData)
                <div class="modal fade" id="delete{{$delData['id']}}" tabindex="-1" aria-labelledby="deletecategory{{$delData['id']}}Label" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h2 class="modal-title" id="deletecategory{{$delData['id']}}Label">@lang('admin.delete')</h2>
                                <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                                    <i class="fa-light fa-times"></i>
                                </button>
                            </div>
                            <form action="{{ route('admin.institute.destroy',$delData['id']) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <input type="hidden" name="category_slug" value="{{ !empty($instituteCategory['slug'][$currentLang]) ? $instituteCategory['slug'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}">
                                <div class="modal-body">
                                    <h2>@lang('admin.delete_about') </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.not')</button>
                                    <button type="submit" class="btn btn-sm btn-primary">@lang('admin.yes')</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @endforeach
            @endforeach
        @endif
    @elseif ($instituteCategory['page_type'] == 'content')
        <?php $instituteCategorySlug = !empty($instituteCategory['slug'][$currentLang]) ? $instituteCategory['slug'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') ?>
        <div class="main-content">
            <div class="dashboard-breadcrumb mb-25">
                <h2>{{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}</h2>
                <a class="btn btn-sm btn-primary" href="{{ route('admin.institute.create',$instituteCategorySlug) }}">
                    <i class="fa-light fa-plus"></i> @lang('admin.add')
                </a>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="panel">
                        <div class="panel-body">
                            @if(!empty($institutePage[0]) && isset($institutePage[0]))
                                <div class="row"  id="sortable">
                                    @foreach($institutePage as $institute)
                                    <div class="col-sm-6" data-id="{{ $institute['id'] }}">
                                        <div class="card">
                                            <div class="card-header">
                                                {{ !empty($institute['full_name'][$currentLang])? $institute['full_name'][$currentLang]: null }}
                                                <a href="{{ route('admin.institute.edit',['id'=>$institute['id'],'slug'=>$instituteCategorySlug]) }}" class="btn btn-sm btn-icon btn-primary" title="@lang('admin.edit')">
                                                    <i class="fa-light fa-edit"></i>
                                                </a>
                                                <button class="btn btn-sm btn-icon btn-danger" data-bs-toggle="modal" data-bs-target="#delete{{$institute['id']}}">
                                                    <i class="fa-light fa-trash-can"></i>
                                                </button>
                                            </div>
                                            <div class="card-body animation-card">
                                                <div class="text-center" data-aos="flip-left">
                                                    <img src="{{ asset('uploads/institute/structureImage/'.$institute->image) }}" alt="">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- main content end -->
        @if(!empty($institutePage[0]) && isset($institutePage[0]))
            @foreach($institutePage as $delData)
                <div class="modal fade" id="delete{{$delData['id']}}" tabindex="-1" aria-labelledby="deletecategory{{$delData['id']}}Label" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h2 class="modal-title" id="deletecategory{{$delData['id']}}Label">@lang('admin.delete')</h2>
                                <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                                    <i class="fa-light fa-times"></i>
                                </button>
                            </div>
                            <form action="{{ route('admin.institute.destroy',$delData['id']) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <input type="hidden" name="category_slug" value="{{ !empty($instituteCategory['slug'][$currentLang]) ? $instituteCategory['slug'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}">
                                <div class="modal-body">
                                    <h2>@lang('admin.delete_about') </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.not')</button>
                                    <button type="submit" class="btn btn-sm btn-primary">@lang('admin.yes')</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            @endforeach
        @endif
    @elseif ($instituteCategory['page_type'] == 'photo')
        <?php $instituteCategorySlug = !empty($instituteCategory['slug'][$currentLang]) ? $instituteCategory['slug'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') ?>
        <div class="main-content">
            <div class="dashboard-breadcrumb mb-25">
                <h2>{{ !empty($instituteCategory['title'][$currentLang]) ? $instituteCategory['title'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}</h2>
                <a class="btn btn-sm btn-primary" href="{{ route('admin.institute.create',$instituteCategorySlug) }}">
                    <i class="fa-light fa-plus"></i> @lang('admin.add')
                </a>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="panel">
                        <div class="panel-body">
                            @if(!empty($institutePage[0]) && isset($institutePage[0]))
                                <div class="row">
                                    @foreach($institutePage as $data)
                                        <div class="col-sm-6">
                                            <div class="card">
                                                <div class="card-header">
                                                    {{ !empty($data['title'][$currentLang])? $data['title'][$currentLang]: null }}
                                                    <a href="{{ route('admin.institute.edit',['id'=>$data['id'],'slug'=>$instituteCategorySlug]) }}" class="btn btn-sm btn-icon btn-primary" title="@lang('admin.edit')">
                                                        <i class="fa-light fa-edit"></i>
                                                    </a>
                                                    <button class="btn btn-sm btn-icon btn-danger" data-bs-toggle="modal" data-bs-target="#delete{{$data['id']}}">
                                                        <i class="fa-light fa-trash-can"></i>
                                                    </button>
                                                </div>
                                                <div class="card-body animation-card">
                                                    <div class="text-center" data-aos="flip-left">
                                                        <img src="{{ asset('uploads/institute/accreditation/'.$data->image) }}" alt="{{ !empty($data['full_name'][$currentLang])? $data['full_name'][$currentLang]: null }}">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endforeach
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- main content end -->
        @if(!empty($institutePage[0]) && isset($institutePage[0]))
            @foreach($institutePage as $delData)
                <div class="modal fade" id="delete{{$delData['id']}}" tabindex="-1" aria-labelledby="deletecategory{{$delData['id']}}Label" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h2 class="modal-title" id="deletecategory{{$delData['id']}}Label">@lang('admin.delete')</h2>
                                <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                                    <i class="fa-light fa-times"></i>
                                </button>
                            </div>
                            <form action="{{ route('admin.institute.destroy',$delData['id']) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <input type="hidden" name="category_slug" value="{{ !empty($instituteCategory['slug'][$currentLang]) ? $instituteCategory['slug'][$currentLang]: \Illuminate\Support\Facades\Lang::get('admin.institute') }}">
                                <div class="modal-body">
                                    <h2>@lang('admin.delete_about') </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.not')</button>
                                    <button type="submit" class="btn btn-sm btn-primary">@lang('admin.yes')</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            @endforeach
        @endif
    @endif
@endsection
@section('admin.js')

    <!-- jQuery əsas kitabxanası -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- jQuery UI kitabxanası -->
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    @if ($instituteCategory['page_type'] == 'slide_content')
        <script>
            document.addEventListener("DOMContentLoaded", function () {
                document.querySelectorAll(".delete-image").forEach(function (button) {
                    button.addEventListener("click", function () {
                        const imageName = this.getAttribute("data-image");
                        const container = this.parentElement;

                        if (confirm("Bu şəkili silmək istədiyinizə əminsiniz?")) {
                            fetch("{{ route('admin.slider_image.delete') }}", {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json",
                                    "X-CSRF-TOKEN": "{{ csrf_token() }}",
                                },
                                body: JSON.stringify({ image: imageName }),
                            })
                                .then((response) => response.json())
                                .then((data) => {
                                    if (data.success) {
                                        container.remove();
                                        alert("Şəkil uğurla silindi.");
                                    } else {
                                        alert("Şəkili silmək mümkün olmadı.");
                                    }
                                })
                                .catch((error) => {
                                    console.error("Xəta:", error);
                                    alert("Xəta baş verdi.");
                                });
                        }
                    });
                });
            });

        </script>
        <script>
            let currentSlide = 0;

            function showSlide(slideIndex) {
                const slides = document.getElementById('slides');
                const totalSlides = slides.children.length;

                // Slide dizilimini değiştir
                if (slideIndex >= totalSlides) {
                    currentSlide = 0; // İlk slide'a döner
                } else if (slideIndex < 0) {
                    currentSlide = totalSlides - 1; // Son slide'a döner
                } else {
                    currentSlide = slideIndex;
                }

                // Slide'ları kaydır
                const offset = -currentSlide * 100; // Offset hesapla
                slides.style.transform = `translateX(${offset}%)`;
            }

            // Slide'ları değiştir
            function changeSlide(n) {
                showSlide(currentSlide + n);
            }

            // İlk slide'ı göster
            showSlide(currentSlide);
        </script>
        <script src="{{ asset('admin/assets/vendor/js/swiper-bundle.min.js') }}"></script>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                const sliderImagePreview = document.getElementById('sliderImagePreview');
                const multipleUploadInput = document.getElementById('multipleUpload');

                // Yüklənmiş faylları izləmək üçün boş bir array yaradılır
                let filesArray = [];

                multipleUploadInput.addEventListener('change', function(event) {
                    sliderImagePreview.innerHTML = ''; // Önizləmə sahəsini sıfırla
                    filesArray = Array.from(event.target.files); // Faylları array olaraq saxla

                    filesArray.forEach((file, index) => {
                        const container = document.createElement('div'); // Şəkil və sil düyməsi üçün konteyner
                        container.style.display = 'inline-block';
                        container.style.position = 'relative';
                        container.style.marginRight = '10px';

                        const img = document.createElement('img');
                        img.src = URL.createObjectURL(file);
                        img.style.width = '100px';
                        img.style.height = 'auto';
                        img.style.border = '1px solid #ccc';
                        img.style.padding = '5px';

                        // Sil düyməsi
                        const deleteButton = document.createElement('button');
                        deleteButton.innerHTML = 'Sil';
                        deleteButton.style.position = 'absolute';
                        deleteButton.style.top = '5px';
                        deleteButton.style.right = '5px';
                        deleteButton.style.backgroundColor = 'red';
                        deleteButton.style.color = 'white';
                        deleteButton.style.border = 'none';
                        deleteButton.style.cursor = 'pointer';
                        deleteButton.style.padding = '2px 5px';

                        // Sil düyməsinə klik edildikdə
                        deleteButton.addEventListener('click', function() {
                            filesArray.splice(index, 1); // Faylı array-dən sil
                            container.remove(); // Önizləmədən çıxar

                            // Faylları yenidən input-a təyin et
                            const dataTransfer = new DataTransfer();
                            filesArray.forEach(file => dataTransfer.items.add(file));
                            multipleUploadInput.files = dataTransfer.files;
                        });

                        // Konteynerə şəkil və düyməni əlavə et
                        container.appendChild(img);
                        container.appendChild(deleteButton);

                        // Önizləmə sahəsinə konteyneri əlavə et
                        sliderImagePreview.appendChild(container);
                    });
                });
            });
        </script>


    @elseif ($instituteCategory['page_type'] == 'file_content')

    @elseif ($instituteCategory['page_type'] == 'content')
        <script>
            $(function () {
                $('#sortable').sortable({
                    update: function (event, ui) {
                        let sortedIDs = $(this).sortable('toArray', { attribute: 'data-id' });
                        let leadId = $('div[data-id]').data('id');
                        console.log(leadId);

                        // İstifadəçini bloklamaq üçün overlay əlavə et
                        $('body').append('<div id="loading-overlay">Zəhmət olmasa gözləyin...</div>');

                        // AJAX vasitəsilə məlumat göndər
                        $.ajax({
                            url: "{{ route('admin.institute.orderBy') }}",
                            method: 'POST',
                            data: {
                                _token: '{{ csrf_token() }}',
                                sortedIDs: sortedIDs,
                                leadId: leadId,
                                type:'structure'
                            },
                            beforeSend: function () {
                                // Bütün düymələri deaktiv et
                                $('button, input, a').prop('disabled', true);
                            },
                            success: function (response) {
                                if (response.status === 'success') {
                                    alert(response.message);
                                } else {
                                    alert('Xəta baş verdi, yenidən cəhd edin.');
                                }
                            },
                            complete: function () {
                                // Overlay-i sil və düymələri yenidən aktiv et
                                $('#loading-overlay').remove();
                                $('button, input, a').prop('disabled', false);
                            }
                        });
                    }
                });
            });
        </script>
    @elseif ($instituteCategory['page_type'] == 'image_content')

        <script>
            $(function () {
                $('.row[id^="sortable"]').sortable({
                    update: function (event, ui) {
                        let sortedIDs = $(this).sortable('toArray', { attribute: 'data-id' });
                        let leadId = $('div[data-id]').data('id');
                        console.log(leadId);

                        // AJAX vasitəsilə məlumat göndər
                        $.ajax({
                            url: "{{ route('admin.institute.orderBy') }}",
                            method: 'POST',
                            data: {
                                _token: '{{ csrf_token() }}',
                                sortedIDs: sortedIDs,
                                leadId: leadId,
                                type:'leadership'
                            },
                            success: function (response) {
                                if (response.status === 'success') {
                                    alert(response.message);
                                } else {
                                    alert('Xəta baş verdi, yenidən cəhd edin.');
                                }
                            }
                        });
                    }
                });
            });
        </script>

        <script src="{{ asset('admin/assets/vendor/js/aos.js') }}"></script>
    @endif
    <script src="{{ asset('summernote/summernote-bs4.min.js') }}"></script>
    <script src="{{ asset('summernote/editor_summernote.js') }}"></script>
    <script>
        $(document).ready(function() {
            $('.summernote-height').summernote({
                airMode: true, // Eğer airMode kullanılıyorsa
                disableResizeEditor: true,
                toolbar: false, // Eğer toolbar varsa, kapat
                disableDragAndDrop: true,
                callbacks: {
                    onInit: function() {
                        // Editoru deaktiv et
                        $(this).summernote('disable');
                    }
                }
            });
        });

    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                var errorDiv = document.getElementById('error-message');
                if (errorDiv) {
                    errorDiv.style.display = 'none';
                }
            }, 2000);
        });
    </script>
@endsection

