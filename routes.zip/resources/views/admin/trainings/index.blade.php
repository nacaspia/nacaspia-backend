@extends('admin.layouts.app')
@section('admin.title')
    @lang('admin.trainings')
@endsection
@section('admin.css')
    <meta name="_token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{ asset('admin/assets/vendor/css/jquery.uploader.css') }}">
@endsection
@section('admin.content')
    <!-- main content start -->
    <div class="main-content">
        @include('components.admin.error')
        <div class="row">
            <div class="col-12">
                <div class="panel">

                    <div class="panel-header">
                        <h5>@lang('admin.trainings')</h5>
                        <div class="btn-box d-flex flex-wrap gap-2">
                            <div id="tableSearch"></div>
                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#addTaskModal"><i class="fa-light fa-plus"></i> @lang('admin.add')
                            </button>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table class="table table-dashed table-hover digi-dataTable task-table table-striped"
                               id="taskTable">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>@lang('admin.title')</th>
                                <th>Seçim tipi</th>
                                <th>@lang('admin.settings')</th>
                            </tr>
                            </thead>
                            <tbody>
                            @if(!empty($trainings[0]) && isset($trainings[0]))
                                @foreach($trainings as $data)
                                    @if(empty($data['parent_id']))
                                        <tr>
                                            <td>{{ $data['id'] }}</td>
                                            <td>
                                                <div class="table-category-card">
                                                    <div class="part-txt">
                                                        <span class="category-name">{!! !empty($data['title'][$currentLang])? $data['title'][$currentLang]: null !!}</span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                @if($data['type'] =='advisory-consulting')
                                                    Məsləhət/konsaltinq xidmətləri -Form
                                                @elseif($data['type'] =='evaluation')
                                                    Qiymətləndirmə xidməti -Form
                                                @elseif($data['type'] =='activity-category')
                                                    Müəssisənin fəaliyyət kateqoriyası -Kalkulator
                                                @elseif($data['type'] =='complexity-group')
                                                    Mürəkkəblik qrupu -Kalkulator
                                                @elseif($data['type'] =='certification-type')
                                                    Sertifikatlaşma növü -Kalkulator
                                                @endif

                                            </td>
                                            <td>
                                                <div class="btn-box">
                                                    <button class="btn btn-sm btn-icon btn-primary" data-bs-toggle="modal"
                                                            data-bs-target="#editMain{{$data['id']}}"><i
                                                            class="fa-light fa-edit"></i>
                                                    </button>

                                                    <button class="btn btn-sm btn-icon btn-danger" data-bs-toggle="modal"
                                                            data-bs-target="#deleteMain{{$data['id']}}"><i
                                                            class="fa-light fa-trash-can"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    @endif
                                @endforeach
                            @endif
                            </tbody>
                        </table>
                        <div class="table-bottom-control"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- main content end -->

    <!-- add new task modal -->
    <div class="modal fade" id="addTaskModal" tabindex="-1" aria-labelledby="addTaskModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title" id="addTaskModalLabel">@lang('admin.add')</h2>
                    <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                        <i class="fa-light fa-times"></i>
                    </button>
                </div>
                <form action="{{ route('admin.trainings.store') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <ul class="nav nav-pills nav-justified" role="tablist">
                            @if(!empty($locales))
                                @foreach($locales as $key => $lang)
                                    <li class="nav-item waves-effect waves-light">
                                        <a class="nav-link @if(++$key ==1) active @endif" data-bs-toggle="tab"
                                           href="#{{$lang->code}}" role="tab">
                                            <span class="d-none d-sm-block">{{$lang->code}}</span>
                                        </a>
                                    </li>
                                @endforeach
                            @endif
                            <li class="nav-item waves-effect waves-light">
                                <a class="nav-link" data-bs-toggle="tab"
                                   href="#other" role="tab">
                                    <span class="d-none d-sm-block">@lang('admin.other')</span>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content p-3 text-muted">
                            @if(!empty($locales))
                                @foreach($locales as $key => $lang)
                                    <div class="tab-pane @if(++$key ==1) active @endif" id="{{$lang['code']}}"
                                         role="tabpanel">
                                        <div class="row g-3">
                                            <div class="col-12">
                                                <label class="form-label">@lang('admin.title')
                                                    - {{$lang['code']}}</label>
                                                <input type="text" class="form-control" name="title[{{$lang['code']}}]">
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            @endif
                            <div class="tab-pane" id="other" role="tabpanel">
                                <div class="row g-3">
                                    <div class="col-sm-12">
                                        <label class="form-label">@lang('admin.status')</label>
                                        <select class="form-control" name="status">
                                            <option value="1" >Aktiv</option>
                                            <option value="0" >Deactiv</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-12">
                                        <label class="form-label">@lang('admin.type')</label>
                                        <select class="form-control" name="type">
                                            <option value="advisory-consulting" >Məsləhət/konsaltinq xidmətləri -Form</option>
                                            <option value="evaluation" >Qiymətləndirmə xidməti -Form</option>
                                            <option value="activity-category" >Müəssisənin fəaliyyət kateqoriyası -Kalkulator</option>
                                            <option value="complexity-group" >Mürəkkəblik qrupu -Kalkulator</option>
                                            <option value="certification-type" >Sertifikatlaşma növü -Kalkulator</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-12">
                                        <label class="form-label">Dəyər</label>
                                        <input type="text" class="form-control" name="weight">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.close')</button>
                        <button type="submit" class="btn btn-sm btn-primary">@lang('admin.save')</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- add new task modal -->

    @if(!empty($trainings[0]) && isset($trainings[0]))
        @foreach($trainings as $value)
            <!-- edit task modal -->
            <div class="modal fade" id="editMain{{$value['id']}}" tabindex="-1" aria-labelledby="editMain{{$value['id']}}Label" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content">
                        <form action="{{ route('admin.trainings.update',$value['id']) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <div class="modal-body">
                                <ul class="nav nav-pills nav-justified" role="tablist">
                                    @if(!empty($locales))
                                        @foreach($locales as $key => $lang)
                                            <li class="nav-item waves-effect waves-light">
                                                <a class="nav-link @if(++$key ==1) active @endif" data-bs-toggle="tab" href="#edit-main{{$value['id']}}{{$lang->code}}" role="tab">
                                                    <span class="d-none d-sm-block">{{$lang->code}}</span>
                                                </a>
                                            </li>
                                        @endforeach
                                    @endif
                                    <li class="nav-item waves-effect waves-light">
                                        <a class="nav-link" data-bs-toggle="tab"
                                           href="#editother-main{{$value['id']}}" role="tab">
                                            <span class="d-none d-sm-block">@lang('admin.other')</span>
                                        </a>
                                    </li>
                                </ul>
                                <div class="tab-content p-3 text-muted">
                                    @if(!empty($locales))
                                        @foreach($locales as $key => $lang)
                                            <div class="tab-pane @if(++$key ==1) active @endif"
                                                 id="edit-main{{$value['id']}}{{$lang['code']}}" role="tabpanel">
                                                <div class="row g-3">
                                                    <div class="col-12">
                                                        <label class="form-label">@lang('admin.title')
                                                            - {{$lang['code']}}</label>
                                                        <input type="text" class="form-control"
                                                               name="title[{{$lang['code']}}]"
                                                               value="{{ !empty($value['title'][$lang['code']])? $value['title'][$lang['code']]: NULL }}">
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    @endif
                                    <div class="tab-pane" id="editother-main{{$value['id']}}" role="tabpanel">
                                        <div class="row g-3">
                                            <div class="col-sm-12">
                                                <label class="form-label">@lang('admin.status')</label>
                                                <select class="form-control" name="status">
                                                    <option value="1" @if($value['status'] ==1) selected @endif>Aktiv</option>
                                                    <option value="0" @if($value['status'] ==0) selected @endif>Deactiv</option>
                                                </select>
                                            </div>

                                            <div class="col-sm-12">
                                                <label class="form-label">@lang('admin.type')</label>
                                                <select class="form-control" name="type">
                                                    <option value="advisory-consulting" @if($value['type'] =='advisory-consulting') selected @endif>Məsləhət/konsaltinq xidmətləri -Form</option>
                                                    <option value="evaluation" @if($value['type'] =='evaluation') selected @endif>Qiymətləndirmə xidməti -Form</option>
                                                    <option value="activity-category"  @if($value['type'] =='activity-category') selected @endif>Müəssisənin fəaliyyət kateqoriyası -Kalkulator</option>
                                                    <option value="complexity-group"  @if($value['type'] =='complexity-group') selected @endif>Mürəkkəblik qrupu -Kalkulator</option>
                                                    <option value="certification-type"  @if($value['type'] =='certification-type') selected @endif>Sertifikatlaşma növü -Kalkulator</option>
                                                </select>
                                            </div>
                                            @if(!empty($value['weight']))
                                                <div class="col-sm-12">
                                                    <label class="form-label">Dəyər</label>
                                                    <input type="text" class="form-control" name="weight" value="{{$value['weight']}}">
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.close')</button>
                                <button type="submit" class="btn btn-sm btn-primary">@lang('admin.save')</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- edit task modal -->
            <div class="modal fade" id="deleteMain{{$value['id']}}" tabindex="-1" aria-labelledby="deleteMain{{$value['id']}}Label" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h2 class="modal-title" id="deleteMain{{$value['id']}}Label">@lang('admin.delete')</h2>
                            <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                                <i class="fa-light fa-times"></i>
                            </button>
                        </div>
                        <form action="{{ route('admin.trainings.destroy',$value['id']) }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <div class="modal-body">
                                <h2>@lang('admin.delete_about')</h2>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.not')</button>
                                <button type="submit" class="btn btn-sm btn-primary">@lang('admin.yes')</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        @endforeach
    @endif
@endsection
@section('admin.js')
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            let typeSelect = document.querySelector("select[name='type']");
            let weightInput = document.querySelector("input[name='weight']");

            function toggleWeightInput() {
                let allowedValues = ["activity-category", "complexity-group", "certification-type"];
                if (allowedValues.includes(typeSelect.value)) {
                    weightInput.closest(".col-sm-12").style.display = "block";
                } else {
                    weightInput.closest(".col-sm-12").style.display = "none";
                }
            }

            // İlk dəfə səhifə yüklənəndə yoxlayırıq
            toggleWeightInput();

            // Seçim dəyişdikdə yeniləyirik
            typeSelect.addEventListener("change", toggleWeightInput);
        });
    </script>

    <script src="{{ asset('admin/assets/vendor/js/jquery.uploader.min.js') }}"></script>
    <script src="{{ asset('admin/assets/js/category.js') }}"></script>
@endsection
