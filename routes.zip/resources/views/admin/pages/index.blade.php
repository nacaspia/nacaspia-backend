@extends('admin.layouts.app')
@section('admin.title')
    @lang('admin.categories')
@endsection
@section('admin.css')
    <meta name="_token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="{{ asset('admin/assets/vendor/css/jquery.uploader.css') }}">
@endsection
@section('admin.content')
    <!-- main content start -->
    <div class="main-content">
        @include('components.admin.error')
        <div class="row">
            <div class="col-12">
                <div class="panel">

                    <div class="panel-header">
                        <h5>@lang('admin.pages')</h5>
                        <div class="btn-box d-flex flex-wrap gap-2">
                            <div id="tableSearch"></div>
                            <button class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#addTaskModal"><i class="fa-light fa-plus"></i> @lang('admin.add')
                            </button>
                        </div>
                    </div>
                    <div class="panel-body">
                        <table class="table table-dashed table-hover digi-dataTable task-table table-striped"
                               id="taskTable">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>@lang('admin.title')</th>
                                <th>@lang('admin.settings')</th>
                            </tr>
                            </thead>
                            <tbody>
                            @if(!empty($pages[0]) && isset($pages[0]))
                                @foreach($pages as $data)
                                    @if(empty($data['parent_id']))
                                    <tr>
                                        <td>{{ $data['id'] }}</td>
                                        <td>
                                            <div class="table-category-card">
                                                <div class="part-txt">
                                                    <span class="category-name">{!! !empty($data['title'][$currentLang])? $data['title'][$currentLang]: null !!}</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="btn-box">
                                                @if(!empty($data['parentPage'][0]) && isset($data['parentPage'][0]))
                                                    <button class="btn btn-sm btn-icon btn-primary" data-bs-toggle="modal"
                                                            data-bs-target="#eyeMain{{$data['id']}}"><i
                                                            class="fa-light fa-eye"></i>
                                                    </button>
                                                @endif
                                                <button class="btn btn-sm btn-icon btn-primary" data-bs-toggle="modal"
                                                        data-bs-target="#editMain{{$data['id']}}"><i
                                                        class="fa-light fa-edit"></i>
                                                </button>

                                                <button class="btn btn-sm btn-icon btn-danger" data-bs-toggle="modal"
                                                        data-bs-target="#deleteMain{{$data['id']}}"><i
                                                        class="fa-light fa-trash-can"></i></button>
                                            </div>
                                        </td>
                                    </tr>
                                    @endif
                                @endforeach
                            @endif
                            </tbody>
                        </table>
                        <div class="table-bottom-control"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- main content end -->

    <!-- add new task modal -->
    <div class="modal fade" id="addTaskModal" tabindex="-1" aria-labelledby="addTaskModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title" id="addTaskModalLabel">@lang('admin.add')</h2>
                    <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                        <i class="fa-light fa-times"></i>
                    </button>
                </div>
                <form action="{{ route('admin.pages.store') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <ul class="nav nav-pills nav-justified" role="tablist">
                            @if(!empty($locales))
                                @foreach($locales as $key => $lang)
                                    <li class="nav-item waves-effect waves-light">
                                        <a class="nav-link @if(++$key ==1) active @endif" data-bs-toggle="tab"
                                           href="#{{$lang->code}}" role="tab">
                                            <span class="d-none d-sm-block">{{$lang->code}}</span>
                                        </a>
                                    </li>
                                @endforeach
                            @endif
                            <li class="nav-item waves-effect waves-light">
                                <a class="nav-link" data-bs-toggle="tab"
                                   href="#other" role="tab">
                                    <span class="d-none d-sm-block">@lang('admin.other')</span>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content p-3 text-muted">
                            @if(!empty($locales))
                                @foreach($locales as $key => $lang)
                                    <div class="tab-pane @if(++$key ==1) active @endif" id="{{$lang['code']}}"
                                         role="tabpanel">
                                        <div class="row g-3">
                                            <div class="col-12">
                                                <label class="form-label">@lang('admin.title')
                                                    - {{$lang['code']}}</label>
                                                <input type="text" class="form-control" name="title[{{$lang['code']}}]">
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            @endif
                            <div class="tab-pane" id="other" role="tabpanel">
                                <div class="row g-3">
                                   {{-- <div class="col-md-12">
                                        <label for="input-category" class="form-label">@lang('admin.main_category')</label>
                                        <select class="form-control" name="parent_id" id="input-category">
                                            <option value="">@lang('admin.choose')</option>
                                            @foreach($mainPage as $main)
                                                <option value="{{$main->id}}">{{ !empty(json_decode($main, true)['title'][$currentLang])? json_decode($main, true)['title'][$currentLang]: null }}</option>
                                            @endforeach
                                        </select>
                                    </div>--}}
                                    <div class="col-md-12">
                                        <label for="input-category" class="form-label">@lang('admin.main_category')</label>
                                        <select class="form-control" name="parent_id" id="input-category">
                                            <option value="">@lang('admin.choose')</option>
                                            @foreach($mainPage as $main)
                                                <option value="{{$main->id}}">
                                                    {{ json_decode($main, true)['title'][$currentLang] ?? null }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="col-md-12 mt-3">
                                        <label for="parent-category" class="form-label">@lang('admin.parent_category')</label>
                                        <select class="form-control" name="page_parent_id" id="parent-category" disabled>
                                            <option value="">@lang('admin.choose')</option>
                                        </select>
                                    </div>

                                    <div class="col-md-12 mt-3">
                                        <label for="sub-category" class="form-label">@lang('admin.sub_category')</label>
                                        <select class="form-control" name="page_sub_parent_id" id="sub-category" disabled>
                                            <option value="">@lang('admin.choose')</option>
                                        </select>
                                    </div>

                                    <div class="col-sm-12">
                                        <label class="form-label">@lang('admin.page_type')</label>
                                        <select class="form-control" name="page_type">
                                            <option value="">@lang('admin.choose')</option>
                                            <option value="slider">@lang('admin.slider')</option>
                                            <option value="file_content">@lang('admin.file_content')</option>
                                            <option value="image_content">@lang('admin.image_content')</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-12">
                                        <label class="form-label">@lang('admin.status')</label>
                                        <select class="form-control" name="status">
                                            <option value="1" >Aktiv</option>
                                            <option value="0" >Deactiv</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.close')</button>
                        <button type="submit" class="btn btn-sm btn-primary">@lang('admin.save')</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- add new task modal -->

    @if(!empty($pages[0]) && isset($pages[0]))
        @foreach($pages as $value)
                <!-- edit task modal -->
                <div class="modal fade" id="editMain{{$value['id']}}" tabindex="-1" aria-labelledby="editMain{{$value['id']}}Label" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <form action="{{ route('admin.pages.update',$value['id']) }}" method="POST">
                                @csrf
                                @method('PUT')
                                <div class="modal-body">
                                    <ul class="nav nav-pills nav-justified" role="tablist">
                                        @if(!empty($locales))
                                            @foreach($locales as $key => $lang)
                                                <li class="nav-item waves-effect waves-light">
                                                    <a class="nav-link @if(++$key ==1) active @endif" data-bs-toggle="tab" href="#edit-main{{$value['id']}}{{$lang->code}}" role="tab">
                                                        <span class="d-none d-sm-block">{{$lang->code}}</span>
                                                    </a>
                                                </li>
                                            @endforeach
                                        @endif
                                        <li class="nav-item waves-effect waves-light">
                                            <a class="nav-link" data-bs-toggle="tab"
                                               href="#editother-main{{$value['id']}}" role="tab">
                                                <span class="d-none d-sm-block">@lang('admin.other')</span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tab-content p-3 text-muted">
                                        @if(!empty($locales))
                                            @foreach($locales as $key => $lang)
                                                <div class="tab-pane @if(++$key ==1) active @endif"
                                                     id="edit-main{{$value['id']}}{{$lang['code']}}" role="tabpanel">
                                                    <div class="row g-3">
                                                        <div class="col-12">
                                                            <label class="form-label">@lang('admin.title')
                                                                - {{$lang['code']}}</label>
                                                            <input type="text" class="form-control"
                                                                   name="title[{{$lang['code']}}]"
                                                                   value="{{ !empty($value['title'][$lang['code']])? $value['title'][$lang['code']]: NULL }}">
                                                        </div>
                                                    </div>
                                                </div>
                                            @endforeach
                                        @endif
                                        <div class="tab-pane" id="editother-main{{$value['id']}}" role="tabpanel">
                                            <div class="row g-3">
                                                @if(!empty($value['parent_id']))
                                                    <div class="col-md-12">
                                                        <label for="input-category" class="form-label">@lang('admin.main_category')</label>
                                                        <select class="form-control" name="parent_id" id="input-category">
                                                            <option value="">@lang('admin.choose')</option>
                                                            @foreach($mainPage as $main)
                                                                <option value="{{$main->id}}" @if(!empty($value['parent_id']) && $value['parent_id'] == $main['id']) selected @endif>{{ !empty(json_decode($main, true)['title'][$currentLang])? json_decode($main, true)['title'][$currentLang]: null }}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                @endif
                                                <div class="col-sm-12">
                                                    <label class="form-label">@lang('admin.page_type')</label>
                                                    <select class="form-control" name="page_type" disabled>
                                                        <option value="" @if($value['page_type'] == '') selected @endif>@lang('admin.choose')</option>
                                                        <option value="slider" @if($value['page_type'] == 'slider') selected @endif>@lang('admin.slider')</option>
                                                        <option value="file_content" @if($value['page_type'] == 'file_content') selected @endif>@lang('admin.file_content')</option>
                                                        <option value="image_content" @if($value['page_type'] == 'image_content') selected @endif>@lang('admin.image_content')</option>
                                                    </select>
                                                </div>
                                                <div class="col-sm-12">
                                                    <label class="form-label">@lang('admin.status')</label>
                                                    <select class="form-control" name="status">
                                                        <option value="1" @if($value['status'] ==1) selected @endif>Aktiv</option>
                                                        <option value="0" @if($value['status'] ==0) selected @endif>Deactiv</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.close')</button>
                                    <button type="submit" class="btn btn-sm btn-primary">@lang('admin.save')</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- edit task modal -->
                <div class="modal fade" id="deleteMain{{$value['id']}}" tabindex="-1" aria-labelledby="deleteMain{{$value['id']}}Label" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h2 class="modal-title" id="deleteMain{{$value['id']}}Label">@lang('admin.delete')</h2>
                                <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                                    <i class="fa-light fa-times"></i>
                                </button>
                            </div>
                            <form action="{{ route('admin.pages.destroy',$value['id']) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <div class="modal-body">
                                    <h2>@lang('admin.delete_about')</h2>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.not')</button>
                                    <button type="submit" class="btn btn-sm btn-primary">@lang('admin.yes')</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                @if(!empty($value['parentPage'][0]) && isset($value['parentPage'][0]))
                    <!-- edit task modal -->
                    <div class="modal fade" id="eyeMain{{$value['id']}}" tabindex="-1" aria-labelledby="eyeMain{{$value['id']}}Label" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                            <div class="modal-content">
                                <table class="table table-dashed table-hover digi-dataTable task-table table-striped"
                                       id="taskTable">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>@lang('admin.title')</th>
                                        <th>@lang('admin.settings')</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($value['parentPage'] as $parentPage)
                                        <tr>
                                            <td>{{ $parentPage['id'] }}</td>
                                            <td>
                                                <div class="table-category-card">
                                                    <div class="part-txt">
                                                        <span class="category-name">{!! !empty($parentPage['title'][$currentLang])? $parentPage['title'][$currentLang]: null !!}</span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="btn-box">

                                                    @if(!empty($parentPage['parentCategories'][0]) && isset($parentPage['parentCategories'][0]))
                                                        <button class="btn btn-sm btn-icon btn-primary" data-bs-toggle="modal"
                                                                data-bs-target="#eyepageParentCategories{{$parentPage['id']}}"><i
                                                                class="fa-light fa-eye"></i>
                                                        </button>
                                                    @endif
                                                    <button class="btn btn-sm btn-icon btn-primary" data-bs-toggle="modal"
                                                            data-bs-target="#editParent{{$parentPage['id']}}"><i
                                                            class="fa-light fa-edit"></i>
                                                    </button>

                                                    <button class="btn btn-sm btn-icon btn-danger" data-bs-toggle="modal"
                                                            data-bs-target="#deleteParent{{$parentPage['id']}}"><i
                                                            class="fa-light fa-trash-can"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- edit task modal -->
                    @foreach($value['parentPage'] as $parentPage)
                    <div class="modal fade" id="eyepageParentCategories{{$parentPage['id']}}" tabindex="-1" aria-labelledby="eyepageParentCategories{{$parentPage['id']}}Label" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-lg">
                                <div class="modal-content">
                                    <table class="table table-dashed table-hover digi-dataTable task-table table-striped"
                                           id="taskTable">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>@lang('admin.title')</th>
                                            <th>@lang('admin.settings')</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($parentPage['parentCategories'] as $parentCategories)
                                            <tr>
                                                <td>{{ $parentCategories['id'] }}</td>
                                                <td>
                                                    <div class="table-category-card">
                                                        <div class="part-txt">
                                                            <span class="category-name">{!! !empty($parentCategories['title'][$currentLang])? $parentCategories['title'][$currentLang]: null !!}</span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="btn-box">

                                                        @if(!empty($parentCategories['subParentCategories'][0]) && isset($parentCategories['subParentCategories'][0]))
                                                            <button class="btn btn-sm btn-icon btn-primary" data-bs-toggle="modal"
                                                                    data-bs-target="#eyeSubParent{{$parentCategories['id']}}"><i
                                                                    class="fa-light fa-eye"></i>
                                                            </button>
                                                        @endif
                                                        <button class="btn btn-sm btn-icon btn-primary" data-bs-toggle="modal"
                                                                data-bs-target="#editSubParent{{$parentCategories['id']}}"><i
                                                                class="fa-light fa-edit"></i>
                                                        </button>

                                                        <button class="btn btn-sm btn-icon btn-danger" data-bs-toggle="modal"
                                                                data-bs-target="#deleteSubParent{{$parentCategories['id']}}"><i
                                                                class="fa-light fa-trash-can"></i></button>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <div class="modal fade" id="editParent{{$parentPage['id']}}" tabindex="-1" aria-labelledby="editParent{{$parentPage['id']}}Label" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                            <div class="modal-content">
                                <form action="{{ route('admin.pages.update',$parentPage['id']) }}" method="POST">
                                    @csrf
                                    @method('PUT')
                                    <div class="modal-body">
                                        <ul class="nav nav-pills nav-justified" role="tablist">
                                            @if(!empty($locales))
                                                @foreach($locales as $key => $lang)
                                                    <li class="nav-item waves-effect waves-light">
                                                        <a class="nav-link @if(++$key ==1) active @endif" data-bs-toggle="tab" href="#edit-parent{{$parentPage['id']}}{{$lang->code}}" role="tab">
                                                            <span class="d-none d-sm-block">{{$lang->code}}</span>
                                                        </a>
                                                    </li>
                                                @endforeach
                                            @endif
                                            <li class="nav-item waves-effect waves-light">
                                                <a class="nav-link" data-bs-toggle="tab"
                                                   href="#editother-parent{{$parentPage['id']}}" role="tab">
                                                    <span class="d-none d-sm-block">@lang('admin.other')</span>
                                                </a>
                                            </li>
                                        </ul>
                                        <div class="tab-content p-3 text-muted">
                                            @if(!empty($locales))
                                                @foreach($locales as $key => $lang)
                                                    <div class="tab-pane @if(++$key ==1) active @endif"
                                                         id="edit-parent{{$parentPage['id']}}{{$lang['code']}}" role="tabpanel">
                                                        <div class="row g-3">
                                                            <div class="col-12">
                                                                <label class="form-label">@lang('admin.title')
                                                                    - {{$lang['code']}}</label>
                                                                <input type="text" class="form-control"
                                                                       name="title[{{$lang['code']}}]"
                                                                       value="{{ !empty($parentPage['title'][$lang['code']])? $parentPage['title'][$lang['code']]: NULL }}">
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endforeach
                                            @endif
                                            <div class="tab-pane" id="editother-parent{{$parentPage['id']}}" role="tabpanel">
                                                <div class="row g-3">
                                                    @if(!empty($parentPage['parent_id']))
                                                        <div class="col-md-12">
                                                            <label for="input-category" class="form-label">@lang('admin.main_category')</label>
                                                            <select class="form-control" name="parent_id" id="input-category">
                                                                <option value="">@lang('admin.choose')</option>
                                                                @foreach($mainPage as $main)
                                                                    <option value="{{$main->id}}" @if(!empty($parentPage['parent_id']) && $parentPage['parent_id'] == $main['id']) selected @endif>{{ !empty(json_decode($main, true)['title'][$currentLang])? json_decode($main, true)['title'][$currentLang]: null }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    @endif

                                                    <div class="col-sm-12">
                                                        <label class="form-label">@lang('admin.page_type')</label>
                                                        <select class="form-control" name="page_type" disabled>
                                                            <option value="" @if($parentPage['page_type'] == '') selected @endif>@lang('admin.choose')</option>
                                                            <option value="slider" @if($parentPage['page_type'] == 'slider') selected @endif>@lang('admin.slider')</option>
                                                            <option value="file_content" @if($parentPage['page_type'] == 'file_content') selected @endif>@lang('admin.file_content')</option>
                                                            <option value="image_content" @if($parentPage['page_type'] == 'image_content') selected @endif>@lang('admin.image_content')</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-sm-12">
                                                        <label class="form-label">@lang('admin.status')</label>
                                                        <select class="form-control" name="status">
                                                            <option value="1" @if($parentPage['status'] ==1) selected @endif>Aktiv</option>
                                                            <option value="0" @if($parentPage['status'] ==0) selected @endif>Deactiv</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.close')</button>
                                        <button type="submit" class="btn btn-sm btn-primary">@lang('admin.save')</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- edit task modal -->
                    <div class="modal fade" id="deleteParent{{$parentPage['id']}}" tabindex="-1" aria-labelledby="deleteParent{{$parentPage['id']}}Label" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h2 class="modal-title" id="deletecategory{{$parentPage['id']}}Label">@lang('admin.delete')</h2>
                                    <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                                        <i class="fa-light fa-times"></i>
                                    </button>
                                </div>
                                <form action="{{ route('admin.pages.destroy',$parentPage['id']) }}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <div class="modal-body">
                                        <h2>@lang('admin.delete_about')</h2>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.not')</button>
                                        <button type="submit" class="btn btn-sm btn-primary">@lang('admin.yes')</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                        @foreach($parentPage['parentCategories'] as $parentCategories)
                            <div class="modal fade" id="eyeSubParent{{$parentCategories['id']}}" tabindex="-1" aria-labelledby="eyeSubParent{{$parentCategories['id']}}Label" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                    <div class="modal-content">
                                        <table class="table table-dashed table-hover digi-dataTable task-table table-striped"
                                               id="taskTable">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>@lang('admin.title')ss</th>
                                                <th>@lang('admin.settings')</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach($parentCategories['subParentCategories'] as $subParentCategories)
                                                <tr>
                                                    <td>{{ $subParentCategories['id'] }}</td>
                                                    <td>
                                                        <div class="table-category-card">
                                                            <div class="part-txt">
                                                                <span class="category-name">{!! !empty($subParentCategories['title'][$currentLang])? $subParentCategories['title'][$currentLang]: null !!}</span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="btn-box">
                                                            <button class="btn btn-sm btn-icon btn-primary" data-bs-toggle="modal"
                                                                    data-bs-target="#editPageSubParent{{$subParentCategories['id']}}"><i
                                                                    class="fa-light fa-edit"></i>
                                                            </button>

                                                            <button class="btn btn-sm btn-icon btn-danger" data-bs-toggle="modal"
                                                                    data-bs-target="#deletePageSubParent{{$subParentCategories['id']}}"><i
                                                                    class="fa-light fa-trash-can"></i></button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="editSubParent{{$parentCategories['id']}}" tabindex="-1" aria-labelledby="editSubParent{{$parentCategories['id']}}Label" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                    <div class="modal-content">
                                        <form action="{{ route('admin.pages.update',$parentCategories['id']) }}" method="POST">
                                            @csrf
                                            @method('PUT')
                                            <div class="modal-body">
                                                <ul class="nav nav-pills nav-justified" role="tablist">
                                                    @if(!empty($locales))
                                                        @foreach($locales as $key => $lang)
                                                            <li class="nav-item waves-effect waves-light">
                                                                <a class="nav-link @if(++$key ==1) active @endif" data-bs-toggle="tab" href="#edit-parent{{$parentCategories['id']}}{{$lang->code}}" role="tab">
                                                                    <span class="d-none d-sm-block">{{$lang->code}}</span>
                                                                </a>
                                                            </li>
                                                        @endforeach
                                                    @endif
                                                    <li class="nav-item waves-effect waves-light">
                                                        <a class="nav-link" data-bs-toggle="tab"
                                                           href="#editother-parent{{$parentCategories['id']}}" role="tab">
                                                            <span class="d-none d-sm-block">@lang('admin.other')</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                                <div class="tab-content p-3 text-muted">
                                                    @if(!empty($locales))
                                                        @foreach($locales as $key => $lang)
                                                            <div class="tab-pane @if(++$key ==1) active @endif"
                                                                 id="edit-parent{{$parentCategories['id']}}{{$lang['code']}}" role="tabpanel">
                                                                <div class="row g-3">
                                                                    <div class="col-12">
                                                                        <label class="form-label">@lang('admin.title')
                                                                            - {{$lang['code']}}</label>
                                                                        <input type="text" class="form-control"
                                                                               name="title[{{$lang['code']}}]"
                                                                               value="{{ !empty($parentCategories['title'][$lang['code']])? $parentCategories['title'][$lang['code']]: NULL }}">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                    @endif
                                                    <div class="tab-pane" id="editother-parent{{$parentCategories['id']}}" role="tabpanel">
                                                        <div class="row g-3">
                                                            @if(!empty($parentCategories['parent_id']))
                                                                <div class="col-md-12">
                                                                    <label for="input-category" class="form-label">@lang('admin.main_category')</label>
                                                                    <select class="form-control" name="parent_id" id="input-category">
                                                                        <option value="">@lang('admin.choose')</option>
                                                                        @foreach($mainPage as $main)
                                                                            <option value="{{$main->id}}" @if(!empty($parentCategories['parent_id']) && $parentCategories['parent_id'] == $main['id']) selected @endif>{{ !empty(json_decode($main, true)['title'][$currentLang])? json_decode($main, true)['title'][$currentLang]: null }}</option>
                                                                        @endforeach
                                                                    </select>
                                                                </div>
                                                            @endif
                                                            <div class="col-md-12 mt-3">
                                                                <label for="parent-category" class="form-label">@lang('admin.parent_category')</label>
                                                                <select class="form-control" name="page_parent_id" id="parent-category">
                                                                    <option value="{{$parentCategories['page_parent_id']}}" @if(!empty($parentCategories['page_parent_id']) && $parentPage['id'] == $parentCategories['page_parent_id']) selected @endif>{{ !empty(json_decode($parentPage, true)['title'][$currentLang])? json_decode($parentPage, true)['title'][$currentLang]: null }}</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-sm-12">
                                                                <label class="form-label">@lang('admin.page_type')</label>
                                                                <select class="form-control" name="page_type" disabled>
                                                                    <option value="" @if($parentCategories['page_type'] == '') selected @endif>@lang('admin.choose')</option>
                                                                    <option value="slider" @if($parentCategories['page_type'] == 'slider') selected @endif>@lang('admin.slider')</option>
                                                                    <option value="file_content" @if($parentCategories['page_type'] == 'file_content') selected @endif>@lang('admin.file_content')</option>
                                                                    <option value="image_content" @if($parentCategories['page_type'] == 'image_content') selected @endif>@lang('admin.image_content')</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-sm-12">
                                                                <label class="form-label">@lang('admin.status')</label>
                                                                <select class="form-control" name="status">
                                                                    <option value="1" @if($parentCategories['status'] ==1) selected @endif>Aktiv</option>
                                                                    <option value="0" @if($parentCategories['status'] ==0) selected @endif>Deactiv</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.close')</button>
                                                <button type="submit" class="btn btn-sm btn-primary">@lang('admin.save')</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- edit task modal -->
                            <div class="modal fade" id="deleteSubParent{{$parentCategories['id']}}" tabindex="-1" aria-labelledby="deleteSubParent{{$parentCategories['id']}}Label" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h2 class="modal-title" id="deletecategory{{$parentCategories['id']}}Label">@lang('admin.delete')</h2>
                                            <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                                                <i class="fa-light fa-times"></i>
                                            </button>
                                        </div>
                                        <form action="{{ route('admin.pages.destroy',$parentCategories['id']) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <div class="modal-body">
                                                <h2>@lang('admin.delete_about')</h2>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.not')</button>
                                                <button type="submit" class="btn btn-sm btn-primary">@lang('admin.yes')</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            @foreach($parentCategories['subParentCategories'] as $subParentCategories)
                                <div class="modal fade" id="editPageSubParent{{$subParentCategories['id']}}" tabindex="-1" aria-labelledby="editPageSubParent{{$subParentCategories['id']}}Label" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <form action="{{ route('admin.pages.update',$subParentCategories['id']) }}" method="POST">
                                                @csrf
                                                @method('PUT')
                                                <div class="modal-body">
                                                    <ul class="nav nav-pills nav-justified" role="tablist">
                                                        @if(!empty($locales))
                                                            @foreach($locales as $key => $lang)
                                                                <li class="nav-item waves-effect waves-light">
                                                                    <a class="nav-link @if(++$key ==1) active @endif" data-bs-toggle="tab" href="#edit-subparent{{$subParentCategories['id']}}{{$lang->code}}" role="tab">
                                                                        <span class="d-none d-sm-block">{{$lang->code}}</span>
                                                                    </a>
                                                                </li>
                                                            @endforeach
                                                        @endif
                                                        <li class="nav-item waves-effect waves-light">
                                                            <a class="nav-link" data-bs-toggle="tab"
                                                               href="#editother-subparent{{$subParentCategories['id']}}" role="tab">
                                                                <span class="d-none d-sm-block">@lang('admin.other')</span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                    <div class="tab-content p-3 text-muted">
                                                        @if(!empty($locales))
                                                            @foreach($locales as $key => $lang)
                                                                <div class="tab-pane @if(++$key ==1) active @endif"
                                                                     id="edit-subparent{{$subParentCategories['id']}}{{$lang['code']}}" role="tabpanel">
                                                                    <div class="row g-3">
                                                                        <div class="col-12">
                                                                            <label class="form-label">@lang('admin.title')
                                                                                - {{$lang['code']}}</label>
                                                                            <input type="text" class="form-control"
                                                                                   name="title[{{$lang['code']}}]"
                                                                                   value="{{ !empty($subParentCategories['title'][$lang['code']])? $subParentCategories['title'][$lang['code']]: NULL }}">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        @endif
                                                        <div class="tab-pane" id="editother-subparent{{$subParentCategories['id']}}" role="tabpanel">
                                                            <div class="row g-3">
                                                                @if(!empty($subParentCategories['parent_id']))
                                                                    <div class="col-md-12">
                                                                        <label for="input-category" class="form-label">@lang('admin.main_category')</label>
                                                                        <select class="form-control" name="parent_id" id="input-category">
                                                                            <option value="">@lang('admin.choose')</option>
                                                                            @foreach($mainPage as $main)
                                                                                <option value="{{$main->id}}" @if(!empty($subParentCategories['parent_id']) && $subParentCategories['parent_id'] == $main['id']) selected @endif>{{ !empty(json_decode($main, true)['title'][$currentLang])? json_decode($main, true)['title'][$currentLang]: null }}</option>
                                                                            @endforeach
                                                                        </select>
                                                                    </div>
                                                                @endif
                                                                    <div class="col-md-12 mt-3">
                                                                        <label for="parent-category" class="form-label">@lang('admin.parent_category')</label>
                                                                        <select class="form-control" name="page_parent_id" id="parent-category">
                                                                            <option value="{{$subParentCategories['page_parent_id']}}" @if(!empty($subParentCategories['page_parent_id']) && $parentPage['id'] == $parentCategories['page_parent_id']) selected @endif>{{ !empty(json_decode($parentPage, true)['title'][$currentLang])? json_decode($parentPage, true)['title'][$currentLang]: null }}</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="col-md-12 mt-3">
                                                                        <label for="parent-category" class="form-label">@lang('admin.parent_category')</label>
                                                                        <select class="form-control" name="page_sub_parent_id" id="parent-category">
                                                                            <option value="{{$subParentCategories['page_sub_parent_id']}}" @if(!empty($subParentCategories['page_sub_parent_id']) && $parentCategories['id'] == $parentCategories['page_sub_parent_id']) selected @endif>{{ !empty(json_decode($parentCategories, true)['title'][$currentLang])? json_decode($parentCategories, true)['title'][$currentLang]: null }}</option>
                                                                        </select>
                                                                    </div>
                                                                <div class="col-sm-12">
                                                                    <label class="form-label">@lang('admin.page_type')</label>
                                                                    <select class="form-control" name="page_type">
                                                                        <option value="" @if($subParentCategories['page_type'] == '') selected @endif>@lang('admin.choose')</option>
                                                                        <option value="slider" @if($subParentCategories['page_type'] == 'slider') selected @endif>@lang('admin.slider')</option>
                                                                        <option value="file_content" @if($subParentCategories['page_type'] == 'file_content') selected @endif>@lang('admin.file_content')</option>
                                                                        <option value="image_content" @if($subParentCategories['page_type'] == 'image_content') selected @endif>@lang('admin.image_content')</option>
                                                                    </select>
                                                                </div>
                                                                <div class="col-sm-12">
                                                                    <label class="form-label">@lang('admin.status')</label>
                                                                    <select class="form-control" name="status">
                                                                        <option value="1" @if($subParentCategories['status'] ==1) selected @endif>Aktiv</option>
                                                                        <option value="0" @if($subParentCategories['status'] ==0) selected @endif>Deactiv</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.close')</button>
                                                    <button type="submit" class="btn btn-sm btn-primary">@lang('admin.save')</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!-- edit task modal -->
                                <div class="modal fade" id="deletePageSubParent{{$subParentCategories['id']}}" tabindex="-1" aria-labelledby="deletePageSubParent{{$subParentCategories['id']}}Label" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h2 class="modal-title" id="deletecategory{{$subParentCategories['id']}}Label">@lang('admin.delete')</h2>
                                                <button type="button" class="btn btn-sm btn-icon btn-outline-primary" data-bs-dismiss="modal" aria-label="Close">
                                                    <i class="fa-light fa-times"></i>
                                                </button>
                                            </div>
                                            <form action="{{ route('admin.pages.destroy',$subParentCategories['id']) }}" method="POST">
                                                @csrf
                                                @method('DELETE')
                                                <div class="modal-body">
                                                    <h2>@lang('admin.delete_about')</h2>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">@lang('admin.not')</button>
                                                    <button type="submit" class="btn btn-sm btn-primary">@lang('admin.yes')</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        @endforeach
                    @endforeach
                @endif
        @endforeach
    @endif
@endsection
@section('admin.js')
    <script src="{{ asset('admin/assets/vendor/js/jquery.uploader.min.js') }}"></script>
    <script src="{{ asset('admin/assets/js/category.js') }}"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const mainCategorySelect = document.getElementById('input-category');
            const parentCategorySelect = document.getElementById('parent-category');
            const subCategorySelect = document.getElementById('sub-category');

            // Main Category seçildikdə
            mainCategorySelect.addEventListener('change', function () {
                const parentId = this.value;
                parentCategorySelect.innerHTML = '<option value="">@lang('admin.choose')</option>';
                subCategorySelect.innerHTML = '<option value="">@lang('admin.choose')</option>';
                subCategorySelect.disabled = true;

                if (parentId) {
                    fetch(`/admin/pages/parent?parent_id=${parentId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                data.parentPage.forEach(category => {
                                    const option = document.createElement('option');
                                    option.value = category.id;
                                    option.textContent = category.title;
                                    parentCategorySelect.appendChild(option);
                                });
                                parentCategorySelect.disabled = false;
                            }
                        });
                } else {
                    parentCategorySelect.disabled = true;
                }
            });

            // Parent Category seçildikdə
            parentCategorySelect.addEventListener('change', function () {
                const parentId = this.value;
                subCategorySelect.innerHTML = '<option value="">@lang('admin.choose')</option>';

                if (parentId) {
                    fetch(`/admin/pages-categories/parent?page_parent_id=${parentId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                data.parentCategories.forEach(category => {
                                    const option = document.createElement('option');
                                    option.value = category.id;
                                    option.textContent = category.title;
                                    subCategorySelect.appendChild(option);
                                });
                                subCategorySelect.disabled = false;
                            }
                        });
                } else {
                    subCategorySelect.disabled = true;
                }
            });

            // Sub Category seçildikdə
            subCategorySelect.addEventListener('change', function () {
                const subParentId = this.value;

                if (subParentId) {
                    fetch(`/admin/pages-categories/sub-parent?page_sub_parent_id=${subParentId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                console.log('Alt kateqoriyalar:', data.subParentCategories);
                                // Əlavə əməliyyatlar aparıla bilər
                            }
                        });
                }
            });
        });
    </script>
@endsection
