<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PageContent extends Model
{
    use HasFactory;

    protected $table = 'page_contents';

    protected $fillable = [
        'id',
        'page_id',
        'parent_page_id',
        'page_parent_id',
        'page_sub_parent_id',
        'page_type',
        'file',
        'image',
        'slider_image',
        'title',
        'slug',
        'text',
        'fulltext',
        'order_by',
        'status',
        'datetime'
    ];

    protected $casts = [
        'title' => 'array',
        'text' => 'array',
        'slug' => 'array',
        'fulltext' => 'array',
        'slider_image' => 'array',
    ];

    public function page()
    {
        return $this->hasOne(Page::class,'id','page_id')->where(['status' => 1,'parent_id' => null]);
    }

    public function parentPage()
    {
        return $this->hasOne(Page::class,'id','parent_page_id')->where(['status' => 1]);
    }
    public function subParentPage()
    {
        return $this->hasOne(Page::class,'id','page_parent_id')->where(['status' => 1]);
    }
    public function pageSubParentPage()
    {
        return $this->hasOne(Page::class,'id','page_sub_parent_id')->where(['status' => 1]);
    }

}
