<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Training extends Model
{
    use HasFactory;

    protected $table = 'trainings';

    protected $fillable = [
        'id',
        'title',
        'slug',
        'order_by',
        'status',
        'weight',
        'type'
    ];

    protected $casts = [
        'title' => 'array',
        'slug' => 'array',
    ];
}
