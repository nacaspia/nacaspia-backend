<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LeaderShip extends Model
{
    use HasFactory;

    protected $table = 'leaderships';

    protected $fillable = [
        'id',
        'category_id',
        'position_id',
        'parent_position_id',
        'image',
        'full_name',
        'slug',
        'fulltext',
        'reception_days',
        'order_by',
        'is_show',
        'status'
    ];

    protected $casts = [
        'full_name' => 'array',
        'slug' => 'array',
        'fulltext' => 'array',
        'reception_days' => 'array',
    ];

    public function scopeOrdered($query)
    {
        return $query->orderBy('order_by');
    }

    public function parent(){
        return $this->hasOne(Position::class,'id','parent_position_id');
    }
}
