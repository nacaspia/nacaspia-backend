<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    use HasFactory;

    protected $table = 'categories';

    protected $fillable = [
        'id',
        'parent_id',
        'sub_parent_id',
        'title',
        'slug',
        'order_by',
        'status'
    ];

    protected $casts = [
        'title' => 'array',
        'slug' => 'array',
    ];

    public function news()
    {
        return $this->hasMany(News::class,'category_id','id')->where(['status' => 1])->orderBy('datetime','DESC');
    }

    public function parentCategories()
    {
        return $this->hasMany(Category::class,'parent_id','id')->whereNull('sub_parent_id')->with('subParentCategories');
    }

    public function subParentCategories()
    {
        return $this->hasMany(Category::class,'sub_parent_id','id');
    }
}
