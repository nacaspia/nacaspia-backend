<?php

namespace App\Repositories;

use App\Contracts\TrainingRepository;
use App\Models\Training;

class TrainingRepositoryIml implements TrainingRepository
{
    protected $model;
    protected $training;

    public function __construct()
    {
        $this->model  = new Training();
        $this->training = Training::orderBy('id','DESC')->get();
    }

    public function getAll()
    {
        return $this->training;
    }

    public function create(array $data)
    {
        return $this->model->create($data);
    }

    public function edit($id)
    {
        return $this->model->whereId($id)->first();
    }

    public function update($id, array $data)
    {
        return $this->model->whereId($id)->update($data);
    }

    public function delete($id)
    {
        return $this->model->whereId($id)->delete();
    }
}
