<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Lang;

class EnlightenmentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules()
    {
        $isCreate = $this->isMethod('post');
        return [
           'image' => $isCreate
               ? 'required|image|mimes:jpeg,png,jpg,gif,svg|dimensions:width=2000,height=2000|max:2100'
               : 'nullable|image|mimes:jpeg,png,jpg,gif,svg|dimensions:max_width=2000,max_height=2000|max:2100',
            'title.az' => 'required|string|max:255',
            'text.az' => 'nullable|string',
            'fulltext.az' => 'nullable|string',
//            'datetime' => 'required|date',
        ];
    }

    public function messages()
    {
        return [
            '*.required' => Lang::get('validation.required', ['attribute' => ':attribute']),
            '*.string' => Lang::get('validation.string', ['attribute' => ':attribute']),
//            'datetime.date' => Lang::get('validation.date', ['attribute' => ':attribute']),
                'image.required' => 'Şəkil yükləmək məcburidir.',
                'image.image' => 'Yalnız şəkil faylları yüklənə bilər.',
                'image.mimes' => 'Şəkil yalnız jpeg, png, jpg, gif və ya svg formatında olmalıdır.',
                'image.dimensions' => 'Şəkilin ölçüsü 2000x2000 piksel olmalıdır.',
                'image.max' => 'Şəkil faylının maksimum ölçüsü 2.1 MB olmalıdır.'

        ];
    }
}
