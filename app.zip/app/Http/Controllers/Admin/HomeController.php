<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Repositories\SlidersRepositoryImpl;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;

class HomeController extends Controller
{
    protected $sliderRepository;
    protected $currentLang;

    public function __construct(SlidersRepositoryImpl $sliderRepository)
    {
        $this->sliderRepository = $sliderRepository;
        $this->currentLang = LaravelLocalization::getCurrentLocale();
        if (!in_array($this->currentLang,['az','en','ru'])){
            return self::notFound();
        }
    }
    public function notFound()
    {
        $currentLang = $this->currentLang;
        return view('site.not_found',compact('currentLang'));
    }
    public function index()
    {
        $sliders = $this->sliderRepository->getAll();
        $currentLang = $this->currentLang;
        return view('admin.sliders.index',compact('sliders','currentLang'));
    }

}
